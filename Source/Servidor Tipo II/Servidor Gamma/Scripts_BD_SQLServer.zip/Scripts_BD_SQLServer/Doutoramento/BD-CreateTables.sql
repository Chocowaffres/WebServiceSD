
-------------------------------------------------------------------------------
-- USE DBProject: Changes the database context to the DBProject database.
--
USE Doutoramento
--
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- Criar as tabelas
-- (create the database tables)
-------------------------------------------------------------------------------

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Curso]') )
begin
  CREATE TABLE Curso (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  Nome nvarchar (30) NOT NULL,
	  Codigo int NOT NULL,
	  ECTS int NOT NULL,
	  Descricao nvarchar (100) NOT NULL,  

      CONSTRAINT U_Descricao UNIQUE (Descricao)	  

  ); 
end


-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Aluno]') )
begin
  CREATE TABLE Aluno (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  ID_Curso int NOT NULL,     
	  
	  CONSTRAINT FK_ID_Curso_Aluno FOREIGN KEY (ID_Curso) 
	     REFERENCES Curso(ID)
	     ON UPDATE CASCADE 
	     ON DELETE NO ACTION

  ); 
end

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Disciplina]') )
begin
  CREATE TABLE Disciplina (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  Nome nvarchar (30) NOT NULL,
	  Codigo int NOT NULL,           
	  Criterios nvarchar (300) NOT NULL,
	  Descricao nvarchar (300) NOT NULL,
	  ECTS int NOT NULL,  
	  ID_Curso int NOT NULL,

	  CONSTRAINT U_Codigo UNIQUE (Codigo),            -- constraint type: unique 
	  
	  CONSTRAINT FK_ID_Curso_Disciplina FOREIGN KEY (ID_Curso) 
	     REFERENCES Curso(ID)
	     ON UPDATE CASCADE 
	     ON DELETE CASCADE

  ); 
end

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Estado]') )
begin
  CREATE TABLE Estado (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  Designacao nvarchar (30) NOT NULL,   

  ); 
end

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Inscricao_Aluno_Disciplina]') )
begin
  CREATE TABLE Inscricao_Aluno_Disciplina (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  ID_Aluno int NOT NULL,
	  ID_Disciplina int NOT NULL,           
	  Ano int NOT NULL,
		CHECK (Ano >= 2000),
	  Nota int,    -- obrigatoriedade de nota apenas no caso de reprovado ou aprovado.
				   -- caso a cadeira esteja a decorrer n�o tem de ter nota associada      
	  ID_Estado int NOT NULL,
	  
	  CONSTRAINT FK_ID_Aluno_Inscricao FOREIGN KEY (ID_Aluno) 
	     REFERENCES Aluno(ID)
	     ON UPDATE CASCADE 
	     ON DELETE CASCADE,

	  CONSTRAINT FK_ID_Disciplina_Inscricao FOREIGN KEY (ID_Disciplina) 
	     REFERENCES Disciplina(ID)
	     ON UPDATE NO ACTION 
	     ON DELETE NO ACTION, -- manter nota de aluno mesmo que cadeira desapare�a

	  CONSTRAINT FK_ID_Estado FOREIGN KEY (ID_Estado) 
	     REFERENCES Estado(ID)
	     ON UPDATE CASCADE 
	     ON DELETE NO ACTION
  ); 
end

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Tipo_Avaliacao]') )
begin
  CREATE TABLE Tipo_Avaliacao (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  Designacao nvarchar (30) NOT NULL,    

  ); 
end

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Avaliacao]') )
begin
  CREATE TABLE Avaliacao (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  Fator_Ponderacao int NOT NULL,           
	  Data nchar (10) NOT NULL,
	  ID_Tipo_Avaliacao int NOT NULL,
	  ID_Disciplina int NOT NULL,
	  
	  CONSTRAINT FK_ID_Tipo_Avaliacao FOREIGN KEY (ID_Tipo_Avaliacao) 
	     REFERENCES Tipo_Avaliacao(ID)
	     ON UPDATE CASCADE 
	     ON DELETE CASCADE,

	  CONSTRAINT FK_ID_Disciplina_Avaliacao FOREIGN KEY (ID_Disciplina) 
	     REFERENCES Disciplina(ID)
	     ON UPDATE CASCADE 
	     ON DELETE NO ACTION
  ); 
end

-- ....................................... .....................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Avaliacao_Aluno]') )
begin
  CREATE TABLE Avaliacao_Aluno (
	  ID_Avaliacao int NOT NULL,
	  ID_Aluno int NOT NULL,
	  Nota float NOT NULL,          

	  CONSTRAINT PK_PRIM_KEY PRIMARY KEY (ID_Avaliacao, ID_Aluno),

	  CONSTRAINT FK_ID_Avaliacao_Avaliacao_Aluno FOREIGN KEY (ID_Avaliacao) 
	     REFERENCES Avaliacao(ID)
	     ON UPDATE NO ACTION 
	     ON DELETE NO ACTION,

	  CONSTRAINT FK_ID_Aluno_Avaliacao_Aluno FOREIGN KEY (ID_Aluno) 
	     REFERENCES Aluno (ID)
	     ON UPDATE CASCADE 
	     ON DELETE CASCADE,

  ); 
end
