-------------------------------------------------------------------------------
-- USE DBProject: Changes the database context to the DBProject database.
--
USE Doutoramento
--
-------------------------------------------------------------------------------
--
-------------------------------------------------------------------------------
------------  INSERT SOME DATA INTO TABLES  -----------------------------------
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
------------- Transaction mode: explicit transactions
-------------------------------------------------------------------------------


BEGIN TRAN

-- Curso 1 : Doutoramento de BM
INSERT INTO Curso(Nome, Codigo, ECTS, Descricao)
VALUES ('B.M', 447, 240, 'Biom�dicas - Doutoramento');

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Doutoramento de Jos� em BM
INSERT INTO Aluno(ID_Curso)
VALUES (1);


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Estado 1 : Aprovado
INSERT INTO Estado(Designacao)
VALUES ('Aprovado');

-- Estado 2 : Reprovado
INSERT INTO Estado(Designacao)
VALUES ('Reprovado');

-- Estado 3 : A decorrer
INSERT INTO Estado(Designacao)
VALUES ('A decorrer');


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Tipo_Avaliacao 1 : Frequ�ncia
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Frequ�ncia');

-- Tipo_Avaliacao 2 : Exerc�cios
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Exerc�cios');

-- Tipo_Avaliacao 3 : Cont�nua (Projeto)
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Cont�nua');


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Disciplina 1 (Disserta��o de BM)
INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso)
VALUES ('Disserta��o', 55, 'Crescer', 'Descobrir', 240, 1);


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Inscricao_Aluno_Disciplina 1 : Jos� em Dissertacao (A decorrer)
INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado)
VALUES (1, 1, 2019, 3);

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Avaliacao 1: Dissertacao
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (100, '07-07-2019', 3, 1);

COMMIT;
