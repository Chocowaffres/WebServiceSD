﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net;
using System.ServiceModel;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;

/// <summary>
/// Summary description for WebService
/// </summary>

// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]

[ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.Single)]

public class ServicoWeb : System.Web.Services.WebService
{

    public ServicoWeb()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    // --------------------------------------------------------------------------------------------------------------------

    // Buscar info em BD local
    private string sIP = "localhost\\sqlexpress";
    private string sDBname = "Mestrado";
    private string sUser = "aluno";
    private string sPass = "SDtest123";

    [WebMethod]
    public string getCursoAlunoUsandoNumero(string sNumUser, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select C.Descricao " +
            "From Aluno A, Curso C " +
            "where A.ID_Curso = C.ID " +
            "and A.ID = @Num_Aluno", conn);

        comm.Parameters.AddWithValue("@Num_Aluno", sNumUser);

        SqlDataReader rdr;

        var listCursos = new List<Curso>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listCursos.Add(new Curso() { Descricao = rdr.GetString(0) });
            }

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listCursos);

        return serializedResult;
    }

    [WebMethod]
    public string getCursos(string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select C.ID, C.Descricao " +
            "From Curso C ", conn);

        SqlDataReader rdr;

        var listCursos = new List<Curso>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listCursos.Add(new Curso() { Codigo = rdr.GetInt32(0), Descricao = rdr.GetString(1) });
            }

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listCursos);

        return serializedResult;
    }

    [WebMethod]
    public string getCadeirasDeCurso(string sCurso, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select D.ID, D.Codigo, D.Nome " +
            "From Curso C, Disciplina D " +
            "where C.Descricao = @Nome_Curso " +
            "and D.ID_Curso = C.ID", conn);

        comm.Parameters.AddWithValue("@Nome_Curso", sCurso);

        SqlDataReader rdr;

        var listCadeira = new List<Cadeira>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listCadeira.Add(new Cadeira()
                {
                    ID = rdr.GetInt32(0),
                    Codigo = rdr.GetInt32(1),
                    Nome = rdr.GetString(2),
                });
            }
            conn.Close();

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listCadeira);

        return serializedResult;

    }

    [WebMethod]
    public string getAvaliacoesDeCadeira(string sCadeira, string sCurso, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select AV.ID, AV.Data, TA.Designacao, AV.Fator_Ponderacao as Nota " +
            "From Curso C, Disciplina D, Avaliacao AV, Tipo_Avaliacao TA " +
            "where C.Descricao = @Nome_Curso " +
            "and D.ID_Curso = C.ID " +
            "and D.Nome = @Nome_Cadeira " +
            "and AV.ID_Disciplina = D.ID " +
            "and TA.ID = AV.ID_Tipo_Avaliacao " +
            "order by AV.Data ASC", conn);

        comm.Parameters.AddWithValue("@Nome_Curso", sCurso);
        comm.Parameters.AddWithValue("@Nome_Cadeira", sCadeira);

        SqlDataReader rdr;

        var listAvaliacoes = new List<Avaliacao>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listAvaliacoes.Add(new Avaliacao()
                {
                    ID = rdr.GetInt32(0),
                    Data = rdr.GetString(1),
                    Designacao = rdr.GetString(2),
                    Nota = rdr.GetInt32(3)
                });
            }
            conn.Close();

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listAvaliacoes);

        return serializedResult;
    }

    [WebMethod]
    public string getNotasDeAvaliacaoDeCadeira(string sIdCadeira, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select AA.ID_Aluno, AA.Nota " +
            "From Avaliacao AV, Avaliacao_Aluno AA " +
            "where AV.ID = @sIdCadeira " +
            "and AA.ID_Avaliacao = AV.ID", conn);

        comm.Parameters.AddWithValue("@sIdCadeira", sIdCadeira);

        SqlDataReader rdr;

        var listAvaliacoes = new List<NotaDeAvaliacaoDeCadeira>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listAvaliacoes.Add(new NotaDeAvaliacaoDeCadeira()
                {
                    ID = rdr.GetInt32(0),
                    Nota = rdr.GetDouble(1)
                });
            }
            conn.Close();

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listAvaliacoes);

        return serializedResult;
    }

    [WebMethod]
    public string getCadeirasAluno(string sNumUser, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
           "Select D.ID, D.Nome as Disciplina, " +
	        "case " +
                "when E.Designacao = 'A decorrer' then 'Em avaliação' " +
                "else CONVERT(varchar(2), IAD.Nota) " +
            "end as Nota " +
            "from Aluno A, Disciplina D, Inscricao_Aluno_Disciplina IAD, Estado E " +
            "where A.ID = (Select A1.ID " +
                            "From Aluno A1 " +
                            "where A1.ID = @sNumUser " +
            ") " +
            "and IAD.ID_Aluno = A.ID " +
            "and IAD.ID_Disciplina = D.ID " +
            "and IAD.ID_Estado = E.ID", conn);

        comm.Parameters.AddWithValue("@sNumUser", sNumUser);

        SqlDataReader rdr;

        var listAvaliacoes = new List<ClassificacaoDeCadeira>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listAvaliacoes.Add(new ClassificacaoDeCadeira()
                {
                    ID = rdr.GetInt32(0),
                    Nome = rdr.GetString(1),
                    Nota = rdr.GetString(2)
                });
            }
            conn.Close();

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listAvaliacoes);

        return serializedResult;
    }

    [WebMethod]
    public string getAvaliacoesDeAlunoEmCadeira(string sNumUser, string sNumDisciplina, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select AV.Data, TA.Designacao, AA.Nota " +
            "from Avaliacao AV, Aluno A, Disciplina D, Tipo_Avaliacao TA, Avaliacao_Aluno AA " +
            "where A.ID = (Select A1.ID " +
                "From Aluno A1 " +
                "where A1.ID = @sNumUser " +
            ") " +
            "and D.ID = (Select D1.ID " +
                "From Disciplina D1 " +
                "where D1.ID = @sNumDisciplina " +
                "and D1.ID_Curso = A.ID_Curso " +
            ") " +
            "and AV.ID_Disciplina = D.ID " +
            "and TA.ID = AV.ID_Tipo_Avaliacao " +
            "and AA.ID_Aluno = A.ID " +
            "and AA.ID_Avaliacao = AV.ID " +
            "order by AV.Data ASC", conn);

        comm.Parameters.AddWithValue("@sNumUser", sNumUser);
        comm.Parameters.AddWithValue("@sNumDisciplina", sNumDisciplina);

        SqlDataReader rdr;

        var listAvaliacoes = new List<AvaliacaoDeAlunoEmCadeira>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listAvaliacoes.Add(new AvaliacaoDeAlunoEmCadeira()
                {
                    Data = rdr.GetString(0),
                    Designacao = rdr.GetString(1),
                    Nota = rdr.GetDouble(2)
                });
            }
            conn.Close();

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listAvaliacoes);

        return serializedResult;
    }


    // --------------------------------------------------------------------------------------------------------------------
    // Inserções

    // Inserções de novo curso
    [WebMethod]
    public string insertNovoCurso(string sNomeCurso, string sCodigo, string sNumbECTS, string sDescricao, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "INSERT INTO Curso(Nome, Codigo, ECTS, Descricao) " +
            "VALUES(@sNomeCurso, @sCodigo, @sNumbECTS, @sDescricao)", conn);

        comm.Parameters.AddWithValue("@sNomeCurso", sNomeCurso);
        comm.Parameters.AddWithValue("@sNumbECTS", sNumbECTS);
        comm.Parameters.AddWithValue("@sDescricao", sDescricao);
        comm.Parameters.AddWithValue("@sCodigo", sCodigo);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);
    }

    // Inserções de aluno em curso
    [WebMethod]
    public string insertAlunoIntoCurso(string sNumCurso, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        // Criar associacao de curso/ID de aluno (criado automaticamente)
        int iValor = associaAlunoACurso(sNumCurso, sGrau);
        string sResposta = "NO_OK";

        if (iValor == -1)
        {
            sResposta = "NO_OK";
        }
        else
        {
            int iAux = getUltimoNumeroAluno(sGrau);
            if (iAux == -1)
            {
                sResposta = "NO_OK";
            }
            else
            {
                sResposta = iAux.ToString();
            }
        }

        return jsonResposta(sResposta);
    }

    public int associaAlunoACurso(string sNumCurso, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "INSERT INTO Aluno(ID_Curso) " +
            "VALUES(@sNumCurso)", conn);

        comm.Parameters.AddWithValue("@sNumCurso", sNumCurso);

        SqlDataReader rdr;

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();

        }
        catch (Exception e)
        {
            return -1;
        }

        return 0;

    }

    public int getUltimoNumeroAluno(string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "SELECT TOP 1 ID FROM Aluno ORDER BY ID DESC;", conn);

        SqlDataReader rdr;

        int sNumAluno = -1;

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                sNumAluno = rdr.GetInt32(0);
            }
            conn.Close();

        }
        catch (Exception e)
        {
            return -1;
        }

        return sNumAluno;
    }

    // Inserções  de disciplina em curso
    [WebMethod]
    public string insertDisciplinaIntoCurso(string sNomeDisc, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso) " +
            "VALUES(@sNomeDisc, @sCodigo, @sCriterios, @sDescricao, @sNumbECTS, @sNumCurso)", conn);

        comm.Parameters.AddWithValue("@sNumCurso", sNumCurso);
        comm.Parameters.AddWithValue("@sNumbECTS", sNumbECTS);
        comm.Parameters.AddWithValue("@sDescricao", sDescricao);
        comm.Parameters.AddWithValue("@sCriterios", sCriterios);
        comm.Parameters.AddWithValue("@sCodigo", sCodigo);
        comm.Parameters.AddWithValue("@sNomeDisc", sNomeDisc);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    // Inserções  de aluno em disciplina
    [WebMethod]
    public string insertAlunoIntoDisciplina(string sNumAluno, string sNumDisc, string sAno, string sEstado, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado) " +
            "VALUES(@sNumAluno, @sNumDisc, @sAno, @sEstado)", conn);

        comm.Parameters.AddWithValue("@sNumAluno", sNumAluno);
        comm.Parameters.AddWithValue("@sNumDisc", sNumDisc);
        comm.Parameters.AddWithValue("@sAno", sAno);
        comm.Parameters.AddWithValue("@sEstado", sEstado);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    // Inserções  de nova avaliação em disciplina
    [WebMethod]
    public string insertAvaliacaoIntoDisciplina(string Fator_Ponderacao, string Data, string ID_Tipo_Avaliacao, string ID_Disciplina, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina) " +
            "VALUES(@Fator_Ponderacao, @Data, @ID_Tipo_Avaliacao, @ID_Disciplina)", conn);

        comm.Parameters.AddWithValue("@Fator_Ponderacao", Fator_Ponderacao);
        comm.Parameters.AddWithValue("@Data", Data);
        comm.Parameters.AddWithValue("@ID_Tipo_Avaliacao", ID_Tipo_Avaliacao);
        comm.Parameters.AddWithValue("@ID_Disciplina", ID_Disciplina);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    // Inserções de nota de aluno em avaliacao
    [WebMethod]
    public string insertNotaDeAlunoAvaliacao(string ID_Avaliacao, string ID_Aluno, string Nota, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) " +
            "VALUES(@ID_Avaliacao, @ID_Aluno, @Nota)", conn);

        comm.Parameters.AddWithValue("@ID_Avaliacao", ID_Avaliacao);
        comm.Parameters.AddWithValue("@ID_Aluno", ID_Aluno);
        comm.Parameters.AddWithValue("@Nota", Nota);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK"; ;
        }

        return jsonResposta(sResposta);

    }


    // --------------------------------------------------------------------------------------------------------------------
    // Updates

    // Fornecer informação para completar campos da interface
    [WebMethod]
    public string getCursosInformacao(string ID_Curso, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select Nome, ECTS, Codigo, Descricao " +
            "From Curso " +
            "where ID = @ID_Curso ", conn);

        comm.Parameters.AddWithValue("@ID_Curso", ID_Curso);

        SqlDataReader rdr;

        var listCursosInformacao = new List<CursoInformacao>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listCursosInformacao.Add(new CursoInformacao()
                {
                    Nome = rdr.GetString(0),
                    ECTS = rdr.GetInt32(1),
                    Codigo = rdr.GetInt32(2),
                    Descricao = rdr.GetString(3),
                });
            }

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listCursosInformacao);

        return serializedResult;
    }

    // Fornecer informação para completar campos da interface
    [WebMethod]
    public string getCadeirasInformacao(string ID_Cadeira, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select Nome, Codigo, Criterios, Descricao, ECTS " +
            "From Disciplina " +
            "where ID = @ID_Cadeira ", conn);

        comm.Parameters.AddWithValue("@ID_Cadeira", ID_Cadeira);

        SqlDataReader rdr;

        var listCadeiraInformacao = new List<CadeiraInformacao>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listCadeiraInformacao.Add(new CadeiraInformacao()
                {
                    Nome = rdr.GetString(0),
                    Codigo = rdr.GetInt32(1),
                    Criterios = rdr.GetString(2),
                    Descricao = rdr.GetString(3),
                    ECTS = rdr.GetInt32(4),
                });
            }

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listCadeiraInformacao);

        return serializedResult;
    }
    
    // Fornecer informação para completar campos da interface
    [WebMethod]
    public string getAvaliacaoInformacao(string ID_Avaliacao, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select Fator_Ponderacao, Data " +
            "From Avaliacao " +
            "where ID = @ID_Avaliacao ", conn);

        comm.Parameters.AddWithValue("@ID_Avaliacao", ID_Avaliacao);

        SqlDataReader rdr;

        var listAvaliacaoInformacao = new List<AvaliacaoInformacao>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listAvaliacaoInformacao.Add(new AvaliacaoInformacao()
                {
                    FatorPonderacao = rdr.GetInt32(0),
                    Data = rdr.GetString(1),
                });
            }

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listAvaliacaoInformacao);

        return serializedResult;
    }

    // Fornecer informação para completar campos da interface (caso falhe o servidor com PHP)
    [WebMethod]
    public string getTipoAvaliacao()
    {

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "Select ID, Designacao " +
            "From Tipo_Avaliacao ", conn);

        SqlDataReader rdr;

        var listTipoAvaliacao = new List<TipoAvaliacao>();

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            while (rdr.Read())
            {
                listTipoAvaliacao.Add(new TipoAvaliacao()
                {
                    ID = rdr.GetInt32(0),
                    Designacao = rdr.GetString(1),
                });
            }

        }
        catch (Exception e)
        {
            return e.ToString();
        }

        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listTipoAvaliacao);

        return serializedResult;
    }



    [WebMethod]
    public string updateAvaliacao(string ID_Avaliacao, string Fator_Ponderacao, string Data, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "UPDATE Avaliacao " +
            "SET Fator_Ponderacao = @Fator_Ponderacao, Data = @Data " +
            "WHERE ID = @ID_Avaliacao ", conn);

        comm.Parameters.AddWithValue("@Fator_Ponderacao", Fator_Ponderacao);
        comm.Parameters.AddWithValue("@Data", Data);
        comm.Parameters.AddWithValue("@ID_Avaliacao", ID_Avaliacao);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    [WebMethod]
    public string updateAvaliacaoAluno(string ID_Avaliacao, string ID_Aluno, string Nota, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "UPDATE Avaliacao_Aluno " +
            "SET Nota = @Nota " +
            "WHERE ID_Aluno = @ID_Aluno and ID_Avaliacao = @ID_Avaliacao", conn);

        comm.Parameters.AddWithValue("@Nota", Nota);
        comm.Parameters.AddWithValue("@ID_Aluno", ID_Aluno);
        comm.Parameters.AddWithValue("@ID_Avaliacao", ID_Avaliacao);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    /* [WebMethod]
     public string updateAlunoCurso(string ID_Aluno, string ID_Curso, string sGrau)
     {
         // Saber qual a base de dados a usar
         sDBname = sGrau;

         string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
         SqlConnection conn = new SqlConnection(linkString);

         SqlCommand comm = new SqlCommand(
             "UPDATE Aluno " +
             "SET ID_Curso = @ID_Curso " +
             "WHERE ID = @ID_Aluno", conn);

         comm.Parameters.AddWithValue("@ID_Curso", ID_Curso);
         comm.Parameters.AddWithValue("@ID_Aluno", ID_Aluno);


         SqlDataReader rdr;
         string sResposta = "NO_OK";

         try
         {
             conn.Open();
             rdr = comm.ExecuteReader();
             conn.Close();
             sResposta = "OK";

         }
         catch (Exception e)
         {
             sResposta = "NO_OK";
         }

         return jsonResposta(sResposta);

     }
     */
    [WebMethod]
    public string updateDisciplinaCurso(string NomeDisc, string CodigoDisc, string CritDisc, string DescDisc, string ECTSDisc, string ID_Curso, string ID_Disc, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "UPDATE Disciplina " +
            "SET Nome = @NomeDisc, Codigo = @CodigoDisc, Criterios = @CritDisc, Descricao = @DescDisc, ECTS = @ECTSDisc, ID_Curso = @ID_Curso " +
            "WHERE ID = @ID_Disc", conn);

        comm.Parameters.AddWithValue("@NomeDisc", NomeDisc);
        comm.Parameters.AddWithValue("@CodigoDisc", CodigoDisc);
        comm.Parameters.AddWithValue("@CritDisc", CritDisc);
        comm.Parameters.AddWithValue("@DescDisc", DescDisc);
        comm.Parameters.AddWithValue("@ECTSDisc", ECTSDisc);
        comm.Parameters.AddWithValue("@ID_Curso", ID_Curso);
        comm.Parameters.AddWithValue("@ID_Disc", ID_Disc);


        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    [WebMethod]
    public string updateCurso(string NomeCurso, string CodigoCurso, string ECTSCurso, string DescCurso, string ID_Curso, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "UPDATE Curso "+
            "SET Nome = @NomeCurso, Codigo = @CodigoCurso, Descricao = @DescCurso, ECTS = @ECTSCurso " +
            "WHERE ID = @ID_Curso", conn);

        comm.Parameters.AddWithValue("@NomeCurso", NomeCurso);
        comm.Parameters.AddWithValue("@CodigoCurso", CodigoCurso);
        comm.Parameters.AddWithValue("@ECTSCurso", ECTSCurso);
        comm.Parameters.AddWithValue("@DescCurso", DescCurso);
        comm.Parameters.AddWithValue("@ID_Curso", ID_Curso);


        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();
            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    [WebMethod]
    public string updateInscricaoAlunoDisciplina(string ID_Inscricao, string Nota, string sGrau)
    {
        // Saber qual a base de dados a usar
        sDBname = sGrau;

        string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
        SqlConnection conn = new SqlConnection(linkString);

        SqlCommand comm = new SqlCommand(
            "UPDATE Inscricao_Aluno_Disciplina " +
            "SET Nota = @Nota " +
            "WHERE ID = @ID_Inscricao "+
            "UPDATE Inscricao_Aluno_Disciplina " +
            "SET ID_Estado = " +
                "case when Nota >= 10 then 1 " +
                "else 2 end " +
            "WHERE ID = @ID_Inscricao", conn);

        comm.Parameters.AddWithValue("@ID_Inscricao", ID_Inscricao);
        comm.Parameters.AddWithValue("@Nota", Nota);

        SqlDataReader rdr;
        string sResposta = "NO_OK";

        try
        {
            conn.Open();
            rdr = comm.ExecuteReader();
            conn.Close();

            sResposta = "OK";

        }
        catch (Exception e)
        {
            sResposta = "NO_OK";
        }

        return jsonResposta(sResposta);

    }

    // Prepara a resposta (OK ou NO_OK) para devolver ao WebService, informando se a operação correu com ou sem sucesso;
    private string jsonResposta(string sResposta)
    {
        // Devolver sob a forma de uma lista para que seja feito o parser correto do JSON
        var listResposta = new List<Resposta>();
        Resposta resposta = new Resposta() { Resultado = sResposta };
        listResposta.Add(resposta);


        var serializer = new JavaScriptSerializer();
        var serializedResult = serializer.Serialize(listResposta);

        return serializedResult;
    }


    // --------------------------------------------------------------------------------------------------------------------
    // Classes

    public class Resposta
    {
        public string Resultado { get; set; }
    }

    public class Curso
    {
        public int Codigo { get; set; }
        public string Descricao { get; set; }
    }

    public class CursoInformacao
    {
        public string Nome { get; set; }
        public int ECTS { get; set; }
        public int Codigo { get; set; }
        public string Descricao { get; set; }
    }

    public class CadeiraInformacao
    {
        public string Nome { get; set; }
        public int Codigo { get; set; }
        public string Criterios { get; set; }
        public string Descricao { get; set; }
        public int ECTS { get; set; }
    }

    public class AvaliacaoInformacao
    {
        public int FatorPonderacao { get; set; }
        public string Data { get; set; }
    }

    public class TipoAvaliacao
    {
        public int ID { get; set; }
        public string Designacao { get; set; }
    }

    public class Cadeira
    {
        public int ID { get; set; }
        public int Codigo { get; set; }
        public string Nome {get; set; }
    }

    public class Avaliacao
    {
        public int ID { get; set; }
        public string Data { get; set; }
        public string Designacao { get; set; }
        public int Nota { get; set; }
    }

    public class NotaDeAvaliacaoDeCadeira
    {
        public int ID { get; set; }
        public double Nota { get; set; }
    }

    public class ClassificacaoDeCadeira
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Nota { get; set; }
    }

    public class AvaliacaoDeAlunoEmCadeira
    {
        public string Data { get; set; }
        public string Designacao { get; set; }
        public double Nota { get; set; }
    }

    // --------------------------------------------------------------------------------------------------------------------

}
