-------------------------------------------------------------------------------
-- USE DBProject: Changes the database context to the DBProject database.
--
USE Licenciatura
--
-------------------------------------------------------------------------------
--
-------------------------------------------------------------------------------
------------  INSERT SOME DATA INTO TABLES  -----------------------------------
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
------------- Transaction mode: explicit transactions
-------------------------------------------------------------------------------


BEGIN TRAN

-- Curso 1 : Licenciatura de EI
INSERT INTO Curso(Nome, Codigo, ECTS, Descricao)
VALUES ('E.I', 112, 180, 'Engenharia Inform�tica - Licenciatura');
-- Curso 2 : Licenciatura de IW
INSERT INTO Curso(Nome, Codigo, ECTS, Descricao)
VALUES ('I.W', 117, 180, 'Inform�tica Web - Licenciatura');

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- licenciatura de Maria
INSERT INTO Aluno(ID_Curso)
VALUES (1);

-- licenciatura de Joao
INSERT INTO Aluno(ID_Curso)
VALUES (1);

-- licenciatura de Bernardo
INSERT INTO Aluno(ID_Curso)
VALUES (2);


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Estado 1 : Aprovado
INSERT INTO Estado(Designacao)
VALUES ('Aprovado');

-- Estado 2 : Reprovado
INSERT INTO Estado(Designacao)
VALUES ('Reprovado');

-- Estado 3 : A decorrer
INSERT INTO Estado(Designacao)
VALUES ('A decorrer');


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Tipo_Avaliacao 1 : Frequ�ncia
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Frequ�ncia');

-- Tipo_Avaliacao 2 : Exerc�cios
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Exerc�cios');

-- Tipo_Avaliacao 3 : Cont�nua (Projeto)
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Cont�nua');


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Disciplina 1 (SD de EI)
INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso)
VALUES ('Sistemas Distribuidos', 445, 'Variados', 'Disciplina de SD', 6, 1);

-- Disciplina 2 (Projeto de EI)
INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso)
VALUES ('Projeto', 778, 'Entregar um projeto', 'Disciplina de Projeto', 12, 1);

-- Disciplina 3 (SD de IW)
INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso)
VALUES ('Sistemas Distribuidos', 335, 'Variados', 'Disciplina de SD', 6, 2);

-- Disciplina 4 (POO de IW)
INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso)
VALUES ('Prog. Orientada a Objetos', 337, 'Objetos', 'Disciplina de POO', 6, 2);


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Inscricao_Aluno_Disciplina 1 : Maria em Projeto (Aprovada, com 18)
INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, Nota, ID_Estado)
VALUES (1, 2, 2018, 18, 1);

-- Inscricao_Aluno_Disciplina 2 : Jo�o em Projeto (A decorrer)
INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado)
VALUES (2, 2, 2019, 3);

-- Inscricao_Aluno_Disciplina 3 : Jo�o em SD (de EI) (A decorrer)
INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado)
VALUES (2, 1, 2019, 3);

-- Inscricao_Aluno_Disciplina 4 : Bernardo em SD (de IW) (A decorrer)
INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado)
VALUES (3, 3, 2019, 3);

-- Inscricao_Aluno_Disciplina 5 : Bernardo em POO (A decorrer)
INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado)
VALUES (3, 4, 2019, 3);

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Avaliacao 1: Projeto
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (100, '07-07-2018', 3, 2);

-- Avaliacao 2: 1� Teste (25% da nota) de SD de EI
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (25, '05-04-2019', 1, 1);

-- Avaliacao 3: Exercicio 1 (5% da nota) de SD de EI
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (5, '10-05-2019', 2, 1);

-- Avaliacao 4: 1� Teste (50% da nota) de POO
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (50, '03-04-2019', 1, 4);

-- Avaliacao 5: 2� Teste (25% da nota) de SD de EI
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (25, '27-05-2019', 1, 1);

-- Avaliacao 6: 1� Teste (25% da nota) de SD de IW
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (25, '27-05-2019', 1, 3);

-- Avaliacao 7: 2� Teste (25% da nota) de SD de IW
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (25, '27-05-2019', 1, 3);

-- Avaliacao 8: Exercicio 1 (5% da nota) de SD de IW
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (5, '10-05-2019', 2, 3);

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Avaliacao_Aluno: 18 de Maria em Projeto
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (1, 1, 18);

-- Avaliacao_Aluno: 10 de Joao em 1� Teste de SD
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (2, 2, 10.2);

-- Avaliacao_Aluno: 12 de Joao em 2� teste de SD
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (5, 2, 12.3);

-- Avaliacao_Aluno: 12 de Joao em Exercicio 1 de SD
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (3, 2, 12);

-- Avaliacao_Aluno: 16 de Bernardo em 1� Teste de POO
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (4, 3, 16.4);

-- Avaliacao_Aluno: 12 de Bernardo em 1� Teste de SD
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (6, 3, 12.1);

-- Avaliacao_Aluno: 14 de Bernardo em Exercicio 1 de SD
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (8, 3, 14);

-- Avaliacao_Aluno: 17 de Bernardo em 2� teste de SD
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (7, 3, 17.9);

COMMIT;