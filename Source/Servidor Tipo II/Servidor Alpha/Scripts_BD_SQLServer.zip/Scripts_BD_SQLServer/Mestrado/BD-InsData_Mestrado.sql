-------------------------------------------------------------------------------
-- USE DBProject: Changes the database context to the DBProject database.
--
USE Mestrado
--
-------------------------------------------------------------------------------
--
-------------------------------------------------------------------------------
------------  INSERT SOME DATA INTO TABLES  -----------------------------------
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
------------- Transaction mode: explicit transactions
-------------------------------------------------------------------------------


BEGIN TRAN

-- Curso  : Mestrado de EI
INSERT INTO Curso(Nome, Codigo, ECTS, Descricao)
VALUES ('E.I', 112, 120, 'Engenharia Inform�tica - Mestrado');

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- mestrado de Maria
INSERT INTO Aluno(ID_Curso)
VALUES (1);

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Estado 1 : Aprovado
INSERT INTO Estado(Designacao)
VALUES ('Aprovado');

-- Estado 2 : Reprovado
INSERT INTO Estado(Designacao)
VALUES ('Reprovado');

-- Estado 3 : A decorrer
INSERT INTO Estado(Designacao)
VALUES ('A decorrer');


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Tipo_Avaliacao 1 : Frequ�ncia
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Frequ�ncia');

-- Tipo_Avaliacao 2 : Exerc�cios
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Exerc�cios');

-- Tipo_Avaliacao 3 : Cont�nua (Projeto)
INSERT INTO Tipo_Avaliacao(Designacao)
VALUES ('Cont�nua');


COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Disciplina 1 : Qualidade de Softawre
INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso)
VALUES ('Qualidade de Software', 472, 'Muitos', 'Disciplina de QS', 6, 1);

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Inscricao_Aluno_Disciplina 1 : Maria em Qualidade de Software
INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado)
VALUES (1, 1, 2019, 3);

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Avaliacao 1: 1� Teste (50% da nota) de QS
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (50, '04-04-2019', 1, 1);

-- Avaliacao 2: 2� Teste (50% da nota) de QS
INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina)
VALUES (50, '05-06-2019', 1, 1);

COMMIT;

-------------------------------------------------------------------------------

BEGIN TRAN

-- Avaliacao_Aluno: 10.5 de Maria em 1� Teste de QS
INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota)
VALUES (1, 1, 10.5);

COMMIT;