<?php
	$username = "root";
	$password = "Biba_g123";
	$servername = "localhost";
	$dbname = "Licenciatura";

	$conn = mysqli_connect($servername,$username,$password);
	if (!$conn) {
		die ("Connection failed: " . mysqli_connect_error());
	}

	$sql = "create database ".$dbname;
	if (mysqli_query($conn,$sql)) {
		echo "Base de dados criada com SUCESSO!";
	} else {
		echo "Error creating database: " . mysqli_error($conn);
	}

	mysqli_close($conn);
	$conn = mysqli_connect($servername,$username,$password,$dbname);
	if (!$conn) {
		die ("Connection failed: " . mysqli_connect_error());
	}

	$sql = "ALTER DATABASE ". $dbname ." CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci";
	if (mysqli_query($conn,$sql)) {
		echo "Base de dados alterada com SUCESSO!";
	} else {
		echo "Error altering database: " . mysqli_error($conn);
	}

	$sql = "create table Curso ( 
	ID integer not null auto_increment primary key, 
	Nome varchar(30) not null,
	ECTS integer not null, 
	Codigo integer not null,
	Descricao varchar(100) not null
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	$sql = "create table Aluno ( 
	ID integer not null auto_increment primary key, 
	ID_Curso integer not null,
	foreign key (ID_Curso) references Curso(ID) on update cascade on delete no action
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}	
	
	$sql = "create table Disciplina ( 
	ID integer not null auto_increment primary key, 
	Nome varchar(30) not null, 
	Codigo integer not null,
	Criterios varchar(300) not null,
	Descricao varchar(300) not null,
	ECTS integer not null,
	ID_Curso integer not null,
	foreign key (ID_Curso) references Curso(ID) on update cascade on delete cascade
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	$sql = "create table Estado ( 
	ID integer not null auto_increment primary key,
	Designacao varchar(30) not null
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	$sql = "create table Inscricao_Aluno_Disciplina ( 
	ID integer not null auto_increment primary key,
	ID_Aluno integer not null,
	ID_Disciplina integer not null, 
	Ano integer not null, 
	Nota integer,
	ID_Estado integer not null,
	foreign key (ID_Aluno) references Aluno(ID) on update cascade on delete cascade,
	foreign key (ID_Disciplina) references Disciplina(ID) on update no action on delete no action,
	foreign key (ID_Estado) references Estado(ID) on update cascade on delete no action
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	$sql = "create table Tipo_Avaliacao ( 
	ID integer not null auto_increment primary key, 
	Designacao varchar(30) not null
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	$sql = "create table Avaliacao ( 
	ID integer not null auto_increment primary key,
	Fator_Ponderacao int not null,
	Data char(10) not null,
	ID_Tipo_Avaliacao integer not null, 
	ID_Disciplina integer not null, 
	foreign key (ID_Tipo_Avaliacao) references Tipo_Avaliacao(ID) on update cascade on delete cascade,
	foreign key (ID_Disciplina) references Disciplina(ID) on update cascade on delete no action
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	$sql = "create table Avaliacao_Aluno ( 
	ID_Avaliacao integer not null, 
	ID_Aluno integer not null,
	Nota float not null,
	primary key (ID_Avaliacao,ID_Aluno), 
	foreign key (ID_Avaliacao) references Avaliacao(ID) on update no action on delete no action,
	foreign key (ID_Aluno) references Aluno(ID) on update cascade on delete cascade
	)";

	if (mysqli_query($conn,$sql)) {
		echo "Tabela criada com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

?>