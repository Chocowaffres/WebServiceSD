	<?php
	$username = "root";
	$password = "Biba_g123";
	$servername = "localhost";
	$dbname = "Licenciatura";

	$conn = mysqli_connect($servername,$username,$password,$dbname);
	if (!$conn) {
		die ("Connection failed: " . mysqli_connect_error());
	}


// Curso

	// Curso 1 : Licenciatura de EI
	$sql = "insert into Curso (Nome, Codigo, ECTS, Descricao) values ('E.I', 112, 180, 'Engenharia Informática - Licenciatura')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Curso 2 : Licenciatura de IW
	$sql = "insert into Curso (Nome, Codigo, ECTS, Descricao) values ('I.W', 117, 180, 'Informática Web - Licenciatura')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Aluno

	// Licenciatura de Maria
	$sql = "insert into Aluno (ID_Curso) values (1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Licenciatura de Joao
	$sql = "insert into Aluno (ID_Curso) values (1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Licenciatura de Bernardo
	$sql = "insert into Aluno (ID_Curso) values (2)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Disciplina

	// Disciplina 1 (SD de EI)
	$sql = "insert into Disciplina(Nome,Codigo,Criterios,Descricao, ECTS,ID_Curso) values ('Sistemas Distribuidos',445,'Variados','Disciplina de SD',6,1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Disciplina 2 (Projeto de EI)
	$sql = "insert into Disciplina(Nome,Codigo,Criterios,Descricao, ECTS,ID_Curso) values ('Projeto', 778, 'Entregar um projeto', 'Disciplina de Projeto', 12, 1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Disciplina 3 (SD de IW)
	$sql = "insert into Disciplina(Nome,Codigo,Criterios,Descricao, ECTS,ID_Curso) values ('Sistemas Distribuidos', 335, 'Variados', 'Disciplina de SD', 6, 2)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Disciplina 4 (POO de IW)
	$sql = "insert into Disciplina(Nome,Codigo,Criterios,Descricao, ECTS,ID_Curso) values ('Prog. Orientada a Objetos', 337, 'Objetos', 'Disciplina de POO', 6, 2)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Estado

	// Estado 1 : Aprovado
	$sql = "insert into Estado(Designacao) values ('Aprovado')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Estado 2 : Reprovado
	$sql = "insert into Estado(Designacao) values ('Reprovado')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Estado 2 : A decorrer
	$sql = "insert into Estado(Designacao) values ('A decorrer')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Inscricao_Aluno_Disciplina

	// Inscricao_Aluno_Disciplina 1 : Maria em Projeto (Aprovada, com 18)
	$sql = "insert into Inscricao_Aluno_Disciplina(ID_Aluno,ID_Disciplina,Ano,Nota,ID_Estado) values (1,2,2018,18,1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Inscricao_Aluno_Disciplina 2 : João em Projeto (A decorrer)
	$sql = "insert into Inscricao_Aluno_Disciplina(ID_Aluno,ID_Disciplina,Ano,ID_Estado) values (2,2,2019,3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Inscricao_Aluno_Disciplina 3 : João em SD (de EI) (A decorrer)
	$sql = "insert into Inscricao_Aluno_Disciplina(ID_Aluno,ID_Disciplina,Ano,ID_Estado) values (2,1,2019,3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Inscricao_Aluno_Disciplina 4 : Bernardo em SD (de IW) (A decorrer)
	$sql = "insert into Inscricao_Aluno_Disciplina(ID_Aluno,ID_Disciplina,Ano,ID_Estado) values (3,3,2019,3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Inscricao_Aluno_Disciplina 5 : Bernardo em POO (A decorrer)
	$sql = "insert into Inscricao_Aluno_Disciplina(ID_Aluno,ID_Disciplina,Ano,ID_Estado) values (3,4,2019,3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Tipo_Avaliacao

	//  Tipo_Avaliacao 1 : Frequência
	$sql = "insert into Tipo_Avaliacao(Designacao) values ('Frequência')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Tipo_Avaliacao 2 : Exercícios
	$sql = "insert into Tipo_Avaliacao(Designacao) values ('Exercícios')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Tipo_Avaliacao 3 :  Contínua (Projeto)
	$sql = "insert into Tipo_Avaliacao(Designacao) values ('Contínua')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}
	

// Avaliacao

	//  Avaliacao 1: Projeto
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (100, '07-07-2018', 3, 2)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao 2: 1º Teste (25% da nota) de SD de E.I
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (25, '05-04-2019', 1, 1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao 3: Exercicio 1 (5% da nota) de SD de E.I
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (5, '10-05-2019', 2, 1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao 4: 1º Teste (50% da nota) de POO
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (50, '03-04-2019', 1, 4)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao 5: 2º Teste (25% da nota) de SD de E.I
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (25, '27-05-2019', 1, 1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao 6: 1º Teste (25% da nota) de SD de I.W
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (25, '05-04-2019', 1, 3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao 7: 2º Teste (25% da nota) de SD de I.W
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (25, '27-05-2019', 1, 3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao 8: Exercicio 1 (5% da nota) de SD de I.W
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (5, '10-05-2019', 2, 3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Avaliacao_Aluno

	//  Avaliacao_Aluno: 18 de Maria em Projeto
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (1, 1, 18)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao_Aluno: 10 de Joao em 1º Teste de SD
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (2, 2, 10.2)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao_Aluno: 12 de Joao em 2º teste de SD
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (5, 2, 12.3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao_Aluno: 12 de Joao em Exercicio 1 de SD
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (3, 2, 12)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao_Aluno: 16 de Bernardo em 1º Teste de POO
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (4, 3, 16.4)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao_Aluno: 12 de Bernardo em 1º Teste de SD
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (6, 3, 12.1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao_Aluno: 14 de Bernardo em Exercicio 1 de SD
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (8, 3, 14)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Avaliacao_Aluno: 17 de Bernardo em 2º teste de SD
	$sql = "insert into Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) values (7, 3, 17.9)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


?>