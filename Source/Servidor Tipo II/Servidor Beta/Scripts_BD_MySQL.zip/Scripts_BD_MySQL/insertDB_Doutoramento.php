	<?php
	$username = "root";
	$password = "Biba_g123";
	$servername = "localhost";
	$dbname = "Doutoramento";

	$conn = mysqli_connect($servername,$username,$password,$dbname);
	if (!$conn) {
		die ("Connection failed: " . mysqli_connect_error());
	}


// Curso

	// Curso 1 : Doutoramento de BM
	$sql = "insert into Curso (Nome, Codigo, ECTS, Descricao) values ('B.M', 447, 240, 'Biomédicas - Doutoramento')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Aluno

	// Doutoramento de José em BM
	$sql = "insert into Aluno (ID_Curso) values (1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Disciplina

	// Disciplina 1 (Dissertação de BM)
	$sql = "insert into Disciplina(Nome,Codigo,Criterios,Descricao, ECTS,ID_Curso) values ('Dissertação', 55, 'Crescer', 'Descobrir', 240, 1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Estado

	// Estado 1 : Aprovado
	$sql = "insert into Estado(Designacao) values ('Aprovado')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Estado 2 : Reprovado
	$sql = "insert into Estado(Designacao) values ('Reprovado')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	// Estado 2 : A decorrer
	$sql = "insert into Estado(Designacao) values ('A decorrer')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Inscricao_Aluno_Disciplina

	// Inscricao_Aluno_Disciplina 1 : José em Dissertacao (A decorrer)
	$sql = "insert into Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado) values (1, 1, 2019, 3)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}


// Tipo_Avaliacao

	//  Tipo_Avaliacao 1 : Frequência
	$sql = "insert into Tipo_Avaliacao(Designacao) values ('Frequência')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Tipo_Avaliacao 2 : Exercícios
	$sql = "insert into Tipo_Avaliacao(Designacao) values ('Exercícios')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

	//  Tipo_Avaliacao 3 :  Contínua (Projeto)
	$sql = "insert into Tipo_Avaliacao(Designacao) values ('Contínua')";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}
	

// Avaliacao

	//  Avaliacao 1: Dissertacao
	$sql = "insert into Avaliacao(Fator_Ponderacao,Data,ID_Tipo_Avaliacao,ID_Disciplina) values (100, '07-07-2019', 3, 1)";
	if (mysqli_query($conn,$sql)) {
		echo "Inserido com SUCESSO!";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
	}

?>