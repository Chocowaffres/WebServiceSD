<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['NomeDisc']) && !empty($_POST['Codigo']) && !empty($_POST['Criterios']) && !empty($_POST['Descricao']) && !empty($_POST['NumbECTS']) && !empty($_POST['NumCurso']) && !empty($_POST['Grau']) ) {

			$nome = $_POST['NomeDisc'];
			$codigo = $_POST['Codigo'];
			$criterios = $_POST['Criterios'];
			$numbECTS = $_POST['NumbECTS'];
			$descricao = $_POST['Descricao'];
			$numCurso = $_POST['NumCurso'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "INSERT INTO Disciplina(Nome, Codigo, Criterios, Descricao, ECTS, ID_Curso) " .
            		"VALUES(? , ? , ? , ?, ?, ?)";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('sissii', $nome ,$codigo, $criterios, $descricao, $numbECTS, $numCurso);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

