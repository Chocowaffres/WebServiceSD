w<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['ID_Avaliacao']) && !empty($_POST['ID_Aluno']) && !empty($_POST['Nota']) && !empty($_POST['Grau']) ) {

			$idAvaliacao = $_POST['ID_Avaliacao'];
			$idAluno = $_POST['ID_Aluno'];
			$nota = $_POST['Nota'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "UPDATE Avaliacao_Aluno " .
					"SET Nota = ? " .
            		"WHERE ID_Aluno = ? and ID_Avaliacao = ?";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('dii', $nota ,$idAluno, $idAvaliacao);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

