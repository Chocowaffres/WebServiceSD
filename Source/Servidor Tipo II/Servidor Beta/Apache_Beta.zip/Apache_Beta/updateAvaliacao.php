<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['ID_Avaliacao']) && !empty($_POST['Fator_Ponderacao']) && !empty($_POST['Data']) && !empty($_POST['Grau']) ) {

			$idAvaliacao = $_POST['ID_Avaliacao'];
			$fatorPonderacao = $_POST['Fator_Ponderacao'];
			$data = $_POST['Data'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "UPDATE Avaliacao " .
					"SET Fator_Ponderacao = ?, Data = ? " .
            		"WHERE ID = ?";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('dsi', $fatorPonderacao ,$data, $idAvaliacao);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

