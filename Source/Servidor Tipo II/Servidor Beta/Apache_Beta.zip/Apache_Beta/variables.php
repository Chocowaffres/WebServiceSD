<?php

	//GRANT ALL PRIVILEGES ON *.* TO 'SDAdmin'@'localhost' IDENTIFIED BY 'SD_test123';
	$username = "SDAdmin";
	$password = "SD_test123";
	$servername = "localhost";
	//$dbname = "Licenciatura";

?>