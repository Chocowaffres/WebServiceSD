<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['Fator_Ponderacao']) && !empty($_POST['Data']) && !empty($_POST['ID_Tipo_Avaliacao']) && !empty($_POST['ID_Disciplina']) && !empty($_POST['Grau']) ) {

			$fator = $_POST['Fator_Ponderacao'];
			$data = $_POST['Data'];
			$tipoAval = $_POST['ID_Tipo_Avaliacao'];
			$disciplina = $_POST['ID_Disciplina'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "INSERT INTO Avaliacao(Fator_Ponderacao, Data, ID_Tipo_Avaliacao, ID_Disciplina) " .
            		"VALUES(? , ? , ? , ?)";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('dsii', $fator ,$data, $tipoAval, $disciplina);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

