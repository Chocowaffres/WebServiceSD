<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['NomeCurso']) && !empty($_POST['Codigo']) && !empty($_POST['NumbECTS']) && !empty($_POST['Descricao']) && !empty($_POST['Grau'])) {

			$curso = $_POST['NomeCurso'];
			$codigo = $_POST['Codigo'];
			$numbECTS = $_POST['NumbECTS'];
			$descricao = $_POST['Descricao'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "INSERT INTO Curso(Nome, Codigo, ECTS, Descricao) " .
            		"VALUES(? , ? , ? , ?)";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('siis', $curso ,$codigo, $numbECTS, $descricao);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

