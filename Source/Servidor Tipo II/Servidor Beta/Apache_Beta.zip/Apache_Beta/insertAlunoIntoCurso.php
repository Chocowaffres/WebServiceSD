<?php

	function associaAlunoACurso($sNumCurso, $dbname) {
		include 'variables.php';

		$conn = new mysqli($servername,$username,$password,$dbname);
		if ($conn->connect_error) {
			die ("Connection failed: " . $conn->connect_error);
		}

		$query = "INSERT INTO Aluno(ID_Curso) " .
            	"VALUES( ? )";

		$stmt = $conn->prepare($query);
		$stmt->bind_param('i', $sNumCurso);
		if ( $stmt->execute() ) {
			$stmt->close();
			$conn->close();

			return 0;
		}
		else {
			$stmt->close();
			$conn->close();

			return -1;
		}
	}

	function getUltimoNumeroAluno($dbname) {
		include 'variables.php';

		$conn = new mysqli($servername,$username,$password,$dbname);
		if ($conn->connect_error) {
			die ("Connection failed: " . $conn->connect_error);
		}

		$query = "SELECT ID FROM Aluno ORDER BY ID DESC LIMIT 1";

		$stmt = $conn->prepare($query);
		$stmt->execute();

		$stmt->bind_result($id);

		if ( $stmt->fetch() ) {
			$stmt->close();
			$conn->close();
			
			return $id;
		}
		else {
			$stmt->close();
			$conn->close();
			
			return -1;
		}
	}

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												
		if ( !empty($_POST['ID_Curso']) && !empty($_POST['Grau']) ) {

			$numero = $_POST['ID_Curso'];
			$dbname = $_POST['Grau'];

			$resultado = associaAlunoACurso($numero, $dbname);

			$jsonData=array();
			if ($resultado == -1) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$id = getUltimoNumeroAluno($dbname);

				if ($id == -1) {
					$jsonDataTemp=array();
					$jsonDataTemp['Resultado']="NO OK";
					$jsonData[] = $jsonDataTemp;
					print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
				}
				else {
					$jsonDataTemp=array();
					$jsonDataTemp['Resultado']=$id;
					$jsonData[] = $jsonDataTemp;
					print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
				}
			}		
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

