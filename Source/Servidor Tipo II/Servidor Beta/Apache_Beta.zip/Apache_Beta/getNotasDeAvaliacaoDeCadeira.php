<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['ID']) && !empty($_POST['Grau']) ) {

			$id = $_POST['ID'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select AA.ID_Aluno, AA.Nota " .
					"From Avaliacao AV, Avaliacao_Aluno AA " .
					"where AV.ID = ? " .
					"and AA.ID_Avaliacao = AV.ID ";


			$stmt = $conn->prepare($query);
			$stmt->bind_param('i', $id);
			$stmt->execute();

			$stmt->bind_result($id_aluno, $nota);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['ID'] = $id_aluno;
				$jsonTempData['Nota'] = $nota;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

