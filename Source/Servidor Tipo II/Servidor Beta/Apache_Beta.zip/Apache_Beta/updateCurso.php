<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['NomeCurso']) && !empty($_POST['CodigoCurso']) 
			&& !empty($_POST['ECTSCurso']) && !empty($_POST['DescCurso']) 
			&& !empty($_POST['ID_Curso']) && !empty($_POST['Grau']) ) {

			$NomeCurso = $_POST['NomeCurso'];
			$CodigoCurso = $_POST['CodigoCurso'];
			$ECTSCurso = $_POST['ECTSCurso'];
			$DescCurso = $_POST['DescCurso'];
			$ID_Curso = $_POST['ID_Curso'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "UPDATE Curso " .
					"SET Nome = ?, Codigo = ?, Descricao = ?,
					ECTS = ? " .
            		"WHERE ID = ?";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('sisii', $NomeCurso, $CodigoCurso, $DescCurso, 
				$ECTSCurso, $ID_Curso);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

