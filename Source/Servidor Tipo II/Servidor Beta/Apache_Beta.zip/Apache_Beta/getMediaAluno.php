<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

		if ( !empty($_POST['Numero_Aluno']) && !empty($_POST['Grau']) ) {
			
			$numero = $_POST['Numero_Aluno'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select B.Nome, B.Curso as Curso, (A.Somatorio_Notas_Ponderadas / B.Somatorio_ECTS) as Média
			From (Select sum(D.ECTS * IAD.Nota) as Somatorio_Notas_Ponderadas
				from Aluno A, Disciplina D, Estado E, Inscricao_Aluno_Disciplina IAD
				where A.ID = (Select A1.ID
								From Aluno A1, Tipo_Aluno TA1
								where A1.Numero_Aluno = ?
								and TA1.Grau = 'Licenciatura'
								and A1.ID_Tipo_Aluno = TA1.ID
						
				)
				and IAD.ID_Aluno = A.ID
				and D.ID = IAD.ID_Disciplina
				and E.Designacao = 'Aprovado'
				and IAD.ID_Estado = E.ID) A
				,
				(Select P.Nome as Nome, C.Descricao as Curso, sum(D.ECTS) as Somatorio_ECTS
				from Aluno A, Disciplina D, Estado E, Inscricao_Aluno_Disciplina IAD, Pessoa P, Matricula M, Curso C
				where A.ID = (Select A1.ID
								From Aluno A1, Tipo_Aluno TA1
								where A1.Numero_Aluno = ?
								and TA1.Grau = 'Licenciatura'
								and A1.ID_Tipo_Aluno = TA1.ID
						
				)
				and IAD.ID_Aluno = A.ID
				and D.ID = IAD.ID_Disciplina
				and E.Designacao = 'Aprovado'
				and IAD.ID_Estado = E.ID
				and C.ID = A.ID_Curso
				and M.ID_Aluno = A.ID
				and P.ID = M.ID_Pessoa
				group by P.Nome, C.Descricao) B";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('ii', $numero, $numero);
			$stmt->execute();

			$stmt->bind_result($nome, $curso, $media);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['Nome'] = $nome;
				$jsonTempData['Curso'] = $curso;
				$jsonTempData['Media'] = $media;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

