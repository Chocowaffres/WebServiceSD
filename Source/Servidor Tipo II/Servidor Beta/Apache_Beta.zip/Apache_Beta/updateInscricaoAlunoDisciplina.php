<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['ID_Inscricao']) && !empty($_POST['Nota']) && !empty($_POST['Grau']) ) {

			$ID_Inscricao = $_POST['ID_Inscricao'];
			$Nota = $_POST['Nota'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "UPDATE Inscricao_Aluno_Disciplina " .
					"SET Nota = ? " .
            		"WHERE ID = ? ";
            		

			$stmt = $conn->prepare($query);
			$stmt->bind_param('ii', $Nota, $ID_Inscricao);
			if ( $stmt->execute() ) {
				$query = "UPDATE Inscricao_Aluno_Disciplina " .
					"SET ID_Estado =  " .
            			"case when Nota >= 10 then 1 " .
            			"else 2 end " .
            		"WHERE ID = ?";

            	$stmt = $conn->prepare($query);
            	$stmt->bind_param('i', $ID_Inscricao);

            	$jsonData=array();
            	if ( $stmt->execute() ){
            		$jsonDataTemp=array();
					$jsonDataTemp['Resultado']="OK";
					$jsonData[] = $jsonDataTemp;
					print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
            	}
            	else {
            		$jsonDataTemp=array();
					$jsonDataTemp['Resultado']="NO OK";
					$jsonData[] = $jsonDataTemp;
					print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));	
            	}
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

