<?php

	if ($_SERVER['REQUEST_METHOD'] == 'GET') {
			
			$dbname = "Licenciatura";

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select * From Tipo_Avaliacao";

			$stmt = $conn->prepare($query);
			$stmt->execute();

			$stmt->bind_result($id, $designacao);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['ID'] = $id;
				$jsonTempData['Designacao'] = $designacao;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));
	}
	else {
		exit;
	}
	
?>

