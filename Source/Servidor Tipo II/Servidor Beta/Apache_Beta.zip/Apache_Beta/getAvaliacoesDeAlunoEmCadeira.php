<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

		if ( !empty($_POST['Numero_Aluno']) && !empty($_POST['ID_Cadeira']) && !empty($_POST['Grau']) ) {
			
			$numero = $_POST['Numero_Aluno'];
			$cadeira = $_POST['ID_Cadeira'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select AV.Data, TA.Designacao, AA.Nota
				from Avaliacao AV, Aluno A, Disciplina D, Tipo_Avaliacao TA, Avaliacao_Aluno AA
				where A.ID = (Select A1.ID
								From Aluno A1
								where A1.ID = ?
				)
				and D.ID = (Select D1.ID
								From Disciplina D1
								where D1.ID = ?
								and D1.ID_Curso = A.ID_Curso
				)
				and AV.ID_Disciplina =  D.ID
				and TA.ID = AV.ID_Tipo_Avaliacao
				and AA.ID_Aluno = A.ID
				and AA.ID_Avaliacao = AV.ID
				order by AV.Data ASC";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('ii', $numero, $cadeira);
			$stmt->execute();

			$stmt->bind_result($data, $designacao, $nota);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['Designacao'] = $designacao;
				$jsonTempData['Nota'] = $nota;
				$jsonTempData['Data'] = $data;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

