<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {											

		if ( !empty($_POST['Curso']) && !empty($_POST['Grau']) ) {

			$curso = $_POST['Curso'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select D.ID, D.Codigo, D.Nome " .
					"From Curso C, Disciplina D " .
					"Where C.Descricao = ? " .
					"and D.ID_Curso = C.ID";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('s', $curso);
			$stmt->execute();

			$stmt->bind_result($id, $codigo, $nome);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['ID'] = $id;
				$jsonTempData['Codigo'] = $codigo;
				$jsonTempData['Nome'] = $nome;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

