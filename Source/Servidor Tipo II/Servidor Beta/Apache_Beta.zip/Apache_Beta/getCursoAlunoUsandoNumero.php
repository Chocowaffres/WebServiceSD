<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

		if ( !empty($_POST['Numero_Aluno'])  && !empty($_POST['Grau']) ) {
			
			$numero = $_POST['Numero_Aluno'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select C.Descricao " .
            "From Aluno A, Curso C " .
            "where A.ID_Curso = C.ID " .
            "and A.ID = ? ";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('i', $numero);
			$stmt->execute();

			$stmt->bind_result($designacao);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['Descricao'] = $designacao;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

