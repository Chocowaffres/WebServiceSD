<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												
		if ( !empty($_POST['Grau']) ) {

			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select C.ID, C.Descricao " .
					"From Curso C ";

			$stmt = $conn->prepare($query);
			$stmt->execute();

			$stmt->bind_result($codigo, $descricao);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['Codigo'] = $codigo;
				$jsonTempData['Descricao'] = $descricao;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));			
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

