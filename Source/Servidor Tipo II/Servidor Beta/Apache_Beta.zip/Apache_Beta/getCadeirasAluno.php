<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

		if ( !empty($_POST['Numero_Aluno']) && !empty($_POST['Grau']) ) {
			
			$numero = $_POST['Numero_Aluno'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "Select D.ID, D.Nome as Disciplina, " .
					"case ".
						"when E.Designacao = 'A decorrer' then 'Em avaliação' ".
			        	"else CONVERT(IAD.Nota, char(2)) ".
				    "end as Nota ".
					"from Aluno A, Disciplina D, Inscricao_Aluno_Disciplina IAD, Estado E " .
					"where A.ID = (Select A1.ID " .
									"From Aluno A1 " .
									"where A1.ID = ? ".
									
					") ".
					"and IAD.ID_Aluno = A.ID " .
					"and IAD.ID_Disciplina = D.ID ".
					"and IAD.ID_Estado = E.ID";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('i', $numero);
			$stmt->execute();

			$stmt->bind_result($id, $nome, $nota);

			$jsonData = array();
			while($stmt->fetch()) {
				$jsonTempData = array();
				$jsonTempData['ID'] = $id;
				$jsonTempData['Nome'] = $nome;
				$jsonTempData['Nota'] = $nota;

				$jsonData[] = $jsonTempData;
			}
			
			$stmt->close();
			$conn->close();

			print_r(json_encode( $jsonData, JSON_UNESCAPED_UNICODE ));
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

