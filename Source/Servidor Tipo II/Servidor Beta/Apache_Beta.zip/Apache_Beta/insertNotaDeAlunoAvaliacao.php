<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['ID_Avaliacao']) && !empty($_POST['ID_Aluno']) && !empty($_POST['Nota']) && !empty($_POST['Grau']) ) {

			$idAval = $_POST['ID_Avaliacao'];
			$idAluno = $_POST['ID_Aluno'];
			$nota = $_POST['Nota'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "INSERT INTO Avaliacao_Aluno(ID_Avaliacao, ID_Aluno, Nota) " .
            		"VALUES(? , ? , ?)";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('iid', $idAval ,$idAluno, $nota);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

