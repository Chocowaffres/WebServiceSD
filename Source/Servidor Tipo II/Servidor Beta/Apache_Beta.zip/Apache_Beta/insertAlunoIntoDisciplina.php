<?php

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {												

		if ( !empty($_POST['NumAluno']) && !empty($_POST['NumDisc']) && !empty($_POST['Ano']) && !empty($_POST['Estado']) && !empty($_POST['Grau']) ) {

			$numAluno = $_POST['NumAluno'];
			$numDisc = $_POST['NumDisc'];
			$ano = $_POST['Ano'];
			$estado = $_POST['Estado'];
			$dbname = $_POST['Grau'];

			include 'variables.php';

			$conn = new mysqli($servername,$username,$password,$dbname);
			if ($conn->connect_error) {
				die ("Connection failed: " . $conn->connect_error);
			}

			$query = "INSERT INTO Inscricao_Aluno_Disciplina(ID_Aluno, ID_Disciplina, Ano, ID_Estado) " .
            		"VALUES(? , ? , ? , ?)";

			$stmt = $conn->prepare($query);
			$stmt->bind_param('iiii', $numAluno ,$numDisc, $ano, $estado);

			$jsonData=array();
			if ( $stmt->execute() ) {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
			else {
				$jsonDataTemp=array();
				$jsonDataTemp['Resultado']="NO OK";
				$jsonData[] = $jsonDataTemp;
				print_r(json_encode($jsonData, JSON_UNESCAPED_UNICODE ));
			}
	
			$stmt->close();
			$conn->close();
		}
		else {
			exit;
		}	
	}
	else {
		exit;
	}
	
?>

