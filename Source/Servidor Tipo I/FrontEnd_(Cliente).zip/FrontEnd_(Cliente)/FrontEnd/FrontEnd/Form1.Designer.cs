﻿namespace FrontEnd
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.PesquisaIntermediaListBox = new System.Windows.Forms.ListBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.PesquisaAlunoButton = new System.Windows.Forms.Button();
			this.Nome_AlunoRB = new System.Windows.Forms.RadioButton();
			this.Num_AlunoRB = new System.Windows.Forms.RadioButton();
			this.PesquisaAlunoTB = new System.Windows.Forms.TextBox();
			this.PesquisaAlunoLabel = new System.Windows.Forms.Label();
			this.PesquisaCadeiraCurso = new System.Windows.Forms.GroupBox();
			this.listaCadeiras = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.listaCursos = new System.Windows.Forms.ComboBox();
			this.PesquisaAvaliações = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.insertButton = new System.Windows.Forms.Button();
			this.PesquisaFinalListBox = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox2.SuspendLayout();
			this.PesquisaCadeiraCurso.SuspendLayout();
			this.SuspendLayout();
			// 
			// PesquisaIntermediaListBox
			// 
			this.PesquisaIntermediaListBox.FormattingEnabled = true;
			this.PesquisaIntermediaListBox.Location = new System.Drawing.Point(320, 41);
			this.PesquisaIntermediaListBox.Name = "PesquisaIntermediaListBox";
			this.PesquisaIntermediaListBox.Size = new System.Drawing.Size(258, 316);
			this.PesquisaIntermediaListBox.TabIndex = 3;
			this.PesquisaIntermediaListBox.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox_DoubleClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.PesquisaAlunoButton);
			this.groupBox2.Controls.Add(this.Nome_AlunoRB);
			this.groupBox2.Controls.Add(this.Num_AlunoRB);
			this.groupBox2.Controls.Add(this.PesquisaAlunoTB);
			this.groupBox2.Controls.Add(this.PesquisaAlunoLabel);
			this.groupBox2.Location = new System.Drawing.Point(12, 12);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(284, 142);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Pesquisa Aluno";
			// 
			// PesquisaAlunoButton
			// 
			this.PesquisaAlunoButton.Location = new System.Drawing.Point(107, 101);
			this.PesquisaAlunoButton.Name = "PesquisaAlunoButton";
			this.PesquisaAlunoButton.Size = new System.Drawing.Size(75, 23);
			this.PesquisaAlunoButton.TabIndex = 5;
			this.PesquisaAlunoButton.Text = "Pesquisar";
			this.PesquisaAlunoButton.UseVisualStyleBackColor = true;
			this.PesquisaAlunoButton.Click += new System.EventHandler(this.PesquisaAlunoButton_Click);
			// 
			// Nome_AlunoRB
			// 
			this.Nome_AlunoRB.AutoSize = true;
			this.Nome_AlunoRB.Location = new System.Drawing.Point(171, 63);
			this.Nome_AlunoRB.Name = "Nome_AlunoRB";
			this.Nome_AlunoRB.Size = new System.Drawing.Size(53, 17);
			this.Nome_AlunoRB.TabIndex = 6;
			this.Nome_AlunoRB.TabStop = true;
			this.Nome_AlunoRB.Text = "Nome";
			this.Nome_AlunoRB.UseVisualStyleBackColor = true;
			// 
			// Num_AlunoRB
			// 
			this.Num_AlunoRB.AutoSize = true;
			this.Num_AlunoRB.Checked = true;
			this.Num_AlunoRB.Location = new System.Drawing.Point(80, 64);
			this.Num_AlunoRB.Name = "Num_AlunoRB";
			this.Num_AlunoRB.Size = new System.Drawing.Size(62, 17);
			this.Num_AlunoRB.TabIndex = 5;
			this.Num_AlunoRB.TabStop = true;
			this.Num_AlunoRB.Text = "Número";
			this.Num_AlunoRB.UseVisualStyleBackColor = true;
			this.Num_AlunoRB.CheckedChanged += new System.EventHandler(this.Num_AlunoRB_CheckedChanged);
			// 
			// PesquisaAlunoTB
			// 
			this.PesquisaAlunoTB.Location = new System.Drawing.Point(92, 29);
			this.PesquisaAlunoTB.Name = "PesquisaAlunoTB";
			this.PesquisaAlunoTB.Size = new System.Drawing.Size(152, 20);
			this.PesquisaAlunoTB.TabIndex = 2;
			// 
			// PesquisaAlunoLabel
			// 
			this.PesquisaAlunoLabel.AutoSize = true;
			this.PesquisaAlunoLabel.Location = new System.Drawing.Point(33, 32);
			this.PesquisaAlunoLabel.Name = "PesquisaAlunoLabel";
			this.PesquisaAlunoLabel.Size = new System.Drawing.Size(44, 13);
			this.PesquisaAlunoLabel.TabIndex = 0;
			this.PesquisaAlunoLabel.Text = "Número";
			// 
			// PesquisaCadeiraCurso
			// 
			this.PesquisaCadeiraCurso.Controls.Add(this.listaCadeiras);
			this.PesquisaCadeiraCurso.Controls.Add(this.label4);
			this.PesquisaCadeiraCurso.Controls.Add(this.listaCursos);
			this.PesquisaCadeiraCurso.Controls.Add(this.PesquisaAvaliações);
			this.PesquisaCadeiraCurso.Controls.Add(this.label3);
			this.PesquisaCadeiraCurso.Location = new System.Drawing.Point(12, 160);
			this.PesquisaCadeiraCurso.Name = "PesquisaCadeiraCurso";
			this.PesquisaCadeiraCurso.Size = new System.Drawing.Size(284, 142);
			this.PesquisaCadeiraCurso.TabIndex = 7;
			this.PesquisaCadeiraCurso.TabStop = false;
			this.PesquisaCadeiraCurso.Text = "Pesquisa Avaliações";
			// 
			// listaCadeiras
			// 
			this.listaCadeiras.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.listaCadeiras.FormattingEnabled = true;
			this.listaCadeiras.Location = new System.Drawing.Point(65, 56);
			this.listaCadeiras.Name = "listaCadeiras";
			this.listaCadeiras.Size = new System.Drawing.Size(202, 21);
			this.listaCadeiras.TabIndex = 8;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 59);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(43, 13);
			this.label4.TabIndex = 7;
			this.label4.Text = "Cadeira";
			// 
			// listaCursos
			// 
			this.listaCursos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.listaCursos.FormattingEnabled = true;
			this.listaCursos.Location = new System.Drawing.Point(65, 29);
			this.listaCursos.Name = "listaCursos";
			this.listaCursos.Size = new System.Drawing.Size(202, 21);
			this.listaCursos.TabIndex = 6;
			this.listaCursos.SelectedIndexChanged += new System.EventHandler(this.listaCursos_SelectedIndexChanged);
			// 
			// PesquisaAvaliações
			// 
			this.PesquisaAvaliações.Location = new System.Drawing.Point(107, 106);
			this.PesquisaAvaliações.Name = "PesquisaAvaliações";
			this.PesquisaAvaliações.Size = new System.Drawing.Size(75, 23);
			this.PesquisaAvaliações.TabIndex = 5;
			this.PesquisaAvaliações.Text = "Pesquisar";
			this.PesquisaAvaliações.UseVisualStyleBackColor = true;
			this.PesquisaAvaliações.Click += new System.EventHandler(this.PesquisaAvaliações_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 32);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(34, 13);
			this.label3.TabIndex = 0;
			this.label3.Text = "Curso";
			// 
			// insertButton
			// 
			this.insertButton.Location = new System.Drawing.Point(92, 334);
			this.insertButton.Name = "insertButton";
			this.insertButton.Size = new System.Drawing.Size(105, 23);
			this.insertButton.TabIndex = 8;
			this.insertButton.Text = "Inserir Informações";
			this.insertButton.UseVisualStyleBackColor = true;
			this.insertButton.Click += new System.EventHandler(this.Inserir_Click);
			// 
			// PesquisaFinalListBox
			// 
			this.PesquisaFinalListBox.FormattingEnabled = true;
			this.PesquisaFinalListBox.Location = new System.Drawing.Point(593, 90);
			this.PesquisaFinalListBox.Name = "PesquisaFinalListBox";
			this.PesquisaFinalListBox.Size = new System.Drawing.Size(176, 212);
			this.PesquisaFinalListBox.TabIndex = 9;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(384, 13);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 13);
			this.label1.TabIndex = 7;
			this.label1.Text = "Resultados de pesquisa";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(648, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(59, 13);
			this.label2.TabIndex = 10;
			this.label2.Text = "Avaliações";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(781, 393);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.PesquisaFinalListBox);
			this.Controls.Add(this.insertButton);
			this.Controls.Add(this.PesquisaCadeiraCurso);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.PesquisaIntermediaListBox);
			this.Name = "Form1";
			this.Text = "Alunos_UBI";
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.PesquisaCadeiraCurso.ResumeLayout(false);
			this.PesquisaCadeiraCurso.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox PesquisaIntermediaListBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox PesquisaAlunoTB;
        private System.Windows.Forms.Label PesquisaAlunoLabel;
        private System.Windows.Forms.RadioButton Num_AlunoRB;
        private System.Windows.Forms.RadioButton Nome_AlunoRB;
        private System.Windows.Forms.Button PesquisaAlunoButton;
        private System.Windows.Forms.GroupBox PesquisaCadeiraCurso;
        private System.Windows.Forms.Button PesquisaAvaliações;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox listaCursos;
        private System.Windows.Forms.ComboBox listaCadeiras;
        private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button insertButton;
		private System.Windows.Forms.ListBox PesquisaFinalListBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
	}
}

