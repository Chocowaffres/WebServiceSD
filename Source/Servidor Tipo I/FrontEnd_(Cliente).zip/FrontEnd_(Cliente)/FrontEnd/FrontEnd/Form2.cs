﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontEnd
{
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
		}

		// Web Service
		ServicoWeb theWebSvc = new ServicoWeb();

		private void InserirSubmeter_Click(object sender, EventArgs e)
		{
			string sNome_User = Nome_UserTB.Text;
			string sPass_User = Pass_UserTB.Text;

			string sResult = theWebSvc.avaliaPermisaoUser(sNome_User, sPass_User);

			if (sResult == "OK")
			{
				Form3 managementForm = new Form3();
				managementForm.Location = this.Location;
				managementForm.StartPosition = this.StartPosition;
				managementForm.FormClosing += delegate { this.Show(); };
				managementForm.Show();
				this.Hide();
			}

			else
			{
				MessageBox.Show("Nome de utilizador ou palavra-passe incorretos!");
			}

		}

		private void ModificarSubmeter_Click(object sender, EventArgs e)
		{
			string sNome_User = SubmeterUser_TB.Text;
			string sPass_User = SubmeterPass_TB.Text;

			string sResult = theWebSvc.avaliaPermisaoUser(sNome_User, sPass_User);

			if (sResult == "OK")
			{
				Form4 managementForm = new Form4();
				managementForm.Location = this.Location;
				managementForm.StartPosition = this.StartPosition;
				managementForm.FormClosing += delegate { this.Show(); };
				managementForm.Show();
				this.Hide();
			}

			else
			{
				MessageBox.Show("Nome de utilizador ou palavra-passe incorretos!");
			}

		}
	}
}
