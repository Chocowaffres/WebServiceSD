﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontEnd
{
	public partial class Form3 : Form
	{
		public Form3()
		{
			InitializeComponent();

			// Obter informação dos cursos disponíveis em todos os graus
			List<string> cursos = carregaCursos();
			int iNum = cursos.Count;
			if (iNum == 0)
			{
				cursos.Add("Não existem cursos!");
			}

			// Preencher as comboBox de cursos com essa informação
			alunoCursoComboBoxCurso.Items.Clear();
			alunoCursoComboBoxCurso.DataSource = cursos;
			alunoCursoComboBoxCurso.SelectedIndex = 0;

			disciplinaCursoComboBoxCurso.Items.Clear();
			disciplinaCursoComboBoxCurso.DataSource = cursos;
			disciplinaCursoComboBoxCurso.SelectedIndex = 0;

			avaliacaoDisciplinaComboBoxCurso.Items.Clear();
			avaliacaoDisciplinaComboBoxCurso.DataSource = cursos;
			avaliacaoDisciplinaComboBoxCurso.SelectedIndex = 0;

			if (iNum == 0)
			{
				alunoCursoComboBoxCurso.Enabled = false;
				disciplinaCursoComboBoxCurso.Enabled = false;
				avaliacaoDisciplinaComboBoxCurso.Enabled = false;
			}

			// Preenchido e escolhido automaticamente pela seleção de um aluno
			alunoDisciplinaComboBoxCurso.Enabled = false;

			notaAlunoAvalComboBoxCurso.Enabled = false;

			// Enquanto não for escolhido um curso as cadeiras não estão disponíveis
			alunoDisciplinaComboBoxCadeira.Enabled = false;
			alunoDisciplinaComboBoxCadeira.SelectedItem = null;

			avaliacaoDisciplinaComboBoxCadeira.Enabled = false;
			avaliacaoDisciplinaComboBoxCadeira.SelectedItem = null;

			notaAlunoAvalComboBoxCadeira.Enabled = false;
			notaAlunoAvalComboBoxCadeira.SelectedItem = null;

			// Enquanto não for escolhida uma disciplina as suas avaliações não estão disponíveis
			notaAlunoAvalComboBoxAval.Enabled = false;
			notaAlunoAvalComboBoxAval.SelectedItem = null;

			// Preencher os tipos de avaliação existentes
			avaliacaoDiscComboBoxTipo.Items.Clear();
			
			List<string> lsTipoAvaliacoes = carregaTiposAval();
			iNum = lsTipoAvaliacoes.Count;

			if (iNum == 0)
			{
				lsTipoAvaliacoes.Add("Não há tipos de avaliações!");
			}
			avaliacaoDiscComboBoxTipo.DataSource = lsTipoAvaliacoes;
			avaliacaoDiscComboBoxTipo.SelectedItem = null;

			// Colocar a informação das pessoas na comboBox respetiva
			// 10 é o número de nomes que vão surgir nestas
			carregaPessoas("",10);
		}

		/*// Sempre que muda de Tab atualizar os valores
		private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
		{
			// Obter informação dos cursos disponíveis em todos os graus
			List<string> cursos = carregaCursos();
			int iNum = cursos.Count;
			if (iNum == 0)
			{
				cursos.Add("Não existem cursos!");
			}

			// Preencher as comboBox de cursos com essa informação
			alunoCursoComboBoxCurso.Items.Clear();
			alunoCursoComboBoxCurso.DataSource = cursos;
			alunoCursoComboBoxCurso.SelectedIndex = 0;

			disciplinaCursoComboBoxCurso.Items.Clear();
			disciplinaCursoComboBoxCurso.DataSource = cursos;
			disciplinaCursoComboBoxCurso.SelectedIndex = 0;

			avaliacaoDisciplinaComboBoxCurso.Items.Clear();
			avaliacaoDisciplinaComboBoxCurso.DataSource = cursos;
			avaliacaoDisciplinaComboBoxCurso.SelectedIndex = 0;

			if (iNum == 0)
			{
				alunoCursoComboBoxCurso.Enabled = false;
				disciplinaCursoComboBoxCurso.Enabled = false;
				avaliacaoDisciplinaComboBoxCurso.Enabled = false;
			}

			// Preenchido e escolhido automaticamente pela seleção de um aluno
			alunoDisciplinaComboBoxCurso.Enabled = false;

			notaAlunoAvalComboBoxCurso.Enabled = false;

			// Enquanto não for escolhido um curso as cadeiras não estão disponíveis
			alunoDisciplinaComboBoxCadeira.Enabled = false;
			alunoDisciplinaComboBoxCadeira.SelectedItem = null;

			avaliacaoDisciplinaComboBoxCadeira.Enabled = false;
			avaliacaoDisciplinaComboBoxCadeira.SelectedItem = null;

			notaAlunoAvalComboBoxCadeira.Enabled = false;
			notaAlunoAvalComboBoxCadeira.SelectedItem = null;

			// Enquanto não for escolhida uma disciplina as suas avaliações não estão disponíveis
			notaAlunoAvalComboBoxAval.Enabled = false;
			notaAlunoAvalComboBoxAval.SelectedItem = null;

			// Preencher os tipos de avaliação existentes
			avaliacaoDiscComboBoxTipo.DataSource = null;
			avaliacaoDiscComboBoxTipo.Items.Clear();

			List<string> lsTipoAvaliacoes = carregaTiposAval();
			iNum = lsTipoAvaliacoes.Count;

			if (iNum == 0)
			{
				lsTipoAvaliacoes.Add("Não há tipos de avaliações!");
			}
			avaliacaoDiscComboBoxTipo.DataSource = lsTipoAvaliacoes;
			avaliacaoDiscComboBoxTipo.SelectedItem = null;

			// Colocar a informação das pessoas na comboBox respetiva
			// 10 é o número de nomes que vão surgir nestas
			carregaPessoas("", 10);
		}*/

		// Web Service
		ServicoWeb theWebSvc = new ServicoWeb();

		// Dicionários que permitem identificar qual o ID associado a um nome ou descrição
		Dictionary<string, string> dictID_Pessoa = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Curso = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Cadeira = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Aluno = new Dictionary<string, string>();
		Dictionary<string, string> dictID_Aluno_Curso = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Tipo_Aval = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Avaliacao = new Dictionary<string, string>();

		// ----------------------------- Tab Pessoa -----------------------------------------------------

		// Função que permite realizar o registo de uma pessoa
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void pessoaConfirmar_Click(object sender, EventArgs e)
		{
			string sNome = pessoaNome.Text.ToString();
			string sCC = pessoaCC.Text.ToString();

			string sResult = theWebSvc.inserirPessoa(sNome, sCC);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Pessoa inserida com sucesso!");
			}
			else
			{
				MessageBox.Show("Pessoa inserida sem sucesso!");
			}
		}

		// Função que permite limpar as informações existentes
		private void pessoaLimpar_Click(object sender, EventArgs e)
		{
			pessoaNome.Text = "";
			pessoaCC.Text = "";
		}

		// ----------------------------- Tab AlunoCurso -----------------------------------------------------

		// Função auxiliar que preenche a comboBox com os diversos cursos
		private List<string> carregaCursos()
		{
			// Limpar datasource antes de realizar modificações
			alunoCursoComboBoxCurso.DataSource = null;
			disciplinaCursoComboBoxCurso.DataSource = null;
			avaliacaoDisciplinaComboBoxCurso.DataSource = null;

			// Limpar a comboBox antes de preencher
			alunoCursoComboBoxCurso.Items.Clear();
			disciplinaCursoComboBoxCurso.Items.Clear();
			avaliacaoDisciplinaComboBoxCurso.Items.Clear();

			// Limpar a informação anterior do dicionário
			dictID_Curso = new Dictionary<string, string>();

			List<string> Graus = new List<string>() { "Licenciatura", "Mestrado", "Doutoramento"/*, "Pos-Doutoramento"*/ };
			List<string> Cursos = new List<string>();
			string sResposta = "", sErro = "";

			for (int i = 0; i < Graus.Count; i++)
			{
				sResposta = theWebSvc.cursosDeGrau(Graus[i]);

				if (sResposta.Contains("Erro"))
				{
					sErro += "Não foi possível conetar-se à BD de " + Graus[i] + "\n";
					continue;
				}

				// Split por >>
				string[] saCursos = sResposta.Split(
					new[] { ">>" },
					StringSplitOptions.None
				);
				for (int j = 0; j < saCursos.Length - 1; j++)
				{
					string[] saIds = saCursos[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					dictID_Curso.Add(saIds[1], saIds[0]);

					Cursos.Add(saIds[1]);
				}

			}

			if (!sErro.Equals(""))
				MessageBox.Show(sErro);

			return Cursos;
		}

		// Função auxiliar que preenche a comboBox com as diversas pessoas
		// com base no nome introduzido na textBox e no número de linhas a mostrar
		private void carregaPessoas(string sNome, int iNumLinhas)
		{
			// Limpar a comboBox antes de preencher
			alunoCursoComboBoxPessoa.SelectedItem = null;
			alunoCursoComboBoxPessoa.Items.Clear();

			// Limpar a informação anterior do dicionário
			dictID_Pessoa = new Dictionary<string, string>();

			string sID_Pessoa = theWebSvc.getIDPessoaUsandoNome(sNome);

			if (sID_Pessoa.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de Matrículas \n");
				alunoCursoComboBoxPessoa.Enabled = false;
				return;
			}

			// Split por >>
			string[] saPessoas = sID_Pessoa.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			for (int j = 0; j < saPessoas.Length - 1 && j < iNumLinhas; j++)
			{
				string[] saIds = saPessoas[j].Split(
						new[] { "||" },
						StringSplitOptions.None
				);

				dictID_Pessoa.Add(saIds[0], saIds[1]);

				alunoCursoComboBoxPessoa.Items.Add(saIds[1]);
			}

			if (saPessoas.Length > 1)
			{
				alunoCursoComboBoxPessoa.SelectedIndex = 0;
			}
		}

		// Sempre que o texto muda então mudar as pessoas
		private void alunoCursoNomeText_TextChanged(object sender, EventArgs e)
		{
			string sNome = alunoCursoNomeText.Text.ToString();

			carregaPessoas(sNome, 10);
		}

		// Aquando do clique do botão Confirmar na tab de AlunoCurso, é feita a inscrição de uma pessoa num curso
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void alunoCursoConfirmar_Click(object sender, EventArgs e)
		{
			string sNome = alunoCursoComboBoxPessoa.Text.ToString();
			string sCurso = alunoCursoComboBoxCurso.Text.ToString();

			string sID_Pessoa = dictID_Pessoa.FirstOrDefault(x => x.Value == sNome).Key;
			string sID_Curso = dictID_Curso.FirstOrDefault(x => x.Key == sCurso).Value;

			string sResult = theWebSvc.inserirMatricula(sID_Pessoa, sCurso, sID_Curso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Matrícula realizada com sucesso!");
			}
			else
			{
				MessageBox.Show("NÃO foi possível inscrever o aluno no curso!");
			}
		}

		// Função que permite limpar as informações existentes
		private void alunoCursoLimpar_Click(object sender, EventArgs e)
		{
			alunoCursoNomeText.Text = "";

			carregaPessoas("",10);

			alunoCursoComboBoxCurso.SelectedIndex = 0;
		}

		// ----------------------------- Tab AlunoDisciplina -----------------------------------------------------

		// Quando o curso muda terá que ser atualizada a lista de cadeiras
		private void alunoDisciplinaComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			alunoDisciplinaComboBoxCadeira.Enabled = true;
			List<string> lsCadeiras = carregaCadeiras();
			int iNum = lsCadeiras.Count;

			if (iNum == 0)
			{
				lsCadeiras.Add("Curso sem Cadeiras!");
			}

			alunoDisciplinaComboBoxCadeira.DataSource = lsCadeiras;
			alunoDisciplinaComboBoxCadeira.SelectedItem = 0;

		}

		// Carregar as cadeiras relativamente a um curso
		// Se não existirem cadeiras então desabilitar comboBox
		private List<string> carregaCadeiras()
		{
			// Limpar a informação anterior do dicionário
			dictID_Cadeira = new Dictionary<string, string>();

			alunoDisciplinaComboBoxCadeira.DataSource = null;
			avaliacaoDisciplinaComboBoxCadeira.DataSource = null;
			notaAlunoAvalComboBoxCadeira.DataSource = null;

			List<string> Cadeiras = new List<string>();
			string sCursoSelecionado = "", sErro = "";

			// Cuidado acrescido
			if (alunoDisciplinaComboBoxCurso.SelectedItem != null)
			{
				sCursoSelecionado = alunoDisciplinaComboBoxCurso.SelectedItem.ToString();
			}
			// Cuidado acrescido
			if (avaliacaoDisciplinaComboBoxCurso.SelectedItem != null)
			{
				sCursoSelecionado = avaliacaoDisciplinaComboBoxCurso.SelectedItem.ToString();
			}
			// Cuidado acrescido
			if (notaAlunoAvalComboBoxCurso.SelectedItem != null)
			{
				sCursoSelecionado = notaAlunoAvalComboBoxCurso.SelectedItem.ToString();
			}

			string sResposta = theWebSvc.cadeirasDeCurso(sCursoSelecionado);

			// Avaliar grau
			string sGrau = (sCursoSelecionado.Contains("Licenciatura") ?
				"Licenciatura" : (sCursoSelecionado.Contains("Mestrado") ?
				"Mestrado" : (sCursoSelecionado.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			if (sResposta.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD " + sGrau + " \n");
				Cadeiras.Add("Não existe informação");
				alunoDisciplinaComboBoxCadeira.Enabled = false;
				avaliacaoDisciplinaComboBoxCadeira.Enabled = false;
				notaAlunoAvalComboBoxCadeira.Enabled = false;
				return Cadeiras;
			}

			string[] saCadeiras = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (saCadeiras.Length == 1)
			{
				// Limpar comboBox's
				alunoDisciplinaComboBoxCadeira.Items.Clear();
				alunoDisciplinaComboBoxCadeira.Enabled = false;

				avaliacaoDisciplinaComboBoxCadeira.Items.Clear();
				avaliacaoDisciplinaComboBoxCadeira.Enabled = false;

				notaAlunoAvalComboBoxCadeira.Items.Clear();
				notaAlunoAvalComboBoxCadeira.Enabled = false;
			}

			for (int j = 0; j < saCadeiras.Length - 1; j++)
			{
				string[] saIds = saCadeiras[j].Split(
						new[] { "||" },
						StringSplitOptions.None
				);

				dictID_Cadeira.Add(saIds[1], saIds[0]);

				Cadeiras.Add(saIds[1]);
			}

			if (!sErro.Equals(""))
				MessageBox.Show(sErro);

			return Cadeiras;

		}

		// Carregar os alunos existentes com base no nome introduzido
		private void carregaAlunos(string sNome, int iNumLinhas)
		{
			alunoDisciplinaListBoxAlunos.Items.Clear();
			alunoDisciplinaListBoxAlunos.SelectedItem = null;

			notaAlunoAvalListBoxAlunos.Items.Clear();
			notaAlunoAvalListBoxAlunos.SelectedItem = null;

			// Limpar a informação anterior do dicionário
			dictID_Aluno = new Dictionary<string, string>();
			dictID_Aluno_Curso = new Dictionary<string, string>();

			string sID_Aluno = theWebSvc.listAlunoUsandoNome(sNome);

			if (sID_Aluno.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de Matrículas \n");
				alunoDisciplinaListBoxAlunos.Enabled = false;
				notaAlunoAvalListBoxAlunos.Enabled = false;
				return;
			}

			// Split por >>
			string[] saAlunos = sID_Aluno.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			for (int j = 0; j < saAlunos.Length - 1 && j < iNumLinhas; j++)
			{
				string[] saIds = saAlunos[j].Split('#');

				// Newline resultante da última linha
				if (saIds.Length == 1)
					continue;
				string sResultado = saIds[0] + ". " + saIds[1] + " " + saIds[2]; 

				dictID_Aluno.Add(saIds[0], sResultado);
				dictID_Aluno_Curso.Add(saIds[0], saIds[2]);

				alunoDisciplinaListBoxAlunos.Items.Add(sResultado);
				notaAlunoAvalListBoxAlunos.Items.Add(sResultado);
			}
		}

		// Aquando do clique do botão Confirmar na tab de AlunoDisciplina, é feita a inscrição de um aluno numa disciplina
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void alunoDisciplinaConfirmar_Click(object sender, EventArgs e)
		{
			string sAluno = alunoDisciplinaListBoxAlunos.SelectedItem.ToString();
			string sCadeira = alunoDisciplinaComboBoxCadeira.Text.ToString();

			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sID_Cadeira = dictID_Cadeira.FirstOrDefault(x => x.Key == sCadeira).Value;

			string sResult = theWebSvc.inserirAlunoDisciplina(sID_Aluno, sID_Cadeira);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Aluno inscrito com sucesso!");
			}
			else
			{
				MessageBox.Show("NÃO foi possível inscrever o aluno na cadeira!");
			}
		}

		// Função que permite limpar as informações existentes
		private void alunoDisciplinaPesquisar_Click(object sender, EventArgs e)
		{
			string sNome = alunoDisciplinaNomeText.Text.ToString();

			carregaAlunos(sNome, 10);
		}

		// Função que permite limpar as informações existentes
		private void alunoDisciplinaLimpar_Click(object sender, EventArgs e)
		{
			alunoDisciplinaNomeText.Text = "";

			alunoDisciplinaListBoxAlunos.SelectedItem = null;
			alunoDisciplinaListBoxAlunos.Items.Clear();

			alunoDisciplinaComboBoxCurso.SelectedItem = null;
			alunoDisciplinaComboBoxCurso.Items.Clear();

			alunoDisciplinaComboBoxCadeira.DataSource = null;
			alunoDisciplinaComboBoxCadeira.SelectedItem = null;
			alunoDisciplinaComboBoxCadeira.Items.Clear();
		}

		// Quando selecionado o aluno, escrever automaticamente o curso no DropDown
		private void alunoDisciplinaListBoxAlunos_DoubleClick(object sender, EventArgs e)
		{		
			string sAluno = alunoDisciplinaListBoxAlunos.SelectedItem.ToString();
			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sCurso = dictID_Aluno_Curso.FirstOrDefault(x => x.Key == sID_Aluno).Value;

			alunoDisciplinaComboBoxCurso.Items.Clear();
			alunoDisciplinaComboBoxCurso.SelectedItem = null;
			alunoDisciplinaComboBoxCurso.Items.Add(sCurso);
			alunoDisciplinaComboBoxCurso.SelectedIndex = 0;
		}

		// ----------------------------- Tab Curso -----------------------------------------------------

		// Aquando do clique do botão Confirmar na tab de Curso, é feita a introdução do curso na base de dados respetiva
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void cursoConfirmar_Click(object sender, EventArgs e)
		{
			string sNome = cursoNomeCursoText.Text.ToString();
			string sCodigo = cursoCodigoCursoText.Text.ToString();
			string sNumbECTS = cursoNumbECTSText.Text.ToString();
			string sDescricao = cursoDescricaoCursoText.Text.ToString();

			string sGrau = tabPage4.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked).Text;

			sDescricao += " - " + sGrau;

			string sResult = theWebSvc.inserirCurso(sNome, sCodigo, sNumbECTS, sDescricao);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Curso criado com sucesso!");
			}
			else
			{
				MessageBox.Show("NÃO foi possível criar o curso!");
			}
		}

		// Função que permite limpar as informações existentes
		private void cursoLimpar_Click(object sender, EventArgs e)
		{
			cursoNomeCursoText.Text = "";
			cursoCodigoCursoText.Text = "";
			cursoNumbECTSText.Text = "";
			cursoDescricaoCursoText.Text = "";
			cursoDescricaoCursoText.Text = "";

			tabPage4.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Text == "Licenciatura").Select();
		}

		// ----------------------------- Tab DisciplinaCurso -----------------------------------------------------

		// Aquando do clique do botão Confirmar na tab de DisciplinaCurso, é feita a introdução da disciplina no curso respetivo
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void disciplinaCursoConfirmar_Click(object sender, EventArgs e)
		{
			string sNome = disciplinaCursoNomeDiscText.Text.ToString();
			string sCodigo = disciplinaCursoCodigoDiscText.Text.ToString();
			string sNumbECTS = disciplinaCursoNumbECTSText.Text.ToString();
			string sDescricao = disciplinaCursoDescDiscText.Text.ToString();
			string sCurso = disciplinaCursoComboBoxCurso.Text.ToString();
			string sCriterios = disciplinaCursoCriteriosDiscText.Text.ToString();

			string sID_Curso = dictID_Curso.FirstOrDefault(x => x.Key == sCurso).Value;

			string sResult = theWebSvc.inserirDisciplinaCurso(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sID_Curso, sCurso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Disciplina introduzida com sucesso!");
			}
			else
			{
				MessageBox.Show("NÃO foi possível introduzir a cadeira no curso!");
			}
		}

		// Função que permite limpar as informações existentes
		private void disciplinaCursoLimpar_Click(object sender, EventArgs e)
		{
			disciplinaCursoNomeDiscText.Text = "";
			disciplinaCursoCodigoDiscText.Text = "";
			disciplinaCursoNumbECTSText.Text = "";
			disciplinaCursoDescDiscText.Text = "";
			disciplinaCursoComboBoxCurso.SelectedIndex = 0;
			disciplinaCursoCriteriosDiscText.Text = "";
		}

		// ----------------------------- Tab AvaliacaoDisciplina -----------------------------------------------------

		// Aquando do clique do botão Confirmar na tab AvaliacaoDisciplina, é feita a introdução de uma avaliação num disciplina
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void avaliacaoDisciplinaConfirmar_Click(object sender, EventArgs e)
		{
			string sFator_Ponderacao = avaliacaoDisciplinaFatorPondText.Text.ToString();
			string sData = avaliacaoDisciplinaDataText.Text.ToString();
			string sTipo_Avaliacao = avaliacaoDiscComboBoxTipo.Text.ToString();
			string sCadeira = avaliacaoDisciplinaComboBoxCadeira.Text.ToString();
			string sCurso = avaliacaoDisciplinaComboBoxCurso.Text.ToString();

			string sID_Disciplina = dictID_Cadeira.FirstOrDefault(x => x.Key == sCadeira).Value;
			string sID_Tipo_Avaliacao = dictID_Tipo_Aval.FirstOrDefault(x => x.Value == sTipo_Avaliacao).Key;

			string sResult = theWebSvc.inserirAvaliacaoDisciplina(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sCurso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Avaliação introduzida com sucesso!");
			}
			else
			{
				MessageBox.Show("NÃO foi possível introduzir avaliação na cadeira!");
			}
		}
		
		// Carregar os Tipos de Avaliação existentes com base no curso escolhido
		private List<string> carregaTiposAval()
		{
			// Limpar a informação anterior do dicionário
			dictID_Tipo_Aval = new Dictionary<string, string>();

			avaliacaoDiscComboBoxTipo.SelectedItem = null;
			List<string> TipoAval = new List<string>();

			string sID_Tipo_Aval = theWebSvc.getTipoAvaliacao();

			if (sID_Tipo_Aval.Contains("NO_OK"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD Licenciatura/Mestrado \n");
				TipoAval.Add("Não existe informação");
				avaliacaoDiscComboBoxTipo.Enabled = false;
				return TipoAval;
			}

			// Split por >>
			string[] saTipoAval = sID_Tipo_Aval.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (saTipoAval.Length == 1)
			{
				// Limpar comboBox's
				avaliacaoDiscComboBoxTipo.Items.Clear();
				avaliacaoDiscComboBoxTipo.SelectedItem = null;
			}

			for (int j = 0; j < saTipoAval.Length - 1; j++)
			{
				string[] saIds = saTipoAval[j].Split(
						new[] { "||" },
						StringSplitOptions.None
				);

				dictID_Tipo_Aval.Add(saIds[0], saIds[1]);

				TipoAval.Add(saIds[1]);
			}

			return TipoAval;
		}

		// Sempre que muda o curso, mostrar as cadeiras do mesmo e atualizar o tipo de avaliação disponível
		private void avaliacaoDisciplinaComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			avaliacaoDisciplinaComboBoxCadeira.Enabled = true;
			avaliacaoDisciplinaComboBoxCadeira.DataSource = null;

			List<string> lsCadeiras = carregaCadeiras();
			int iNum = lsCadeiras.Count;

			if (iNum == 0)
			{
				lsCadeiras.Add("Curso sem Cadeiras!");
			}

			avaliacaoDisciplinaComboBoxCadeira.DataSource = lsCadeiras;
			avaliacaoDisciplinaComboBoxCadeira.SelectedIndex = 0;

		}
		
		// Função que permite limpar as informações existentes
		private void avaliacaoDisciplinaLimpar_Click(object sender, EventArgs e)
		{
			avaliacaoDisciplinaFatorPondText.Text = "";
			avaliacaoDisciplinaDataText.Text = "";
			avaliacaoDiscComboBoxTipo.SelectedIndex = 0;
			avaliacaoDisciplinaComboBoxCadeira.DataSource = null;
			avaliacaoDisciplinaComboBoxCadeira.SelectedItem = null;
			avaliacaoDisciplinaComboBoxCadeira.Items.Clear();
			avaliacaoDisciplinaComboBoxCurso.SelectedIndex = 0;
		}

		// -----------------------------Tab NotaAlunoAvaliacao-----------------------------------------------------

		// Quando selecionado o aluno, escrever automaticamente o curso no DropDown
		private void notaAlunoAvalListBoxAlunos_DoubleClick(object sender, EventArgs e)
		{
			string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();
			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sCurso = dictID_Aluno_Curso.FirstOrDefault(x => x.Key == sID_Aluno).Value;

			notaAlunoAvalComboBoxCurso.Items.Clear();
			notaAlunoAvalComboBoxCurso.SelectedItem = null;
			notaAlunoAvalComboBoxCurso.Items.Add(sCurso);
			notaAlunoAvalComboBoxCurso.SelectedIndex = 0;
		}

		private List<string> carregaCadeirasAluno(string sID_Aluno)
		{
			// Limpar a informação anterior do dicionário
			dictID_Cadeira = new Dictionary<string, string>();

			notaAlunoAvalComboBoxCadeira.DataSource = null;

			List<string> Cadeiras = new List<string>();

			string sResposta = theWebSvc.cadeirasDeAluno(sID_Aluno);

			string[] saCadeiras = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			
			if (saCadeiras.Length == 1)
			{
				// Limpar comboBox
				notaAlunoAvalComboBoxCadeira.Items.Clear();
				notaAlunoAvalComboBoxCadeira.Enabled = false;
			}

			for (int j = 0; j < saCadeiras.Length - 1; j++)
			{
				string[] saIds = saCadeiras[j].Split(
						new[] { "||" },
						StringSplitOptions.None
				);

				string[] saNota = saIds[1].Split(
						new[] { " : " },
						StringSplitOptions.None
				);

				dictID_Cadeira.Add(saIds[0], saNota[0]);

				Cadeiras.Add(saNota[0]);
			}

			return Cadeiras;
		}

		// Quando o curso muda terá que ser atualizada a lista de cadeiras
		private void notaAlunoAvalComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			notaAlunoAvalComboBoxCadeira.Enabled = true;
			string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();
			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;

			List<string> lsCadeiras = carregaCadeirasAluno(sID_Aluno);
			int iNum = lsCadeiras.Count;

			if (iNum == 0)
			{
				lsCadeiras.Add("Cadeira sem avaliações!");
			}

			notaAlunoAvalComboBoxCadeira.DataSource = lsCadeiras;
			notaAlunoAvalComboBoxCadeira.SelectedItem = 0;
		}

		// Carregar as avaliações de uma cadeira
		private void carregaAvaliacoesCadeira()
		{
			// Limpar dicionário
			dictID_Avaliacao = new Dictionary<string, string>();

			// Limpar listBox
			notaAlunoAvalComboBoxAval.Items.Clear();

			string cursoSelecionado = notaAlunoAvalComboBoxCurso.SelectedItem.ToString();
			string cadeiraSelecionada = "";

			// Cuidado acrescido
			if (notaAlunoAvalComboBoxCadeira.SelectedItem != null)
			{
				cadeiraSelecionada = notaAlunoAvalComboBoxCadeira.SelectedItem.ToString();
			}

			if (cadeiraSelecionada == "" || cursoSelecionado == "")
			{
				MessageBox.Show("Escolha ambos os campos!");
				return;
			}

			if (cadeiraSelecionada == "Cadeira sem avaliações!")
			{
				notaAlunoAvalComboBoxAval.Enabled = false;
			}

			// Avaliar grau
			string sGrau = (cursoSelecionado.Contains("Licenciatura") ?
				"Licenciatura" : (cursoSelecionado.Contains("Mestrado") ?
				"Mestrado" : (cursoSelecionado.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			string sResposta = theWebSvc.avaliacoesDeCadeira(cadeiraSelecionada, cursoSelecionado);

			if (sResposta.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de " + sGrau + "\n");
				alunoDisciplinaListBoxAlunos.Enabled = false;
				notaAlunoAvalListBoxAlunos.Enabled = false;
				return;
			}

			string[] avaliacoes = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (avaliacoes.Length == 1)
			{
				// Limpar listBox
				notaAlunoAvalComboBoxAval.Items.Clear();
				notaAlunoAvalComboBoxAval.Items.Add("Cadeira sem avaliações!");
				notaAlunoAvalComboBoxAval.SelectedIndex = 0;
			}
			else
			{
				for (int j = 0; j < avaliacoes.Length - 1; j++)
				{
					string[] ids = avaliacoes[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					dictID_Avaliacao.Add(ids[0], ids[1]);

					notaAlunoAvalComboBoxAval.Items.Add(ids[1]);
				}

				notaAlunoAvalComboBoxAval.SelectedIndex = 0;
			}
		}

		// Quando muda a cadeira atualizar as informações relativamente às avaliações
		private void notaAlunoAvalComboBoxCadeira_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (notaAlunoAvalComboBoxCadeira.SelectedItem == null)
			{
				notaAlunoAvalComboBoxAval.Enabled = false;
			}
			else
			{
				notaAlunoAvalComboBoxAval.Enabled = true;

				carregaAvaliacoesCadeira();
			}
			
		}

		// Quando carregar no botão Pesquisar carregar os alunos disponíveis com aquele nome
		private void notaAlunoAvalPesquisar_Click(object sender, EventArgs e)
		{
			string sNome = notaAlunoAvalNomeText.Text.ToString();

			carregaAlunos(sNome, 10);
		}

		// Quando carregar no botão Confirmar enviar informação para a base de dados
		private void notaAlunoAvalConfirmar_Click(object sender, EventArgs e)
		{
			string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();
			string sAvaliacao = notaAlunoAvalComboBoxAval.SelectedItem.ToString();
			string sNota = notaAlunoAvaliacaoNotaText.Text.ToString();
			string sCurso = notaAlunoAvalComboBoxCurso.SelectedItem.ToString();

			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sID_Avaliacao = dictID_Avaliacao.FirstOrDefault(x => x.Value == sAvaliacao).Key;

			string sResult = theWebSvc.inserirNotaAlunoAvaliacao(sID_Avaliacao, sID_Aluno, sNota, sCurso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Nota introduzida com sucesso!");
			}
			else
			{
				MessageBox.Show("NÃO foi possível atribuir nota ao aluno!");
			}
		}

		// Função que permite limpar as informações existentes
		private void notaAlunoAvalLimpar_Click(object sender, EventArgs e)
		{
			notaAlunoAvalNomeText.Text = "";

			notaAlunoAvalListBoxAlunos.DataSource = null;
			notaAlunoAvalListBoxAlunos.Items.Clear();
			notaAlunoAvalListBoxAlunos.SelectedItem = null;

			notaAlunoAvalComboBoxCurso.DataSource = null;
			notaAlunoAvalComboBoxCurso.Items.Clear();

			notaAlunoAvalComboBoxCadeira.DataSource = null;
			notaAlunoAvalComboBoxCadeira.Items.Clear();
			notaAlunoAvalComboBoxCadeira.SelectedItem = null;

			notaAlunoAvalComboBoxAval.DataSource = null;
			notaAlunoAvalComboBoxAval.Items.Clear();
			notaAlunoAvalComboBoxAval.SelectedItem = null;	

			notaAlunoAvaliacaoNotaText.Text = "";
		}

	}
}
