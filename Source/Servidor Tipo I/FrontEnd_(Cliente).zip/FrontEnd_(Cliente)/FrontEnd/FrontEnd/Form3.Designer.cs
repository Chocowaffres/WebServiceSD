﻿namespace FrontEnd
{
	partial class Form3
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.alunoDisciplinaListBoxAlunos = new System.Windows.Forms.ListBox();
			this.alunoDisciplinaPesquisar = new System.Windows.Forms.Button();
			this.alunoDisciplinaComboBoxCadeira = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.alunoDisciplinaNomeText = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.alunoDisciplinaComboBoxCurso = new System.Windows.Forms.ComboBox();
			this.alunoDisciplinaLimpar = new System.Windows.Forms.Button();
			this.alunoDisciplinaConfirmar = new System.Windows.Forms.Button();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.alunoCursoLimpar = new System.Windows.Forms.Button();
			this.alunoCursoConfirmar = new System.Windows.Forms.Button();
			this.alunoCursoNomeText = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.alunoCursoComboBoxCurso = new System.Windows.Forms.ComboBox();
			this.alunoCursoComboBoxPessoa = new System.Windows.Forms.ComboBox();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.pessoaLimpar = new System.Windows.Forms.Button();
			this.pessoaConfirmar = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.pessoaCC = new System.Windows.Forms.TextBox();
			this.pessoaNome = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.TabControl = new System.Windows.Forms.TabControl();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.cursoPosDocRadio = new System.Windows.Forms.RadioButton();
			this.cursoDoutoramentoRadio = new System.Windows.Forms.RadioButton();
			this.cursoMestradoRadio = new System.Windows.Forms.RadioButton();
			this.cursoLicenciaturaRadio = new System.Windows.Forms.RadioButton();
			this.cursoDescricaoCursoText = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.cursoNumbECTSText = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.cursoCodigoCursoText = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.cursoNomeCursoText = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.cursoLimpar = new System.Windows.Forms.Button();
			this.cursoConfirmar = new System.Windows.Forms.Button();
			this.tabPage5 = new System.Windows.Forms.TabPage();
			this.disciplinaCursoCriteriosDiscText = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.disciplinaCursoComboBoxCurso = new System.Windows.Forms.ComboBox();
			this.disciplinaCursoDescDiscText = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.disciplinaCursoNumbECTSText = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.disciplinaCursoCodigoDiscText = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.disciplinaCursoNomeDiscText = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.disciplinaCursoLimpar = new System.Windows.Forms.Button();
			this.disciplinaCursoConfirmar = new System.Windows.Forms.Button();
			this.tabPage6 = new System.Windows.Forms.TabPage();
			this.avaliacaoDiscComboBoxTipo = new System.Windows.Forms.ComboBox();
			this.label18 = new System.Windows.Forms.Label();
			this.avaliacaoDisciplinaComboBoxCadeira = new System.Windows.Forms.ComboBox();
			this.label19 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.avaliacaoDisciplinaComboBoxCurso = new System.Windows.Forms.ComboBox();
			this.avaliacaoDisciplinaDataText = new System.Windows.Forms.TextBox();
			this.label21 = new System.Windows.Forms.Label();
			this.avaliacaoDisciplinaFatorPondText = new System.Windows.Forms.TextBox();
			this.label22 = new System.Windows.Forms.Label();
			this.avaliacaoDisciplinaLimpar = new System.Windows.Forms.Button();
			this.avaliacaoDisciplinaConfirmar = new System.Windows.Forms.Button();
			this.tabPage7 = new System.Windows.Forms.TabPage();
			this.notaAlunoAvaliacaoNotaText = new System.Windows.Forms.TextBox();
			this.label27 = new System.Windows.Forms.Label();
			this.notaAlunoAvalComboBoxAval = new System.Windows.Forms.ComboBox();
			this.label26 = new System.Windows.Forms.Label();
			this.notaAlunoAvalListBoxAlunos = new System.Windows.Forms.ListBox();
			this.notaAlunoAvalPesquisar = new System.Windows.Forms.Button();
			this.notaAlunoAvalComboBoxCadeira = new System.Windows.Forms.ComboBox();
			this.label20 = new System.Windows.Forms.Label();
			this.notaAlunoAvalNomeText = new System.Windows.Forms.TextBox();
			this.label24 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.notaAlunoAvalComboBoxCurso = new System.Windows.Forms.ComboBox();
			this.notaAlunoAvalLimpar = new System.Windows.Forms.Button();
			this.notaAlunoAvalConfirmar = new System.Windows.Forms.Button();
			this.tabPage3.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.TabControl.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.tabPage5.SuspendLayout();
			this.tabPage6.SuspendLayout();
			this.tabPage7.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.alunoDisciplinaListBoxAlunos);
			this.tabPage3.Controls.Add(this.alunoDisciplinaPesquisar);
			this.tabPage3.Controls.Add(this.alunoDisciplinaComboBoxCadeira);
			this.tabPage3.Controls.Add(this.label7);
			this.tabPage3.Controls.Add(this.alunoDisciplinaNomeText);
			this.tabPage3.Controls.Add(this.label5);
			this.tabPage3.Controls.Add(this.label6);
			this.tabPage3.Controls.Add(this.alunoDisciplinaComboBoxCurso);
			this.tabPage3.Controls.Add(this.alunoDisciplinaLimpar);
			this.tabPage3.Controls.Add(this.alunoDisciplinaConfirmar);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new System.Drawing.Size(796, 427);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "AlunoDisciplina";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// alunoDisciplinaListBoxAlunos
			// 
			this.alunoDisciplinaListBoxAlunos.FormattingEnabled = true;
			this.alunoDisciplinaListBoxAlunos.Location = new System.Drawing.Point(37, 130);
			this.alunoDisciplinaListBoxAlunos.Name = "alunoDisciplinaListBoxAlunos";
			this.alunoDisciplinaListBoxAlunos.Size = new System.Drawing.Size(209, 173);
			this.alunoDisciplinaListBoxAlunos.TabIndex = 18;
			this.alunoDisciplinaListBoxAlunos.DoubleClick += new System.EventHandler(this.alunoDisciplinaListBoxAlunos_DoubleClick);
			// 
			// alunoDisciplinaPesquisar
			// 
			this.alunoDisciplinaPesquisar.Location = new System.Drawing.Point(37, 89);
			this.alunoDisciplinaPesquisar.Name = "alunoDisciplinaPesquisar";
			this.alunoDisciplinaPesquisar.Size = new System.Drawing.Size(75, 23);
			this.alunoDisciplinaPesquisar.TabIndex = 17;
			this.alunoDisciplinaPesquisar.Text = "Pesquisar";
			this.alunoDisciplinaPesquisar.UseVisualStyleBackColor = true;
			this.alunoDisciplinaPesquisar.Click += new System.EventHandler(this.alunoDisciplinaPesquisar_Click);
			// 
			// alunoDisciplinaComboBoxCadeira
			// 
			this.alunoDisciplinaComboBoxCadeira.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.alunoDisciplinaComboBoxCadeira.FormattingEnabled = true;
			this.alunoDisciplinaComboBoxCadeira.Location = new System.Drawing.Point(379, 121);
			this.alunoDisciplinaComboBoxCadeira.Name = "alunoDisciplinaComboBoxCadeira";
			this.alunoDisciplinaComboBoxCadeira.Size = new System.Drawing.Size(228, 21);
			this.alunoDisciplinaComboBoxCadeira.TabIndex = 16;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(376, 94);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(43, 13);
			this.label7.TabIndex = 15;
			this.label7.Text = "Cadeira";
			// 
			// alunoDisciplinaNomeText
			// 
			this.alunoDisciplinaNomeText.Location = new System.Drawing.Point(37, 55);
			this.alunoDisciplinaNomeText.Name = "alunoDisciplinaNomeText";
			this.alunoDisciplinaNomeText.Size = new System.Drawing.Size(209, 20);
			this.alunoDisciplinaNomeText.TabIndex = 14;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(34, 29);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(80, 13);
			this.label5.TabIndex = 13;
			this.label5.Text = "Nome de Aluno";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(376, 29);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(34, 13);
			this.label6.TabIndex = 12;
			this.label6.Text = "Curso";
			// 
			// alunoDisciplinaComboBoxCurso
			// 
			this.alunoDisciplinaComboBoxCurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.alunoDisciplinaComboBoxCurso.FormattingEnabled = true;
			this.alunoDisciplinaComboBoxCurso.Location = new System.Drawing.Point(379, 55);
			this.alunoDisciplinaComboBoxCurso.Name = "alunoDisciplinaComboBoxCurso";
			this.alunoDisciplinaComboBoxCurso.Size = new System.Drawing.Size(228, 21);
			this.alunoDisciplinaComboBoxCurso.TabIndex = 11;
			this.alunoDisciplinaComboBoxCurso.SelectedIndexChanged += new System.EventHandler(this.alunoDisciplinaComboBoxCurso_SelectedIndexChanged);
			// 
			// alunoDisciplinaLimpar
			// 
			this.alunoDisciplinaLimpar.Location = new System.Drawing.Point(391, 359);
			this.alunoDisciplinaLimpar.Name = "alunoDisciplinaLimpar";
			this.alunoDisciplinaLimpar.Size = new System.Drawing.Size(75, 23);
			this.alunoDisciplinaLimpar.TabIndex = 9;
			this.alunoDisciplinaLimpar.Text = "Limpar";
			this.alunoDisciplinaLimpar.UseVisualStyleBackColor = true;
			this.alunoDisciplinaLimpar.Click += new System.EventHandler(this.alunoDisciplinaLimpar_Click);
			// 
			// alunoDisciplinaConfirmar
			// 
			this.alunoDisciplinaConfirmar.Location = new System.Drawing.Point(287, 359);
			this.alunoDisciplinaConfirmar.Name = "alunoDisciplinaConfirmar";
			this.alunoDisciplinaConfirmar.Size = new System.Drawing.Size(75, 23);
			this.alunoDisciplinaConfirmar.TabIndex = 8;
			this.alunoDisciplinaConfirmar.Text = "Confirmar";
			this.alunoDisciplinaConfirmar.UseVisualStyleBackColor = true;
			this.alunoDisciplinaConfirmar.Click += new System.EventHandler(this.alunoDisciplinaConfirmar_Click);
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.alunoCursoLimpar);
			this.tabPage2.Controls.Add(this.alunoCursoConfirmar);
			this.tabPage2.Controls.Add(this.alunoCursoNomeText);
			this.tabPage2.Controls.Add(this.label4);
			this.tabPage2.Controls.Add(this.label3);
			this.tabPage2.Controls.Add(this.alunoCursoComboBoxCurso);
			this.tabPage2.Controls.Add(this.alunoCursoComboBoxPessoa);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(796, 427);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "AlunoCurso";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// alunoCursoLimpar
			// 
			this.alunoCursoLimpar.Location = new System.Drawing.Point(391, 359);
			this.alunoCursoLimpar.Name = "alunoCursoLimpar";
			this.alunoCursoLimpar.Size = new System.Drawing.Size(75, 23);
			this.alunoCursoLimpar.TabIndex = 7;
			this.alunoCursoLimpar.Text = "Limpar";
			this.alunoCursoLimpar.UseVisualStyleBackColor = true;
			this.alunoCursoLimpar.Click += new System.EventHandler(this.alunoCursoLimpar_Click);
			// 
			// alunoCursoConfirmar
			// 
			this.alunoCursoConfirmar.Location = new System.Drawing.Point(287, 359);
			this.alunoCursoConfirmar.Name = "alunoCursoConfirmar";
			this.alunoCursoConfirmar.Size = new System.Drawing.Size(75, 23);
			this.alunoCursoConfirmar.TabIndex = 6;
			this.alunoCursoConfirmar.Text = "Confirmar";
			this.alunoCursoConfirmar.UseVisualStyleBackColor = true;
			this.alunoCursoConfirmar.Click += new System.EventHandler(this.alunoCursoConfirmar_Click);
			// 
			// alunoCursoNomeText
			// 
			this.alunoCursoNomeText.Location = new System.Drawing.Point(34, 61);
			this.alunoCursoNomeText.Name = "alunoCursoNomeText";
			this.alunoCursoNomeText.Size = new System.Drawing.Size(209, 20);
			this.alunoCursoNomeText.TabIndex = 4;
			this.alunoCursoNomeText.TextChanged += new System.EventHandler(this.alunoCursoNomeText_TextChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(34, 35);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 13);
			this.label4.TabIndex = 3;
			this.label4.Text = "Nome de Aluno";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(373, 35);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(34, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Curso";
			// 
			// alunoCursoComboBoxCurso
			// 
			this.alunoCursoComboBoxCurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.alunoCursoComboBoxCurso.FormattingEnabled = true;
			this.alunoCursoComboBoxCurso.Location = new System.Drawing.Point(376, 61);
			this.alunoCursoComboBoxCurso.Name = "alunoCursoComboBoxCurso";
			this.alunoCursoComboBoxCurso.Size = new System.Drawing.Size(228, 21);
			this.alunoCursoComboBoxCurso.TabIndex = 1;
			// 
			// alunoCursoComboBoxPessoa
			// 
			this.alunoCursoComboBoxPessoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.alunoCursoComboBoxPessoa.FormattingEnabled = true;
			this.alunoCursoComboBoxPessoa.Location = new System.Drawing.Point(34, 97);
			this.alunoCursoComboBoxPessoa.Name = "alunoCursoComboBoxPessoa";
			this.alunoCursoComboBoxPessoa.Size = new System.Drawing.Size(228, 21);
			this.alunoCursoComboBoxPessoa.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.pessoaLimpar);
			this.tabPage1.Controls.Add(this.pessoaConfirmar);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.pessoaCC);
			this.tabPage1.Controls.Add(this.pessoaNome);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(796, 427);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Pessoa";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// pessoaLimpar
			// 
			this.pessoaLimpar.Location = new System.Drawing.Point(391, 359);
			this.pessoaLimpar.Name = "pessoaLimpar";
			this.pessoaLimpar.Size = new System.Drawing.Size(75, 23);
			this.pessoaLimpar.TabIndex = 5;
			this.pessoaLimpar.Text = "Limpar";
			this.pessoaLimpar.UseVisualStyleBackColor = true;
			this.pessoaLimpar.Click += new System.EventHandler(this.pessoaLimpar_Click);
			// 
			// pessoaConfirmar
			// 
			this.pessoaConfirmar.Location = new System.Drawing.Point(287, 359);
			this.pessoaConfirmar.Name = "pessoaConfirmar";
			this.pessoaConfirmar.Size = new System.Drawing.Size(75, 23);
			this.pessoaConfirmar.TabIndex = 4;
			this.pessoaConfirmar.Text = "Confirmar";
			this.pessoaConfirmar.UseVisualStyleBackColor = true;
			this.pessoaConfirmar.Click += new System.EventHandler(this.pessoaConfirmar_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(21, 55);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(95, 13);
			this.label2.TabIndex = 3;
			this.label2.Text = "Cartão do Cidadão";
			// 
			// pessoaCC
			// 
			this.pessoaCC.Location = new System.Drawing.Point(122, 52);
			this.pessoaCC.Name = "pessoaCC";
			this.pessoaCC.Size = new System.Drawing.Size(172, 20);
			this.pessoaCC.TabIndex = 2;
			// 
			// pessoaNome
			// 
			this.pessoaNome.Location = new System.Drawing.Point(122, 15);
			this.pessoaNome.Name = "pessoaNome";
			this.pessoaNome.Size = new System.Drawing.Size(626, 20);
			this.pessoaNome.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(81, 18);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(35, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "Nome";
			// 
			// TabControl
			// 
			this.TabControl.Controls.Add(this.tabPage1);
			this.TabControl.Controls.Add(this.tabPage2);
			this.TabControl.Controls.Add(this.tabPage3);
			this.TabControl.Controls.Add(this.tabPage4);
			this.TabControl.Controls.Add(this.tabPage5);
			this.TabControl.Controls.Add(this.tabPage6);
			this.TabControl.Controls.Add(this.tabPage7);
			this.TabControl.Location = new System.Drawing.Point(0, 0);
			this.TabControl.Name = "TabControl";
			this.TabControl.SelectedIndex = 0;
			this.TabControl.Size = new System.Drawing.Size(804, 453);
			this.TabControl.TabIndex = 0;
			//this.TabControl.SelectedIndexChanged += new System.EventHandler(this.TabControl_SelectedIndexChanged);
			// 
			// tabPage4
			// 
			this.tabPage4.Controls.Add(this.cursoPosDocRadio);
			this.tabPage4.Controls.Add(this.cursoDoutoramentoRadio);
			this.tabPage4.Controls.Add(this.cursoMestradoRadio);
			this.tabPage4.Controls.Add(this.cursoLicenciaturaRadio);
			this.tabPage4.Controls.Add(this.cursoDescricaoCursoText);
			this.tabPage4.Controls.Add(this.label11);
			this.tabPage4.Controls.Add(this.cursoNumbECTSText);
			this.tabPage4.Controls.Add(this.label10);
			this.tabPage4.Controls.Add(this.cursoCodigoCursoText);
			this.tabPage4.Controls.Add(this.label8);
			this.tabPage4.Controls.Add(this.cursoNomeCursoText);
			this.tabPage4.Controls.Add(this.label9);
			this.tabPage4.Controls.Add(this.cursoLimpar);
			this.tabPage4.Controls.Add(this.cursoConfirmar);
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage4.Size = new System.Drawing.Size(796, 427);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Curso";
			this.tabPage4.UseVisualStyleBackColor = true;
			// 
			// cursoPosDocRadio
			// 
			this.cursoPosDocRadio.AutoSize = true;
			this.cursoPosDocRadio.Location = new System.Drawing.Point(522, 31);
			this.cursoPosDocRadio.Name = "cursoPosDocRadio";
			this.cursoPosDocRadio.Size = new System.Drawing.Size(113, 17);
			this.cursoPosDocRadio.TabIndex = 24;
			this.cursoPosDocRadio.TabStop = true;
			this.cursoPosDocRadio.Text = "Pós-Doutoramento";
			this.cursoPosDocRadio.UseVisualStyleBackColor = true;
			// 
			// cursoDoutoramentoRadio
			// 
			this.cursoDoutoramentoRadio.AutoSize = true;
			this.cursoDoutoramentoRadio.Location = new System.Drawing.Point(399, 31);
			this.cursoDoutoramentoRadio.Name = "cursoDoutoramentoRadio";
			this.cursoDoutoramentoRadio.Size = new System.Drawing.Size(92, 17);
			this.cursoDoutoramentoRadio.TabIndex = 23;
			this.cursoDoutoramentoRadio.TabStop = true;
			this.cursoDoutoramentoRadio.Text = "Doutoramento";
			this.cursoDoutoramentoRadio.UseVisualStyleBackColor = true;
			// 
			// cursoMestradoRadio
			// 
			this.cursoMestradoRadio.AutoSize = true;
			this.cursoMestradoRadio.Location = new System.Drawing.Point(296, 31);
			this.cursoMestradoRadio.Name = "cursoMestradoRadio";
			this.cursoMestradoRadio.Size = new System.Drawing.Size(69, 17);
			this.cursoMestradoRadio.TabIndex = 22;
			this.cursoMestradoRadio.TabStop = true;
			this.cursoMestradoRadio.Text = "Mestrado";
			this.cursoMestradoRadio.UseVisualStyleBackColor = true;
			// 
			// cursoLicenciaturaRadio
			// 
			this.cursoLicenciaturaRadio.AutoSize = true;
			this.cursoLicenciaturaRadio.Location = new System.Drawing.Point(186, 31);
			this.cursoLicenciaturaRadio.Name = "cursoLicenciaturaRadio";
			this.cursoLicenciaturaRadio.Size = new System.Drawing.Size(83, 17);
			this.cursoLicenciaturaRadio.TabIndex = 21;
			this.cursoLicenciaturaRadio.TabStop = true;
			this.cursoLicenciaturaRadio.Text = "Licenciatura";
			this.cursoLicenciaturaRadio.UseVisualStyleBackColor = true;
			// 
			// cursoDescricaoCursoText
			// 
			this.cursoDescricaoCursoText.Location = new System.Drawing.Point(301, 110);
			this.cursoDescricaoCursoText.Multiline = true;
			this.cursoDescricaoCursoText.Name = "cursoDescricaoCursoText";
			this.cursoDescricaoCursoText.Size = new System.Drawing.Size(473, 20);
			this.cursoDescricaoCursoText.TabIndex = 20;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(301, 84);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(100, 13);
			this.label11.TabIndex = 19;
			this.label11.Text = "Descrição do Curso";
			// 
			// cursoNumbECTSText
			// 
			this.cursoNumbECTSText.Location = new System.Drawing.Point(197, 187);
			this.cursoNumbECTSText.Name = "cursoNumbECTSText";
			this.cursoNumbECTSText.Size = new System.Drawing.Size(117, 20);
			this.cursoNumbECTSText.TabIndex = 18;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(197, 161);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(117, 13);
			this.label10.TabIndex = 17;
			this.label10.Text = "Número Total de ECTS";
			// 
			// cursoCodigoCursoText
			// 
			this.cursoCodigoCursoText.Location = new System.Drawing.Point(40, 187);
			this.cursoCodigoCursoText.Name = "cursoCodigoCursoText";
			this.cursoCodigoCursoText.Size = new System.Drawing.Size(117, 20);
			this.cursoCodigoCursoText.TabIndex = 16;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(40, 161);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(85, 13);
			this.label8.TabIndex = 15;
			this.label8.Text = "Código do Curso";
			// 
			// cursoNomeCursoText
			// 
			this.cursoNomeCursoText.Location = new System.Drawing.Point(38, 110);
			this.cursoNomeCursoText.Name = "cursoNomeCursoText";
			this.cursoNomeCursoText.Size = new System.Drawing.Size(209, 20);
			this.cursoNomeCursoText.TabIndex = 14;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(38, 84);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(80, 13);
			this.label9.TabIndex = 13;
			this.label9.Text = "Nome do Curso";
			// 
			// cursoLimpar
			// 
			this.cursoLimpar.Location = new System.Drawing.Point(391, 359);
			this.cursoLimpar.Name = "cursoLimpar";
			this.cursoLimpar.Size = new System.Drawing.Size(75, 23);
			this.cursoLimpar.TabIndex = 9;
			this.cursoLimpar.Text = "Limpar";
			this.cursoLimpar.UseVisualStyleBackColor = true;
			this.cursoLimpar.Click += new System.EventHandler(this.cursoLimpar_Click);
			// 
			// cursoConfirmar
			// 
			this.cursoConfirmar.Location = new System.Drawing.Point(287, 359);
			this.cursoConfirmar.Name = "cursoConfirmar";
			this.cursoConfirmar.Size = new System.Drawing.Size(75, 23);
			this.cursoConfirmar.TabIndex = 8;
			this.cursoConfirmar.Text = "Confirmar";
			this.cursoConfirmar.UseVisualStyleBackColor = true;
			this.cursoConfirmar.Click += new System.EventHandler(this.cursoConfirmar_Click);
			// 
			// tabPage5
			// 
			this.tabPage5.Controls.Add(this.disciplinaCursoCriteriosDiscText);
			this.tabPage5.Controls.Add(this.label17);
			this.tabPage5.Controls.Add(this.label16);
			this.tabPage5.Controls.Add(this.disciplinaCursoComboBoxCurso);
			this.tabPage5.Controls.Add(this.disciplinaCursoDescDiscText);
			this.tabPage5.Controls.Add(this.label12);
			this.tabPage5.Controls.Add(this.disciplinaCursoNumbECTSText);
			this.tabPage5.Controls.Add(this.label13);
			this.tabPage5.Controls.Add(this.disciplinaCursoCodigoDiscText);
			this.tabPage5.Controls.Add(this.label14);
			this.tabPage5.Controls.Add(this.disciplinaCursoNomeDiscText);
			this.tabPage5.Controls.Add(this.label15);
			this.tabPage5.Controls.Add(this.disciplinaCursoLimpar);
			this.tabPage5.Controls.Add(this.disciplinaCursoConfirmar);
			this.tabPage5.Location = new System.Drawing.Point(4, 22);
			this.tabPage5.Name = "tabPage5";
			this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage5.Size = new System.Drawing.Size(796, 427);
			this.tabPage5.TabIndex = 4;
			this.tabPage5.Text = "DisciplinaCurso";
			this.tabPage5.UseVisualStyleBackColor = true;
			// 
			// disciplinaCursoCriteriosDiscText
			// 
			this.disciplinaCursoCriteriosDiscText.Location = new System.Drawing.Point(333, 129);
			this.disciplinaCursoCriteriosDiscText.Multiline = true;
			this.disciplinaCursoCriteriosDiscText.Name = "disciplinaCursoCriteriosDiscText";
			this.disciplinaCursoCriteriosDiscText.Size = new System.Drawing.Size(440, 20);
			this.disciplinaCursoCriteriosDiscText.TabIndex = 24;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(330, 103);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(107, 13);
			this.label17.TabIndex = 23;
			this.label17.Text = "Critérios da Disciplina";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(33, 169);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(34, 13);
			this.label16.TabIndex = 22;
			this.label16.Text = "Curso";
			// 
			// disciplinaCursoComboBoxCurso
			// 
			this.disciplinaCursoComboBoxCurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.disciplinaCursoComboBoxCurso.FormattingEnabled = true;
			this.disciplinaCursoComboBoxCurso.Location = new System.Drawing.Point(36, 195);
			this.disciplinaCursoComboBoxCurso.Name = "disciplinaCursoComboBoxCurso";
			this.disciplinaCursoComboBoxCurso.Size = new System.Drawing.Size(228, 21);
			this.disciplinaCursoComboBoxCurso.TabIndex = 21;
			// 
			// disciplinaCursoDescDiscText
			// 
			this.disciplinaCursoDescDiscText.Location = new System.Drawing.Point(333, 52);
			this.disciplinaCursoDescDiscText.Multiline = true;
			this.disciplinaCursoDescDiscText.Name = "disciplinaCursoDescDiscText";
			this.disciplinaCursoDescDiscText.Size = new System.Drawing.Size(440, 20);
			this.disciplinaCursoDescDiscText.TabIndex = 20;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(330, 26);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(118, 13);
			this.label12.TabIndex = 19;
			this.label12.Text = "Descrição da Disciplina";
			// 
			// disciplinaCursoNumbECTSText
			// 
			this.disciplinaCursoNumbECTSText.Location = new System.Drawing.Point(195, 129);
			this.disciplinaCursoNumbECTSText.Name = "disciplinaCursoNumbECTSText";
			this.disciplinaCursoNumbECTSText.Size = new System.Drawing.Size(117, 20);
			this.disciplinaCursoNumbECTSText.TabIndex = 18;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(195, 103);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(75, 13);
			this.label13.TabIndex = 17;
			this.label13.Text = "Número ECTS";
			// 
			// disciplinaCursoCodigoDiscText
			// 
			this.disciplinaCursoCodigoDiscText.Location = new System.Drawing.Point(36, 129);
			this.disciplinaCursoCodigoDiscText.Name = "disciplinaCursoCodigoDiscText";
			this.disciplinaCursoCodigoDiscText.Size = new System.Drawing.Size(117, 20);
			this.disciplinaCursoCodigoDiscText.TabIndex = 16;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(36, 103);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(103, 13);
			this.label14.TabIndex = 15;
			this.label14.Text = "Código da Disciplina";
			// 
			// disciplinaCursoNomeDiscText
			// 
			this.disciplinaCursoNomeDiscText.Location = new System.Drawing.Point(36, 52);
			this.disciplinaCursoNomeDiscText.Name = "disciplinaCursoNomeDiscText";
			this.disciplinaCursoNomeDiscText.Size = new System.Drawing.Size(209, 20);
			this.disciplinaCursoNomeDiscText.TabIndex = 14;
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(36, 26);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(98, 13);
			this.label15.TabIndex = 13;
			this.label15.Text = "Nome da Disciplina";
			// 
			// disciplinaCursoLimpar
			// 
			this.disciplinaCursoLimpar.Location = new System.Drawing.Point(391, 359);
			this.disciplinaCursoLimpar.Name = "disciplinaCursoLimpar";
			this.disciplinaCursoLimpar.Size = new System.Drawing.Size(75, 23);
			this.disciplinaCursoLimpar.TabIndex = 9;
			this.disciplinaCursoLimpar.Text = "Limpar";
			this.disciplinaCursoLimpar.UseVisualStyleBackColor = true;
			this.disciplinaCursoLimpar.Click += new System.EventHandler(this.disciplinaCursoLimpar_Click);
			// 
			// disciplinaCursoConfirmar
			// 
			this.disciplinaCursoConfirmar.Location = new System.Drawing.Point(287, 359);
			this.disciplinaCursoConfirmar.Name = "disciplinaCursoConfirmar";
			this.disciplinaCursoConfirmar.Size = new System.Drawing.Size(75, 23);
			this.disciplinaCursoConfirmar.TabIndex = 8;
			this.disciplinaCursoConfirmar.Text = "Confirmar";
			this.disciplinaCursoConfirmar.UseVisualStyleBackColor = true;
			this.disciplinaCursoConfirmar.Click += new System.EventHandler(this.disciplinaCursoConfirmar_Click);
			// 
			// tabPage6
			// 
			this.tabPage6.Controls.Add(this.avaliacaoDiscComboBoxTipo);
			this.tabPage6.Controls.Add(this.label18);
			this.tabPage6.Controls.Add(this.avaliacaoDisciplinaComboBoxCadeira);
			this.tabPage6.Controls.Add(this.label19);
			this.tabPage6.Controls.Add(this.label23);
			this.tabPage6.Controls.Add(this.avaliacaoDisciplinaComboBoxCurso);
			this.tabPage6.Controls.Add(this.avaliacaoDisciplinaDataText);
			this.tabPage6.Controls.Add(this.label21);
			this.tabPage6.Controls.Add(this.avaliacaoDisciplinaFatorPondText);
			this.tabPage6.Controls.Add(this.label22);
			this.tabPage6.Controls.Add(this.avaliacaoDisciplinaLimpar);
			this.tabPage6.Controls.Add(this.avaliacaoDisciplinaConfirmar);
			this.tabPage6.Location = new System.Drawing.Point(4, 22);
			this.tabPage6.Name = "tabPage6";
			this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage6.Size = new System.Drawing.Size(796, 427);
			this.tabPage6.TabIndex = 5;
			this.tabPage6.Text = "AvaliacaoDisciplina";
			this.tabPage6.UseVisualStyleBackColor = true;
			// 
			// avaliacaoDiscComboBoxTipo
			// 
			this.avaliacaoDiscComboBoxTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.avaliacaoDiscComboBoxTipo.FormattingEnabled = true;
			this.avaliacaoDiscComboBoxTipo.Location = new System.Drawing.Point(472, 51);
			this.avaliacaoDiscComboBoxTipo.Name = "avaliacaoDiscComboBoxTipo";
			this.avaliacaoDiscComboBoxTipo.Size = new System.Drawing.Size(228, 21);
			this.avaliacaoDiscComboBoxTipo.TabIndex = 30;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(469, 24);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(93, 13);
			this.label18.TabIndex = 29;
			this.label18.Text = "Tipo de Avaliação";
			// 
			// avaliacaoDisciplinaComboBoxCadeira
			// 
			this.avaliacaoDisciplinaComboBoxCadeira.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.avaliacaoDisciplinaComboBoxCadeira.FormattingEnabled = true;
			this.avaliacaoDisciplinaComboBoxCadeira.Location = new System.Drawing.Point(36, 117);
			this.avaliacaoDisciplinaComboBoxCadeira.Name = "avaliacaoDisciplinaComboBoxCadeira";
			this.avaliacaoDisciplinaComboBoxCadeira.Size = new System.Drawing.Size(228, 21);
			this.avaliacaoDisciplinaComboBoxCadeira.TabIndex = 28;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(33, 90);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(43, 13);
			this.label19.TabIndex = 27;
			this.label19.Text = "Cadeira";
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(33, 25);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(34, 13);
			this.label23.TabIndex = 26;
			this.label23.Text = "Curso";
			// 
			// avaliacaoDisciplinaComboBoxCurso
			// 
			this.avaliacaoDisciplinaComboBoxCurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.avaliacaoDisciplinaComboBoxCurso.FormattingEnabled = true;
			this.avaliacaoDisciplinaComboBoxCurso.Location = new System.Drawing.Point(36, 51);
			this.avaliacaoDisciplinaComboBoxCurso.Name = "avaliacaoDisciplinaComboBoxCurso";
			this.avaliacaoDisciplinaComboBoxCurso.Size = new System.Drawing.Size(228, 21);
			this.avaliacaoDisciplinaComboBoxCurso.TabIndex = 25;
			this.avaliacaoDisciplinaComboBoxCurso.SelectedIndexChanged += new System.EventHandler(this.avaliacaoDisciplinaComboBoxCurso_SelectedIndexChanged);
			// 
			// avaliacaoDisciplinaDataText
			// 
			this.avaliacaoDisciplinaDataText.Location = new System.Drawing.Point(618, 117);
			this.avaliacaoDisciplinaDataText.Name = "avaliacaoDisciplinaDataText";
			this.avaliacaoDisciplinaDataText.Size = new System.Drawing.Size(117, 20);
			this.avaliacaoDisciplinaDataText.TabIndex = 18;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(618, 91);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(30, 13);
			this.label21.TabIndex = 17;
			this.label21.Text = "Data";
			// 
			// avaliacaoDisciplinaFatorPondText
			// 
			this.avaliacaoDisciplinaFatorPondText.Location = new System.Drawing.Point(462, 117);
			this.avaliacaoDisciplinaFatorPondText.Name = "avaliacaoDisciplinaFatorPondText";
			this.avaliacaoDisciplinaFatorPondText.Size = new System.Drawing.Size(117, 20);
			this.avaliacaoDisciplinaFatorPondText.TabIndex = 16;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(462, 91);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(107, 13);
			this.label22.TabIndex = 15;
			this.label22.Text = "Fator de Ponderação";
			// 
			// avaliacaoDisciplinaLimpar
			// 
			this.avaliacaoDisciplinaLimpar.Location = new System.Drawing.Point(391, 359);
			this.avaliacaoDisciplinaLimpar.Name = "avaliacaoDisciplinaLimpar";
			this.avaliacaoDisciplinaLimpar.Size = new System.Drawing.Size(75, 23);
			this.avaliacaoDisciplinaLimpar.TabIndex = 9;
			this.avaliacaoDisciplinaLimpar.Text = "Limpar";
			this.avaliacaoDisciplinaLimpar.UseVisualStyleBackColor = true;
			this.avaliacaoDisciplinaLimpar.Click += new System.EventHandler(this.avaliacaoDisciplinaLimpar_Click);
			// 
			// avaliacaoDisciplinaConfirmar
			// 
			this.avaliacaoDisciplinaConfirmar.Location = new System.Drawing.Point(287, 359);
			this.avaliacaoDisciplinaConfirmar.Name = "avaliacaoDisciplinaConfirmar";
			this.avaliacaoDisciplinaConfirmar.Size = new System.Drawing.Size(75, 23);
			this.avaliacaoDisciplinaConfirmar.TabIndex = 8;
			this.avaliacaoDisciplinaConfirmar.Text = "Confirmar";
			this.avaliacaoDisciplinaConfirmar.UseVisualStyleBackColor = true;
			this.avaliacaoDisciplinaConfirmar.Click += new System.EventHandler(this.avaliacaoDisciplinaConfirmar_Click);
			// 
			// tabPage7
			// 
			this.tabPage7.Controls.Add(this.notaAlunoAvaliacaoNotaText);
			this.tabPage7.Controls.Add(this.label27);
			this.tabPage7.Controls.Add(this.notaAlunoAvalComboBoxAval);
			this.tabPage7.Controls.Add(this.label26);
			this.tabPage7.Controls.Add(this.notaAlunoAvalListBoxAlunos);
			this.tabPage7.Controls.Add(this.notaAlunoAvalPesquisar);
			this.tabPage7.Controls.Add(this.notaAlunoAvalComboBoxCadeira);
			this.tabPage7.Controls.Add(this.label20);
			this.tabPage7.Controls.Add(this.notaAlunoAvalNomeText);
			this.tabPage7.Controls.Add(this.label24);
			this.tabPage7.Controls.Add(this.label25);
			this.tabPage7.Controls.Add(this.notaAlunoAvalComboBoxCurso);
			this.tabPage7.Controls.Add(this.notaAlunoAvalLimpar);
			this.tabPage7.Controls.Add(this.notaAlunoAvalConfirmar);
			this.tabPage7.Location = new System.Drawing.Point(4, 22);
			this.tabPage7.Name = "tabPage7";
			this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage7.Size = new System.Drawing.Size(796, 427);
			this.tabPage7.TabIndex = 6;
			this.tabPage7.Text = "NotaAlunoAvaliacao";
			this.tabPage7.UseVisualStyleBackColor = true;
			// 
			// notaAlunoAvaliacaoNotaText
			// 
			this.notaAlunoAvaliacaoNotaText.Location = new System.Drawing.Point(379, 253);
			this.notaAlunoAvaliacaoNotaText.Name = "notaAlunoAvaliacaoNotaText";
			this.notaAlunoAvaliacaoNotaText.Size = new System.Drawing.Size(104, 20);
			this.notaAlunoAvaliacaoNotaText.TabIndex = 22;
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(376, 227);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(30, 13);
			this.label27.TabIndex = 21;
			this.label27.Text = "Nota";
			// 
			// notaAlunoAvalComboBoxAval
			// 
			this.notaAlunoAvalComboBoxAval.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.notaAlunoAvalComboBoxAval.FormattingEnabled = true;
			this.notaAlunoAvalComboBoxAval.Location = new System.Drawing.Point(379, 187);
			this.notaAlunoAvalComboBoxAval.Name = "notaAlunoAvalComboBoxAval";
			this.notaAlunoAvalComboBoxAval.Size = new System.Drawing.Size(228, 21);
			this.notaAlunoAvalComboBoxAval.TabIndex = 20;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(376, 160);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(54, 13);
			this.label26.TabIndex = 19;
			this.label26.Text = "Avaliação";
			// 
			// notaAlunoAvalListBoxAlunos
			// 
			this.notaAlunoAvalListBoxAlunos.FormattingEnabled = true;
			this.notaAlunoAvalListBoxAlunos.Location = new System.Drawing.Point(37, 130);
			this.notaAlunoAvalListBoxAlunos.Name = "notaAlunoAvalListBoxAlunos";
			this.notaAlunoAvalListBoxAlunos.Size = new System.Drawing.Size(209, 173);
			this.notaAlunoAvalListBoxAlunos.TabIndex = 18;
			this.notaAlunoAvalListBoxAlunos.DoubleClick += new System.EventHandler(this.notaAlunoAvalListBoxAlunos_DoubleClick);
			// 
			// notaAlunoAvalPesquisar
			// 
			this.notaAlunoAvalPesquisar.Location = new System.Drawing.Point(37, 89);
			this.notaAlunoAvalPesquisar.Name = "notaAlunoAvalPesquisar";
			this.notaAlunoAvalPesquisar.Size = new System.Drawing.Size(75, 23);
			this.notaAlunoAvalPesquisar.TabIndex = 17;
			this.notaAlunoAvalPesquisar.Text = "Pesquisar";
			this.notaAlunoAvalPesquisar.UseVisualStyleBackColor = true;
			this.notaAlunoAvalPesquisar.Click += new System.EventHandler(this.notaAlunoAvalPesquisar_Click);
			// 
			// notaAlunoAvalComboBoxCadeira
			// 
			this.notaAlunoAvalComboBoxCadeira.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.notaAlunoAvalComboBoxCadeira.FormattingEnabled = true;
			this.notaAlunoAvalComboBoxCadeira.Location = new System.Drawing.Point(379, 121);
			this.notaAlunoAvalComboBoxCadeira.Name = "notaAlunoAvalComboBoxCadeira";
			this.notaAlunoAvalComboBoxCadeira.Size = new System.Drawing.Size(228, 21);
			this.notaAlunoAvalComboBoxCadeira.TabIndex = 16;
			this.notaAlunoAvalComboBoxCadeira.SelectedIndexChanged += new System.EventHandler(this.notaAlunoAvalComboBoxCadeira_SelectedIndexChanged);
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(376, 94);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(43, 13);
			this.label20.TabIndex = 15;
			this.label20.Text = "Cadeira";
			// 
			// notaAlunoAvalNomeText
			// 
			this.notaAlunoAvalNomeText.Location = new System.Drawing.Point(37, 55);
			this.notaAlunoAvalNomeText.Name = "notaAlunoAvalNomeText";
			this.notaAlunoAvalNomeText.Size = new System.Drawing.Size(209, 20);
			this.notaAlunoAvalNomeText.TabIndex = 14;
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(34, 29);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(80, 13);
			this.label24.TabIndex = 13;
			this.label24.Text = "Nome de Aluno";
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(376, 29);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(34, 13);
			this.label25.TabIndex = 12;
			this.label25.Text = "Curso";
			// 
			// notaAlunoAvalComboBoxCurso
			// 
			this.notaAlunoAvalComboBoxCurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.notaAlunoAvalComboBoxCurso.FormattingEnabled = true;
			this.notaAlunoAvalComboBoxCurso.Location = new System.Drawing.Point(379, 55);
			this.notaAlunoAvalComboBoxCurso.Name = "notaAlunoAvalComboBoxCurso";
			this.notaAlunoAvalComboBoxCurso.Size = new System.Drawing.Size(228, 21);
			this.notaAlunoAvalComboBoxCurso.TabIndex = 11;
			this.notaAlunoAvalComboBoxCurso.SelectedIndexChanged += new System.EventHandler(this.notaAlunoAvalComboBoxCurso_SelectedIndexChanged);
			// 
			// notaAlunoAvalLimpar
			// 
			this.notaAlunoAvalLimpar.Location = new System.Drawing.Point(391, 359);
			this.notaAlunoAvalLimpar.Name = "notaAlunoAvalLimpar";
			this.notaAlunoAvalLimpar.Size = new System.Drawing.Size(75, 23);
			this.notaAlunoAvalLimpar.TabIndex = 9;
			this.notaAlunoAvalLimpar.Text = "Limpar";
			this.notaAlunoAvalLimpar.UseVisualStyleBackColor = true;
			this.notaAlunoAvalLimpar.Click += new System.EventHandler(this.notaAlunoAvalLimpar_Click);
			// 
			// notaAlunoAvalConfirmar
			// 
			this.notaAlunoAvalConfirmar.Location = new System.Drawing.Point(287, 359);
			this.notaAlunoAvalConfirmar.Name = "notaAlunoAvalConfirmar";
			this.notaAlunoAvalConfirmar.Size = new System.Drawing.Size(75, 23);
			this.notaAlunoAvalConfirmar.TabIndex = 8;
			this.notaAlunoAvalConfirmar.Text = "Confirmar";
			this.notaAlunoAvalConfirmar.UseVisualStyleBackColor = true;
			this.notaAlunoAvalConfirmar.Click += new System.EventHandler(this.notaAlunoAvalConfirmar_Click);
			// 
			// Form3
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.TabControl);
			this.Name = "Form3";
			this.Text = "Form3";
			this.tabPage3.ResumeLayout(false);
			this.tabPage3.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.TabControl.ResumeLayout(false);
			this.tabPage4.ResumeLayout(false);
			this.tabPage4.PerformLayout();
			this.tabPage5.ResumeLayout(false);
			this.tabPage5.PerformLayout();
			this.tabPage6.ResumeLayout(false);
			this.tabPage6.PerformLayout();
			this.tabPage7.ResumeLayout(false);
			this.tabPage7.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.ComboBox alunoDisciplinaComboBoxCadeira;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox alunoDisciplinaNomeText;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox alunoDisciplinaComboBoxCurso;
		private System.Windows.Forms.Button alunoDisciplinaLimpar;
		private System.Windows.Forms.Button alunoDisciplinaConfirmar;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Button alunoCursoLimpar;
		private System.Windows.Forms.Button alunoCursoConfirmar;
		private System.Windows.Forms.TextBox alunoCursoNomeText;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox alunoCursoComboBoxCurso;
		private System.Windows.Forms.ComboBox alunoCursoComboBoxPessoa;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.Button pessoaLimpar;
		private System.Windows.Forms.Button pessoaConfirmar;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox pessoaCC;
		private System.Windows.Forms.TextBox pessoaNome;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TabControl TabControl;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.TextBox cursoNomeCursoText;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Button cursoLimpar;
		private System.Windows.Forms.Button cursoConfirmar;
		private System.Windows.Forms.TextBox cursoCodigoCursoText;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox cursoDescricaoCursoText;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox cursoNumbECTSText;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.RadioButton cursoPosDocRadio;
		private System.Windows.Forms.RadioButton cursoDoutoramentoRadio;
		private System.Windows.Forms.RadioButton cursoMestradoRadio;
		private System.Windows.Forms.RadioButton cursoLicenciaturaRadio;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.TextBox disciplinaCursoDescDiscText;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox disciplinaCursoNumbECTSText;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox disciplinaCursoCodigoDiscText;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox disciplinaCursoNomeDiscText;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Button disciplinaCursoLimpar;
		private System.Windows.Forms.Button disciplinaCursoConfirmar;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.ComboBox disciplinaCursoComboBoxCurso;
		private System.Windows.Forms.TextBox disciplinaCursoCriteriosDiscText;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TabPage tabPage6;
		private System.Windows.Forms.ComboBox avaliacaoDisciplinaComboBoxCadeira;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.ComboBox avaliacaoDisciplinaComboBoxCurso;
		private System.Windows.Forms.TextBox avaliacaoDisciplinaDataText;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.TextBox avaliacaoDisciplinaFatorPondText;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Button avaliacaoDisciplinaLimpar;
		private System.Windows.Forms.ComboBox avaliacaoDiscComboBoxTipo;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Button avaliacaoDisciplinaConfirmar;
		private System.Windows.Forms.Button alunoDisciplinaPesquisar;
		private System.Windows.Forms.ListBox alunoDisciplinaListBoxAlunos;
		private System.Windows.Forms.TabPage tabPage7;
		private System.Windows.Forms.ListBox notaAlunoAvalListBoxAlunos;
		private System.Windows.Forms.Button notaAlunoAvalPesquisar;
		private System.Windows.Forms.ComboBox notaAlunoAvalComboBoxCadeira;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.TextBox notaAlunoAvalNomeText;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.ComboBox notaAlunoAvalComboBoxCurso;
		private System.Windows.Forms.Button notaAlunoAvalLimpar;
		private System.Windows.Forms.Button notaAlunoAvalConfirmar;
		private System.Windows.Forms.ComboBox notaAlunoAvalComboBoxAval;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox notaAlunoAvaliacaoNotaText;
		private System.Windows.Forms.Label label27;
	}
}