﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontEnd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            listaCursos.DataSource = carregaCursos();
            listaCursos.SelectedItem = null;

            listaCadeiras.Enabled = false;
            PesquisaIntermediaListBox.Items.Clear();

			PesquisaFinalListBox.Enabled = false;
		}

        // Web Service
        ServicoWeb theWebSvc = new ServicoWeb();

		Dictionary<string, string> dictID_Avaliacao = new Dictionary<string, string>();
		Dictionary<string, string> dictID_Curso = new Dictionary<string, string>();
		Dictionary<string, string> dictID_Cadeira = new Dictionary<string, string>();

		bool bPesquisaDisciplina = false;
		bool bPesquisaAluno = false;
		bool bPesquisaCadeira = false;

        private List<string> carregaCursos()
        {
			// Limpar dicionário de cursos
			dictID_Curso = new Dictionary<string, string>();

			List<string> Graus = new List<string>() { "Licenciatura" , "Mestrado", "Doutoramento"/*, "Pos-Doutoramento"*/};
            List<string> Cursos = new List<string>();
            string sResposta = "", sErro = "";

            for (int i = 0; i < Graus.Count; i++)
            {
                sResposta = theWebSvc.cursosDeGrau(Graus[i]);

				if (sResposta.Contains("Erro"))
				{
					sErro += "Não foi possível conetar-se à BD de " + Graus[i] + "\n";
					continue;
				}

                // Split por >>
                string[] saCursos = sResposta.Split(
                    new[] { ">>" },
                    StringSplitOptions.None
                );
				
                for (int j = 0; j < saCursos.Length - 1; j++) {

					string[] saIds = saCursos[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					dictID_Curso.Add(saIds[1], saIds[0]);

					Cursos.Add(saIds[1]);
                }
                   
            }

			if (!sErro.Equals(""))
				MessageBox.Show(sErro);

			return Cursos;

        }

		private void Inserir_Click(object sender, EventArgs e)
		{
			Form2 managementForm = new Form2();
			managementForm.Location = this.Location;
			managementForm.StartPosition = this.StartPosition;
			managementForm.FormClosing += delegate { this.Show(); };
			managementForm.Show();
			this.Hide();
		}

        // Começa a true, logo se mudou quer dizer que foi selecionado a opção de pesquisa por nome
        private void Num_AlunoRB_CheckedChanged(object sender, EventArgs e)
        {
            PesquisaAlunoLabel.Text = "Nome";
            if (Num_AlunoRB.Checked == true)
            {
                PesquisaAlunoLabel.Text = "Número";
            }
        }

        // Pesquisar aluno
        private void PesquisaAlunoButton_Click(object sender, EventArgs e)
        {
			bPesquisaAluno = true;
			bPesquisaDisciplina = false;
			bPesquisaCadeira = false;

			// Limpar listBox
			PesquisaIntermediaListBox.Items.Clear();

            string sPadraoNum = @"^[a,A,m,M,d,D,pd,PD].[0-9]*$";
            string sPadraoNome = @"[\p{L}\w]+";
            string sResult = "";
            Regex regex;
            
            // Esta a espera de receber um inteiro com string (a37032, e.g)
            if (Num_AlunoRB.Checked == true){

                regex = new Regex(sPadraoNum);
                if (regex.IsMatch(PesquisaAlunoTB.Text))
                {
                    sResult = theWebSvc.listAlunoUsandoNumero(PesquisaAlunoTB.Text);
                    // Resposta vazia
                    if (sResult == "")
                    {
						PesquisaIntermediaListBox.Items.Add("Não foram encontrados alunos com o número introduzido!");
                    }
                    else {

						string[] saIDS = sResult.Split(
						new[] { "#" },
						StringSplitOptions.None
						);

						if (saIDS[1].Equals("") || saIDS[2].Equals(""))
							PesquisaIntermediaListBox.Items.Add("Não foram encontrados alunos com o número introduzido!");
						else
							PesquisaIntermediaListBox.Items.Add(saIDS[0] + ". " + saIDS[1] + " - " + saIDS[2]);
                    } 
                }
                else
                {
                    MessageBox.Show("Erro: introduza o número de aluno correto!");
                }
            }
            // Pesquisa por nome
            else
            {
                regex = new Regex(sPadraoNome);
                if (regex.IsMatch(PesquisaAlunoTB.Text))
                {
                    sResult = theWebSvc.listAlunoUsandoNome(PesquisaAlunoTB.Text);

                    // Resposta vazia
                    if (sResult == "")
                    {
						PesquisaIntermediaListBox.Items.Add("Não foram encontrados alunos com o nome introduzido!");
                    }
                    else
                    {
						// Split por >>
						string[] lines = sResult.Split(
							new[] { ">>" },
							StringSplitOptions.None
						);

						for (int j = 0; j < lines.Length - 1; j++)
						{
							string[] saIDS = lines[j].Split(
							new[] { "#" },
							StringSplitOptions.None
							);

							if (saIDS.Length == 1 || saIDS[1].Equals("") || saIDS.Length == 2 || saIDS[2].Equals(""))
								continue;

							PesquisaIntermediaListBox.Items.Add(saIDS[0] + ". " + saIDS[1] + " - " + saIDS[2]);
						}
                    }
                }
                else
                {
                    MessageBox.Show("Erro!");
                }
            }

        }

		private void listBox_DoubleClick(object sender, MouseEventArgs e)
		{
			int index = this.PesquisaIntermediaListBox.IndexFromPoint(e.Location);
			if (index != System.Windows.Forms.ListBox.NoMatches)
			{
				if (bPesquisaDisciplina)
				{
					pesquisaAvaliacoes();
				}
				else if (bPesquisaAluno)
				{
					pesquisaClassificacoesDeAluno();
				}
				else if (bPesquisaCadeira)
				{
					pesquisaAvaliacoesDeCadeiraDeAluno();
				}

			}
		}

		// Quando o curso muda terá que ser atualizada a lista de cadeiras
		private void listaCursos_SelectedIndexChanged(object sender, EventArgs e)
        {

            listaCadeiras.Enabled = true;
            listaCadeiras.DataSource = carregaCadeiras();
            listaCadeiras.SelectedItem = null;
            PesquisaIntermediaListBox.Items.Add(listaCursos.SelectedText);

        }

        private List<string> carregaCadeiras()
        {
			// Limpar a informação anterior do dicionário
			dictID_Cadeira = new Dictionary<string, string>();

			List<string> Cadeiras = new List<string>();
            string cursoSelecionado = "";

            // Cuidado acrescido
            if (listaCursos.SelectedItem != null) {
                cursoSelecionado = listaCursos.SelectedItem.ToString();
            }

			// Avaliar grau
			string sGrau = (cursoSelecionado.Contains("Licenciatura") ?
				"Licenciatura" : (cursoSelecionado.Contains("Mestrado") ?
				"Mestrado" : (cursoSelecionado.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			string sResposta = theWebSvc.cadeirasDeCurso(cursoSelecionado);

			if (sResposta.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de " + sGrau + "\n");
				Cadeiras.Add("Não existem informações!");
				return Cadeiras;
			}

			string[] saCadeiras = sResposta.Split(
                new[] { ">>" },
                StringSplitOptions.None
            );

            for (int j = 0; j < saCadeiras.Length - 1; j++)
            {
				string[] saIds = saCadeiras[j].Split(
						new[] { "||" },
						StringSplitOptions.None
				);

				dictID_Cadeira.Add(saIds[1], saIds[0]);

				Cadeiras.Add(saIds[1]);
            }

            return Cadeiras;

        }

        // Pesquisar avaliações de cadeira escolhida
        private void PesquisaAvaliações_Click(object sender, EventArgs e)
        {
			bPesquisaAluno = false;
			bPesquisaDisciplina = true;
			bPesquisaCadeira = false;

			// Limpar dicionário
			dictID_Avaliacao = new Dictionary<string, string>();
			
			// Limpar listBox
            PesquisaIntermediaListBox.Items.Clear();

            string cursoSelecionado = listaCursos.SelectedItem.ToString();
            string cadeiraSelecionada = "";

            // Cuidado acrescido
            if (listaCadeiras.SelectedItem != null)
            {
                cadeiraSelecionada = listaCadeiras.SelectedItem.ToString();
                string[] saTemp = cadeiraSelecionada.Split( 
                    new[] {" . "},
                StringSplitOptions.None
                );
                cadeiraSelecionada = saTemp[1];
            }

            if (cadeiraSelecionada == "" || cursoSelecionado == "")
            {
                MessageBox.Show("Escolha ambos os campos!");
                return;
            }

			// Avaliar grau
			string sGrau = (cursoSelecionado.Contains("Licenciatura") ?
				"Licenciatura" : (cursoSelecionado.Contains("Mestrado") ?
				"Mestrado" : (cursoSelecionado.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			string sResposta = theWebSvc.avaliacoesDeCadeira(cadeiraSelecionada, cursoSelecionado);

			if (sResposta.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de " + sGrau + "\n");
				PesquisaIntermediaListBox.Items.Add("Não existem informações!");
				return ;
			}

			string[] avaliacoes = sResposta.Split(
                new[] { ">>" },
                StringSplitOptions.None
            );

			if (avaliacoes.Length == 1)
            {
                // Limpar listBox
                PesquisaIntermediaListBox.Items.Clear();
                PesquisaIntermediaListBox.Items.Add("Cadeira sem avaliações!");
            }
            else { 
                for (int j = 0; j < avaliacoes.Length - 1; j++)
                {
					string[] ids = avaliacoes[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					dictID_Avaliacao.Add(ids[0], ids[1]);

					PesquisaIntermediaListBox.Items.Add(ids[1]);
                }
            }
        }


        // --------------------------- Classes  ----------------------------

        class ComboItem
        {
            public int ID { get; set; }
            public string Text { get; set; }
        }

        public class Pessoa
        {
            public string nome { get; set; }
            public int CC { get; set; }
            public Pessoa(string nome, int CC)
            {
                this.nome = nome;
                this.CC = CC;
            }
        }

		// ----------------------------------------------------------------------------------------------------------------------------------
		// Funções auxiliares usadas na função listBox_DoubleClick() 

		private void pesquisaAvaliacoes()
		{
			PesquisaFinalListBox.Items.Clear();
			PesquisaFinalListBox.SelectedItem = null;

			string sAvaliacao = PesquisaIntermediaListBox.SelectedItem.ToString();
			string sKey = dictID_Avaliacao.FirstOrDefault(x => x.Value == sAvaliacao).Key;
			string sCurso = listaCursos.SelectedItem.ToString();

			// Avaliar grau
			string sGrau = (sCurso.Contains("Licenciatura") ?
				"Licenciatura" : (sCurso.Contains("Mestrado") ?
				"Mestrado" : (sCurso.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			string sResposta = theWebSvc.notasDeAvaliacaoDeCadeira(sKey, sCurso);

			if (sResposta.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de " + sGrau + "\n");
				PesquisaFinalListBox.Items.Add("Não existem informações!");
				PesquisaFinalListBox.Enabled = false;
				return;
			}

			string[] notas = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (notas.Length == 1)
			{
				PesquisaFinalListBox.Items.Add("Ainda sem classificações!");
			}
			else
			{
				for (int j = 0; j < notas.Length - 1; j++)
				{
					string[] ids = notas[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					// Adicionar identificador associado ao grau do curso
					string sNumber = (sCurso.Contains("Licenciatura") ?
							"a" : (sCurso.Contains("Mestrado") ?
							"m" : (sCurso.Contains("Doutoramento") ?
							"d" : "pd"))) + ids[0];

					string sNome = theWebSvc.getNomeAlunoUsandoNumero(sNumber);

					if (sNome.Contains("Erro"))
					{
						MessageBox.Show("Não foi possível conetar-se à BD de " + sGrau + "\n");
						PesquisaFinalListBox.Items.Add("Não existem informações!");
						PesquisaFinalListBox.Enabled = false;
						return;
					}

					PesquisaFinalListBox.Items.Add(sNumber + ". " + sNome + " : " + ids[1]);
				}
			}
		}

		string sNumber = "";
		string sCurso = "";

		private void pesquisaClassificacoesDeAluno()
		{
			bPesquisaDisciplina = false;
			bPesquisaAluno = false;
			bPesquisaCadeira = true;

			string sAluno = PesquisaIntermediaListBox.SelectedItem.ToString();

			// Limpar listBox
			PesquisaIntermediaListBox.Items.Clear();

			// Limpar dicionário
			dictID_Cadeira = new Dictionary<string, string>();

			string[] saIdAluno = sAluno.Split(
				new[] { ". " },
				StringSplitOptions.None
			);

			sNumber = saIdAluno[0];
			sCurso = sNumber.Contains("a") ?
				"Licenciatura" : sNumber.Contains("m") ?
				"Mestrado" : sNumber.Contains("d") ?
				"Doutoramento" : "Pos-Doutoramento";

			string sResposta = theWebSvc.cadeirasDeAluno(sNumber);

			if (sResposta.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de " + sCurso + "\n");
				PesquisaIntermediaListBox.Items.Add("Não existem informações!");
				PesquisaIntermediaListBox.Enabled = false;
				return;
			}

			string[] saCadeiras = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (saCadeiras.Length == 1)
			{
				// Limpar listBox
				PesquisaIntermediaListBox.Items.Clear();
				PesquisaIntermediaListBox.Items.Add("Aluno sem cadeiras!");
			}
			else
			{
				for (int j = 0; j < saCadeiras.Length - 1; j++)
				{
					string[] saIds = saCadeiras[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					dictID_Cadeira.Add(saIds[0], saIds[1]);

					PesquisaIntermediaListBox.Items.Add(saIds[1]);
				}
			}
		}

		private void pesquisaAvaliacoesDeCadeiraDeAluno()
		{
			PesquisaFinalListBox.Items.Clear();
			PesquisaFinalListBox.SelectedItem = null;

			string sCadeira = PesquisaIntermediaListBox.SelectedItem.ToString();
			string sID_Cadeira = dictID_Cadeira.FirstOrDefault(x => x.Value == sCadeira).Key;
			if ( sID_Cadeira == null || sNumber.Equals("") || sCurso.Equals(""))
			{
				PesquisaFinalListBox.Items.Add("Dados inválidos!");

				return;
			}

			string sID_Aluno = sNumber.Contains("a") ?
				sNumber.Substring(1) : sNumber.Contains("m") ?
				sNumber.Substring(1) : sNumber.Contains("d") ?
				sNumber.Substring(1) : sNumber.Substring(2);

			// Avaliar grau
			string sGrau = (sCurso.Contains("Licenciatura") ?
				"Licenciatura" : (sCurso.Contains("Mestrado") ?
				"Mestrado" : (sCurso.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			string sResposta = theWebSvc.avaliacoesDeAlunoEmCadeira(sID_Aluno, sID_Cadeira, sCurso);

			if (sResposta.Contains("Erro"))
			{
				MessageBox.Show("Não foi possível conetar-se à BD de " + sGrau + "\n");
				PesquisaFinalListBox.Items.Add("Não existem informações!");
				PesquisaFinalListBox.Enabled = false;
				return;
			}

			string[] saNotas = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (saNotas.Length == 1)
			{
				PesquisaFinalListBox.Items.Add("Ainda sem avaliações!");
			}
			else
			{
				for (int j = 0; j < saNotas.Length - 1; j++)
				{
					PesquisaFinalListBox.Items.Add(saNotas[j]);
				}
			}
		}
	
	}
}
