﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontEnd
{
	public partial class Form4 : Form
	{
		public Form4()
		{
			InitializeComponent();

			// Obter informação dos cursos disponíveis em todos os graus
			List<string> cursos = carregaCursos();
			int iNum = cursos.Count;
			if (iNum == 0)
			{
				cursos.Add("Não existem cursos!");
			}

			// Preencher as comboBox de cursos com essa informação
			cursoComboBoxCurso.Items.Clear();
			cursoComboBoxCurso.DataSource = cursos;
			cursoComboBoxCurso.SelectedIndex = 0;

			disciplinaCursoComboBoxCurso.Items.Clear();
			disciplinaCursoComboBoxCurso.DataSource = cursos;
			disciplinaCursoComboBoxCurso.SelectedIndex = 0;

			avaliacaoDisciplinaComboBoxCurso.Items.Clear();
			avaliacaoDisciplinaComboBoxCurso.DataSource = cursos;
			avaliacaoDisciplinaComboBoxCurso.SelectedIndex = 0;

			if (iNum == 0)
			{
				cursoComboBoxCurso.Enabled = false;
			}

			// Preenchido e escolhido automaticamente pela seleção de um aluno
			alunoDisciplinaComboBoxCurso.Enabled = false;
			notaAlunoAvalComboBoxCurso.Enabled = false;
		}

		/*// Sempre que muda de Tab atualizar os valores
		private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
		{
			alunoCursoNomeText.Text = "";

			// Obter informação dos cursos disponíveis em todos os graus
			List<string> cursos = carregaCursos();
			int iNum = cursos.Count;
			if (iNum == 0)
			{
				cursos.Add("Não existem cursos!");
			}

			// Preencher as comboBox de cursos com essa informação
			alunoCursoComboBoxCurso.DataSource = null;
			alunoCursoComboBoxCurso.Items.Clear();
			alunoCursoComboBoxCurso.DataSource = cursos;
			alunoCursoComboBoxCurso.SelectedIndex = 0;

			cursoComboBoxCurso.DataSource = null;
			cursoComboBoxCurso.Items.Clear();
			cursoComboBoxCurso.DataSource = cursos;
			cursoComboBoxCurso.SelectedIndex = 0;

			if (iNum == 0)
			{
				alunoCursoComboBoxCurso.Enabled = false;
				cursoComboBoxCurso.Enabled = false;
			}

			// Preenchido e escolhido automaticamente pela seleção de um aluno
			alunoDisciplinaComboBoxCurso.Enabled = false;

			// Colocar a informação dos alunos na comboBox respetiva
			carregaAlunos("");
		}*/

		// Web Service
		ServicoWeb theWebSvc = new ServicoWeb();

		// Dicionários que permitem identificar qual o ID associado a um nome ou descrição
		Dictionary<string, string> dictID_Curso = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Aluno = new Dictionary<string, string>();
		Dictionary<string, string> dictID_Aluno_Curso = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Cadeira = new Dictionary<string, string>();
		Dictionary<string, string> dictID_Cadeira_Nota = new Dictionary<string, string>();

		Dictionary<string, string> dictID_Avaliacao = new Dictionary<string, string>();


		// Função auxiliar que preenche a comboBox com os diversos cursos
		private List<string> carregaCursos()
		{
			// Limpar datasource antes de realizar modificações
			alunoDisciplinaComboBoxCurso.DataSource = null;
			disciplinaCursoComboBoxCurso.DataSource = null;

			// Limpar a comboBox antes de preencher
			alunoDisciplinaComboBoxCurso.Items.Clear();
			disciplinaCursoComboBoxCurso.Items.Clear();

			// Limpar a informação anterior do dicionário
			dictID_Curso = new Dictionary<string, string>();

			List<string> Graus = new List<string>() { "Licenciatura", "Mestrado", "Doutoramento"/*, "Pos-Doutoramento"*/ };
			List<string> Cursos = new List<string>();
			string sResposta = "", sErro = "";

			for (int i = 0; i < Graus.Count; i++)
			{
				sResposta = theWebSvc.cursosDeGrau(Graus[i]);

				if (sResposta.Equals("Erro"))
				{
					sErro += "Não foi possível conetar-se à BD de " + Graus[i] + "\n";
					continue;
				}

				// Split por >>
				string[] saCursos = sResposta.Split(
					new[] { ">>" },
					StringSplitOptions.None
				);
				for (int j = 0; j < saCursos.Length - 1; j++)
				{
					string[] saIds = saCursos[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					dictID_Curso.Add(saIds[1], saIds[0]);

					Cursos.Add(saIds[1]);
				}

			}

			if (!sErro.Equals(""))
				MessageBox.Show(sErro);

			return Cursos;
		}

		// Carregar os alunos existentes com base no nome introduzido
		private void carregaAlunos(string sNome)
		{
			alunoDisciplinaListBoxAlunos.Items.Clear();
			alunoDisciplinaListBoxAlunos.SelectedItem = null;

			notaAlunoAvalListBoxAlunos.Items.Clear();
			notaAlunoAvalListBoxAlunos.SelectedItem = null;

			// Limpar a informação anterior do dicionário
			dictID_Aluno = new Dictionary<string, string>();
			dictID_Aluno_Curso = new Dictionary<string, string>();

			string sID_Aluno = theWebSvc.listAlunoUsandoNome(sNome);

			// Split por >>
			string[] saAlunos = sID_Aluno.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			for (int j = 0; j < saAlunos.Length - 1; j++)
			{
				string[] saIds = saAlunos[j].Split('#');

				// Newline resultante da última linha
				if (saIds.Length == 1)
					continue;

				if (saIds[1].Equals(""))
					continue;

				string sResultado = saIds[0] + ". " + saIds[1] + " " + saIds[2];

				dictID_Aluno.Add(saIds[0], sResultado);
				dictID_Aluno_Curso.Add(saIds[0], saIds[2]);

				alunoDisciplinaListBoxAlunos.Items.Add(sResultado);
				notaAlunoAvalListBoxAlunos.Items.Add(sResultado);
			}
		}


		// ----------------------------- Tab AlunoDisciplina -----------------------------------------------------

		// Quando o curso muda terá que ser atualizada a lista de cadeiras
		private void alunoDisciplinaComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			string sAluno = alunoDisciplinaListBoxAlunos.SelectedItem.ToString();
			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;

			alunoDisciplinaComboBoxCadeira.Enabled = true;
			alunoDisciplinaComboBoxCadeira.DataSource = null;
			List<string> lsCadeiras = carregaCadeirasAluno(sID_Aluno);
			int iNum = lsCadeiras.Count;

			if (iNum == 0)
			{
				lsCadeiras.Add("Curso sem Cadeiras!");
			}

			alunoDisciplinaComboBoxCadeira.DataSource = lsCadeiras;
			alunoDisciplinaComboBoxCadeira.SelectedItem = 0;
		}

		// Carregar as cadeiras relativamente à matrícula de um aluno
		private List<string> carregaCadeirasAluno(string sID_Aluno)
		{
			// Limpar a informação anterior do dicionário
			dictID_Cadeira = new Dictionary<string, string>();
			dictID_Cadeira_Nota = new Dictionary<string, string>();

			List<string> Cadeiras = new List<string>();

			string sResposta = theWebSvc.cadeirasDeAluno(sID_Aluno);

			string[] saCadeiras = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);


			if (saCadeiras.Length == 1)
			{
				// Limpar comboBox
				alunoDisciplinaComboBoxCadeira.Items.Clear();
				Cadeiras.Add("Não existem cadeiras!");
				alunoDisciplinaComboBoxCadeira.Enabled = false;
			}

			for (int j = 0; j < saCadeiras.Length - 1; j++)
			{
				string[] saIds = saCadeiras[j].Split(
						new[] { "||" },
						StringSplitOptions.None
				);

				// Newline resultante da última linha
				if (saIds.Length == 1)
					continue;

				string[] saNota = saIds[1].Split(
						new[] { " : " },
						StringSplitOptions.None
				);

				// Newline resultante da última linha
				if (saNota.Length == 1)
					continue;

				dictID_Cadeira.Add(saIds[0], saNota[0]);
				dictID_Cadeira_Nota.Add(saIds[0], saNota[1]);

				Cadeiras.Add(saNota[0]);
			}

			return Cadeiras;
		}

		// Aquando do clique do botão Confirmar na tab de AlunoDisciplina, é feita a atualização da nota de um aluno numa disciplina
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void alunoDisciplinaConfirmar_Click(object sender, EventArgs e)
		{
			/*string sAluno = alunoDisciplinaListBoxAlunos.SelectedItem.ToString();
			string sCadeira = alunoDisciplinaComboBoxCadeira.Text.ToString();
			string sNota = alunoDisciplinaNotaText.Text.ToString();

			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sID_Cadeira = dictID_Cadeira.FirstOrDefault(x => x.Key == sCadeira).Value;

			string sResult = theWebSvc.updateAlunoDisciplina(sID_Inscricao ,sNota, sID_Aluno);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Aluno inscrito com sucesso!");
			}
			else
			{
				MessageBox.Show("Aluno inscrito sem sucesso!");
			}*/
		}

		private void alunoDisciplinaPesquisar_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Preciso do ID de inscrição --> fazer uma pessoa para devolver o ID de inscrição OU passar o ID de cadeira e ID de aluno (podem haver múltiplas inscrições tho)");
			string sNome = alunoDisciplinaNomeText.Text.ToString();

			carregaAlunos(sNome);
		}

		// Função que permite limpar as informações existentes
		private void alunoDisciplinaLimpar_Click(object sender, EventArgs e)
		{
			alunoDisciplinaNomeText.Text = "";

			alunoDisciplinaListBoxAlunos.SelectedItem = null;
			alunoDisciplinaListBoxAlunos.Items.Clear();

			alunoDisciplinaComboBoxCurso.SelectedItem = null;
			alunoDisciplinaComboBoxCurso.Items.Clear();

			alunoDisciplinaComboBoxCadeira.DataSource = null;
			alunoDisciplinaComboBoxCadeira.SelectedItem = null;
			alunoDisciplinaComboBoxCadeira.Items.Clear();

			alunoDisciplinaNotaText.Text = "";
		}

		// Quando selecionado o aluno, escrever automaticamente o curso no DropDown
		private void alunoDisciplinaListBoxAlunos_DoubleClick(object sender, EventArgs e)
		{
			string sAluno = alunoDisciplinaListBoxAlunos.SelectedItem.ToString();
			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sCurso = dictID_Aluno_Curso.FirstOrDefault(x => x.Key == sID_Aluno).Value;

			alunoDisciplinaComboBoxCurso.Items.Clear();
			alunoDisciplinaComboBoxCurso.SelectedItem = null;
			alunoDisciplinaComboBoxCurso.Items.Add(sCurso);
			alunoDisciplinaComboBoxCurso.SelectedIndex = 0;
		}

		// Sempre que se muda a cadeira atualizar a respetiva nota
		private void alunoDisciplinaComboBoxCadeira_SelectedIndexChanged(object sender, EventArgs e)
		{
			alunoDisciplinaNotaText.Text = "";

			string sCadeira = "", sID_cadeira = "", sNota = "";
			if (alunoDisciplinaComboBoxCadeira.SelectedItem != null)
				sCadeira = alunoDisciplinaComboBoxCadeira.SelectedItem.ToString();
			if (sCadeira == null)
				return;
			sID_cadeira = dictID_Cadeira.FirstOrDefault(x => x.Value == sCadeira).Key;
			if (sID_cadeira == null)
				return;
			sNota = dictID_Cadeira_Nota.FirstOrDefault(x => x.Key == sID_cadeira).Value;
			if (sNota == null)
				return;
			alunoDisciplinaNotaText.Text = sNota;
		}


		// ----------------------------- Tab Curso -----------------------------------------------------

		// Aquando do clique do botão Confirmar na tab de Curso, é feita a atualização do curso na base de dados respetiva
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void cursoConfirmar_Click(object sender, EventArgs e)
		{
			string sNome = cursoNomeCursoText.Text.ToString();
			string sCodigo = cursoCodigoCursoText.Text.ToString();
			string sNumbECTS = cursoNumbECTSText.Text.ToString();
			string sDescricao = cursoDescricaoCursoText.Text.ToString();

			string sCurso = "";
			if (cursoComboBoxCurso.SelectedItem != null)
				sCurso = cursoComboBoxCurso.SelectedItem.ToString();
			string sID_Curso = dictID_Curso.FirstOrDefault(x => x.Key == sCurso).Value;
			if (sID_Curso == null)
				return;

			string sGrau = tabPage4.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked).Text;

			sDescricao += " - " + sGrau;

			string sResult = theWebSvc.updateCurso(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Curso criado com sucesso!");
			}
			else
			{
				MessageBox.Show("Curso criado sem sucesso!");
			}
		}

		// Função que permite limpar as informações existentes
		private void cursoLimpar_Click(object sender, EventArgs e)
		{
			cursoNomeCursoText.Text = "";
			cursoCodigoCursoText.Text = "";
			cursoNumbECTSText.Text = "";
			cursoDescricaoCursoText.Text = "";
			cursoDescricaoCursoText.Text = "";
			cursoComboBoxCurso.SelectedIndex = 0;

			tabPage4.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Text == "Licenciatura").Select();
		}

		// Sempre que é selecionado um curso diferente atualizar a sua informação
		private void cursoComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			string sCurso = "";
			if (cursoComboBoxCurso.SelectedItem != null)
				sCurso = cursoComboBoxCurso.SelectedItem.ToString();

			string sID_Curso = dictID_Curso.FirstOrDefault(x => x.Key == sCurso).Value;
			if (sID_Curso == null)
				return;

			// Avaliar grau
			string sGrau = (sCurso.Contains("Licenciatura") ?
				"Licenciatura" : (sCurso.Contains("Mestrado") ?
				"Mestrado" : (sCurso.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			tabPage4.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Text == sGrau).Select();

			string sResposta = theWebSvc.cursosInformacao(sID_Curso, sGrau);

			if (sResposta.Equals("Erro"))
			{
				MessageBox.Show("Não foram encontradas informações sobre o curso!");
				return;
			}

			string[] saCursos = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);


			if (saCursos.Length == 1)
			{
				// Informar o utilizador de que não informações sobre o curso
				MessageBox.Show("Não foram encontradas informações sobre o curso!");
			}

			for (int j = 0; j < saCursos.Length - 1; j++)
			{
				string[] saIds = saCursos[j].Split(
						new[] { "#" },
						StringSplitOptions.None
				);

				// Newline resultante da última linha
				if (saIds.Length == 1)
					continue;

				cursoNomeCursoText.Text = saIds[0];
				cursoNumbECTSText.Text = saIds[1];
				cursoCodigoCursoText.Text = saIds[2];
				cursoDescricaoCursoText.Text = saIds[3];
			}
		}


		// ----------------------------- Tab DisciplinaCurso -----------------------------------------------------

		// Aquando do clique do botão Confirmar na tab de DisciplinaCurso, é feita a atualização da disciplina no curso respetivo
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void disciplinaCursoConfirmar_Click(object sender, EventArgs e)
		{
			string sNome = disciplinaCursoNomeDiscText.Text.ToString();
			string sCodigo = disciplinaCursoCodigoDiscText.Text.ToString();
			string sNumbECTS = disciplinaCursoNumbECTSText.Text.ToString();
			string sDescricao = disciplinaCursoDescDiscText.Text.ToString();
			string sCriterios = disciplinaCursoCriteriosDiscText.Text.ToString();

			string sCurso = "";
			if (disciplinaCursoComboBoxCurso.SelectedItem != null)
				sCurso = disciplinaCursoComboBoxCurso.Text.ToString();

			string sCadeira = "";
			if (disciplinaCursoComboBoxCadeira.SelectedItem != null)
				sCadeira = disciplinaCursoComboBoxCadeira.Text.ToString();

			string sID_Curso = dictID_Curso.FirstOrDefault(x => x.Key == sCurso).Value;
			if (sID_Curso == null)
				return;

			string sID_Disc = dictID_Cadeira.FirstOrDefault(x => x.Key == sCadeira).Value;
			if (sID_Disc == null)
				return;

			string sResult = theWebSvc.updateDisciplinaCurso(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sID_Curso, sID_Disc, sCurso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Disciplina introduzida com sucesso!");
			}
			else
			{
				MessageBox.Show("Disciplina introduzida sem sucesso!");
			}
		}

		// Função que permite limpar as informações existentes
		private void disciplinaCursoLimpar_Click(object sender, EventArgs e)
		{
			disciplinaCursoNomeDiscText.Text = "";
			disciplinaCursoCodigoDiscText.Text = "";
			disciplinaCursoNumbECTSText.Text = "";
			disciplinaCursoDescDiscText.Text = "";
			disciplinaCursoComboBoxCurso.SelectedIndex = 0;
			disciplinaCursoCriteriosDiscText.Text = "";
			disciplinaCursoComboBoxCadeira.SelectedItem = null;
		}

		// Sempre que é escolhido um novo curso atualizar as disciplinas
		private void disciplinaCursoComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			string sCurso = "";
			if (disciplinaCursoComboBoxCurso.SelectedItem != null)
				sCurso = disciplinaCursoComboBoxCurso.SelectedItem.ToString();

			disciplinaCursoComboBoxCadeira.Enabled = true;
			disciplinaCursoComboBoxCadeira.DataSource = null;

			List<string> lsCadeiras = carregaCadeiras(sCurso);

			disciplinaCursoComboBoxCadeira.DataSource = lsCadeiras;
			disciplinaCursoComboBoxCadeira.SelectedItem = 0;
		}

		// Carregar as cadeiras relativamente a um curso
		// Se não existirem cadeiras então desabilitar comboBox
		private List<string> carregaCadeiras(string sCurso)
		{
			// Limpar a informação anterior do dicionário
			dictID_Cadeira = new Dictionary<string, string>();

			List<string> Cadeiras = new List<string>();

			string sResposta = theWebSvc.cadeirasDeCurso(sCurso);

			string[] saCadeiras = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (saCadeiras.Length == 1)
			{
				// Limpar comboBox
				disciplinaCursoComboBoxCadeira.DataSource = null;
				disciplinaCursoComboBoxCadeira.Items.Clear();
				Cadeiras.Add("Não existem cadeiras!");
				disciplinaCursoComboBoxCadeira.Enabled = false;
			}

			for (int j = 0; j < saCadeiras.Length - 1; j++)
			{
				string[] saIds = saCadeiras[j].Split(
						new[] { "||" },
						StringSplitOptions.None
				);

				// Newline resultante da última linha
				if (saIds.Length == 1)
					continue;

				dictID_Cadeira.Add(saIds[1], saIds[0]);

				Cadeiras.Add(saIds[1]);
			}

			return Cadeiras;

		}

		// Sempre que é escolhido uma nova cadeira atualizar informação
		private void disciplinaCursoComboBoxCadeira_SelectedIndexChanged(object sender, EventArgs e)
		{
			string sCadeira = "";
			if (disciplinaCursoComboBoxCadeira.SelectedItem != null)
				sCadeira = disciplinaCursoComboBoxCadeira.SelectedItem.ToString();

			string sID_Cadeira = dictID_Cadeira.FirstOrDefault(x => x.Key == sCadeira).Value;
			if (sID_Cadeira == null)
				return;

			string sCurso = "";
			if (disciplinaCursoComboBoxCurso.SelectedItem != null)
				sCurso = disciplinaCursoComboBoxCurso.SelectedItem.ToString();

			// Avaliar grau
			string sGrau = (sCurso.Contains("Licenciatura") ?
				"Licenciatura" : (sCurso.Contains("Mestrado") ?
				"Mestrado" : (sCurso.Contains("Doutoramento") ?
				"Doutoramento" : "Pós-Doutoramento")));

			string sResposta = theWebSvc.cadeirasInformacao(sID_Cadeira, sGrau);

			if (sResposta.Equals("Erro"))
			{
				MessageBox.Show("Não foram encontradas informações sobre a cadeira!");
				return;
			}

			string[] saCadeiras = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (saCadeiras.Length == 1)
			{
				// Informar o utilizador de que não informações sobre a cadeira
				MessageBox.Show("Não foram encontradas informações sobre a cadeira!");
			}

			for (int j = 0; j < saCadeiras.Length - 1; j++)
			{
				string[] saIds = saCadeiras[j].Split(
						new[] { "#" },
						StringSplitOptions.None
				);

				// Newline resultante da última linha
				if (saIds.Length == 1)
					continue;

				disciplinaCursoNomeDiscText.Text = saIds[0];
				disciplinaCursoCodigoDiscText.Text = saIds[1];
				disciplinaCursoCriteriosDiscText.Text = saIds[2];
				disciplinaCursoDescDiscText.Text = saIds[3];
				disciplinaCursoNumbECTSText.Text = saIds[4];
			}
		}


		// ----------------------------- Tab AvaliacaoDisciplina -----------------------------------------------------

		// Aquando do clique do botão Confirmar na tab AvaliacaoDisciplina, é feita a introdução de uma avaliação num disciplina
		// Informa o utilizador se o processo foi bem sucedido ou não
		private void avaliacaoDisciplinaConfirmar_Click(object sender, EventArgs e)
		{
			string sFator_Ponderacao = avaliacaoDisciplinaFatorPondText.Text.ToString();
			string sData = avaliacaoDisciplinaDataText.Text.ToString();
			string sAvaliacao = avaliacaoDiscComboBoxTipo.Text.ToString();
			string sCurso = avaliacaoDisciplinaComboBoxCurso.Text.ToString();

			string sID_Avaliacao = dictID_Avaliacao.FirstOrDefault(x => x.Key == sAvaliacao).Value;
			if (sID_Avaliacao == null)
				return;

			string sResult = theWebSvc.updateAvaliacaoDisciplina(sID_Avaliacao, sFator_Ponderacao, sData, sCurso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Avaliação introduzida com sucesso!");
			}
			else
			{
				MessageBox.Show("Avaliação introduzida sem sucesso!");
			}
		}

		// Carregar as avaliações de uma cadeira
		private List<string> carregaAvaliacoesCadeira(string sCurso, string sCadeira)
		{
			// Limpar dicionário
			dictID_Avaliacao = new Dictionary<string, string>();

			// Limpar datasource antes de realizar modificações
			avaliacaoDiscComboBoxTipo.DataSource = null;

			// Limpar Avaliacoes
			avaliacaoDiscComboBoxTipo.Items.Clear();
			avaliacaoDiscComboBoxTipo.SelectedItem = null;

			List<string> Avaliacoes = new List<string>();

			string sResposta = theWebSvc.avaliacoesDeCadeira(sCadeira, sCurso);

			if (sResposta.Equals("Erro"))
			{
				MessageBox.Show("Não foram encontradas informações sobre a cadeira!");
				return Avaliacoes;
			}

			string[] avaliacoes = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (avaliacoes.Length == 1)
			{
				Avaliacoes.Add("Cadeira sem avaliações!");
			}
			else
			{
				for (int j = 0; j < avaliacoes.Length - 1; j++)
				{
					string[] ids = avaliacoes[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					if (ids.Length == 1)
						continue;

					string[] resto = ids[1].Split(
						new[] { ". " },
						StringSplitOptions.None
						);

					if (resto.Length == 1)
						continue;

					string[] designacao = resto[1].Split(
						new[] { " : " },
						StringSplitOptions.None
						);

					if (designacao.Length == 1)
						continue;

					dictID_Avaliacao.Add(ids[0], designacao[0]);

					Avaliacoes.Add(designacao[0]);
				}
			}

			return Avaliacoes;
		}

		// Sempre que muda o curso, mostrar as cadeiras do mesmo e atualizar o tipo de avaliação disponível
		private void avaliacaoDisciplinaComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (avaliacaoDisciplinaComboBoxCurso.SelectedItem == null)
				return;

			string sCurso = avaliacaoDisciplinaComboBoxCurso.SelectedItem.ToString();

			avaliacaoDisciplinaComboBoxCadeira.Enabled = true;
			avaliacaoDisciplinaComboBoxCadeira.DataSource = null;

			List<string> lsCadeiras = carregaCadeiras(sCurso);
			int iNum = lsCadeiras.Count;

			if (iNum == 0)
			{
				lsCadeiras.Add("Curso sem Cadeiras!");
			}

			avaliacaoDisciplinaComboBoxCadeira.DataSource = lsCadeiras;
			avaliacaoDisciplinaComboBoxCadeira.SelectedIndex = 0;

		}

		// Função que permite limpar as informações existentes
		private void avaliacaoDisciplinaLimpar_Click(object sender, EventArgs e)
		{
			avaliacaoDisciplinaFatorPondText.Text = "";
			avaliacaoDisciplinaDataText.Text = "";
			avaliacaoDiscComboBoxTipo.SelectedIndex = 0;
			avaliacaoDisciplinaComboBoxCadeira.DataSource = null;
			avaliacaoDisciplinaComboBoxCadeira.SelectedItem = null;
			avaliacaoDisciplinaComboBoxCadeira.Items.Clear();
			avaliacaoDisciplinaComboBoxCurso.SelectedIndex = 0;
		}

		private void avaliacaoDisciplinaComboBoxCadeira_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (avaliacaoDisciplinaComboBoxCadeira.SelectedItem == null || avaliacaoDisciplinaComboBoxCurso.SelectedItem == null)
				return;

			string sCurso = avaliacaoDisciplinaComboBoxCurso.SelectedItem.ToString();
			string sNum_Cadeira = avaliacaoDisciplinaComboBoxCadeira.SelectedItem.ToString();

			string[] saNome = sNum_Cadeira.Split(
				new[] { ". " },
				StringSplitOptions.None
			);

			if (saNome.Length == 1)
				return;

			string sCadeira = saNome[1];

			avaliacaoDiscComboBoxTipo.Enabled = true;
			avaliacaoDiscComboBoxTipo.DataSource = null;

			List<string> lsAvaliacoes = carregaAvaliacoesCadeira(sCurso, sCadeira);
			int iNum = lsAvaliacoes.Count;

			avaliacaoDiscComboBoxTipo.DataSource = lsAvaliacoes;
			avaliacaoDiscComboBoxTipo.SelectedIndex = 0;
		}

		private void avaliacaoDiscComboBoxTipo_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (avaliacaoDiscComboBoxTipo.SelectedItem == null || avaliacaoDisciplinaComboBoxCurso.SelectedItem == null)
				return;

			string sAvaliacao = avaliacaoDiscComboBoxTipo.SelectedItem.ToString();
			string sCurso = avaliacaoDisciplinaComboBoxCurso.SelectedItem.ToString();

			string sID_Avaliacao = dictID_Avaliacao.FirstOrDefault(x => x.Value == sAvaliacao).Key;
			if (sID_Avaliacao == null)
				return;

			/*string sResposta = theWebSvc.avaliacoesInformacao(sID_Avaliacao, sCurso);

			if (sResposta.Equals("Erro"))
			{
				MessageBox.Show("Não foram encontradas informações sobre a cadeira!");
				return;
			}

			string[] avaliacoes = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			for (int j = 0; j < avaliacoes.Length - 1; j++)
			{
				string[] ids = avaliacoes[j].Split(
					new[] { "#" },
					StringSplitOptions.None
				);

				avaliacaoDisciplinaFatorPondText.Text = ids[0];
				avaliacaoDisciplinaDataText.Text = ids[1];
			}*/
		}


		// -----------------------------Tab NotaAlunoAvaliacao-----------------------------------------------------

		// Quando selecionado o aluno, escrever automaticamente o curso no DropDown
		private void notaAlunoAvalListBoxAlunos_DoubleClick(object sender, EventArgs e)
		{
			string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();
			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sCurso = dictID_Aluno_Curso.FirstOrDefault(x => x.Key == sID_Aluno).Value;

			notaAlunoAvalComboBoxCurso.Items.Clear();
			notaAlunoAvalComboBoxCurso.SelectedItem = null;
			notaAlunoAvalComboBoxCurso.Items.Add(sCurso);
			notaAlunoAvalComboBoxCurso.SelectedIndex = 0;
		}

		// Quando o curso muda terá que ser atualizada a lista de cadeiras
		private void notaAlunoAvalComboBoxCurso_SelectedIndexChanged(object sender, EventArgs e)
		{
			notaAlunoAvalComboBoxCadeira.Enabled = true;
			notaAlunoAvalComboBoxCadeira.DataSource = null;

			string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();
			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;

			List<string> lsCadeiras = carregaCadeirasAluno(sID_Aluno);
			int iNum = lsCadeiras.Count;

			if (iNum == 0)
			{
				lsCadeiras.Add("Cadeira sem avaliações!");
			}

			notaAlunoAvalComboBoxCadeira.DataSource = lsCadeiras;
			notaAlunoAvalComboBoxCadeira.SelectedItem = 0;
		}

		// Quando muda a cadeira atualizar as informações relativamente às avaliações
		private void notaAlunoAvalComboBoxCadeira_SelectedIndexChanged(object sender, EventArgs e)
		{/*
			if (notaAlunoAvalComboBoxCadeira.SelectedItem == null)
			{
				notaAlunoAvalComboBoxAval.Enabled = false;
			}
			else
			{
				if (notaAlunoAvalComboBoxCurso.SelectedItem == null || notaAlunoAvalComboBoxCadeira.SelectedItem == null || notaAlunoAvalListBoxAlunos.SelectedItem == null)
				{
					notaAlunoAvalComboBoxAval.Enabled = false;
					return;
				}

				string sCurso = notaAlunoAvalComboBoxCurso.SelectedItem.ToString();
				string sCadeira = notaAlunoAvalComboBoxCadeira.SelectedItem.ToString();
				string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();

				string sID_Cadeira = dictID_Cadeira.FirstOrDefault(x => x.Value == sCadeira).Key;
				string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
				if (sID_Cadeira == null || sID_Aluno == null)
					return;

				notaAlunoAvalComboBoxAval.Enabled = true;

				carregaAvaliacoesAluno(sID_Aluno, sID_Cadeira, sCurso);
			}*/

		}

		// Quando carregar no botão Pesquisar carregar os alunos disponíveis com aquele nome
		private void notaAlunoAvalPesquisar_Click(object sender, EventArgs e)
		{
			string sNome = notaAlunoAvalNomeText.Text.ToString();

			carregaAlunos(sNome);
		}

		// Quando carregar no botão Confirmar enviar informação para a base de dados
		private void notaAlunoAvalConfirmar_Click(object sender, EventArgs e)
		{
			/*string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();
			string sAvaliacao = notaAlunoAvalComboBoxAval.SelectedItem.ToString();
			string sNota = notaAlunoAvaliacaoNotaText.Text.ToString();
			string sCurso = notaAlunoAvalComboBoxCurso.SelectedItem.ToString();

			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sID_Avaliacao = dictID_Avaliacao.FirstOrDefault(x => x.Value == sAvaliacao).Key;

			string sResult = theWebSvc.inserirNotaAlunoAvaliacao(sID_Avaliacao, sID_Aluno, sNota, sCurso);

			if (sResult.Equals("OK"))
			{
				MessageBox.Show("Nota introduzida com sucesso!");
			}
			else
			{
				MessageBox.Show("Nota introduzida sem sucesso!");
			}*/
		}

		// Função que permite limpar as informações existentes
		private void notaAlunoAvalLimpar_Click(object sender, EventArgs e)
		{
			notaAlunoAvalNomeText.Text = "";

			notaAlunoAvalListBoxAlunos.DataSource = null;
			notaAlunoAvalListBoxAlunos.Items.Clear();
			notaAlunoAvalListBoxAlunos.SelectedItem = null;

			notaAlunoAvalComboBoxCurso.DataSource = null;
			notaAlunoAvalComboBoxCurso.Items.Clear();

			notaAlunoAvalComboBoxCadeira.DataSource = null;
			notaAlunoAvalComboBoxCadeira.Items.Clear();
			notaAlunoAvalComboBoxCadeira.SelectedItem = null;

			notaAlunoAvalComboBoxAval.DataSource = null;
			notaAlunoAvalComboBoxAval.Items.Clear();
			notaAlunoAvalComboBoxAval.SelectedItem = null;

			notaAlunoAvaliacaoNotaText.Text = "";
		}

		// Verificar se existe alguma nota e preencher
		private void notaAlunoAvalComboBoxAval_SelectedIndexChanged(object sender, EventArgs e)
		{
			/*string sCurso = notaAlunoAvalComboBoxCurso.Text.ToString();
			string sAluno = notaAlunoAvalListBoxAlunos.SelectedItem.ToString();
			string sCadeira = notaAlunoAvalComboBoxCadeira.Text.ToString();

			string sID_Aluno = dictID_Aluno.FirstOrDefault(x => x.Value == sAluno).Key;
			string sID_Cadeira = dictID_Cadeira.FirstOrDefault(x => x.Key == sCadeira).Value;

			string sNota = theWebSvc.avaliacoesDeAlunoEmCadeira(sID_Aluno, sID_Cadeira, sCurso);

			string[] saNotas = sNota.Split(
						new[] { " : " },
						StringSplitOptions.None
			);

			if (saNotas.Length > 1)
			{
				notaAlunoAvaliacaoNotaText.Text = saNotas[1];
				notaAlunoAvaliacaoNotaText.Enabled = false;
			}*/

		}

		// Carregar as avaliações de um aluno numa cadeira
		private List<string> carregaAvaliacoesAluno(string sID_Aluno, string sID_Cadeira, string sCurso)
		{
			// Limpar dicionário
			dictID_Avaliacao = new Dictionary<string, string>();

			// Limpar datasource
			notaAlunoAvalComboBoxAval.DataSource = null;

			// Limpar comboBox
			notaAlunoAvalComboBoxAval.Items.Clear();

			List<string> Avaliacoes = new List<string>();

			string sResposta = theWebSvc.avaliacoesDeAlunoEmCadeira(sID_Aluno, sID_Cadeira, sCurso);

			if (sResposta.Equals("Erro"))
			{
				MessageBox.Show("Não foram encontradas informações sobre a cadeira!");
				return Avaliacoes;
			}

			string[] avaliacoes = sResposta.Split(
				new[] { ">>" },
				StringSplitOptions.None
			);

			if (avaliacoes.Length == 1)
			{
				Avaliacoes.Add("Aluno sem avaliações!");
			}
			else
			{
				for (int j = 0; j < avaliacoes.Length - 1; j++)
				{
					string[] ids = avaliacoes[j].Split(
						new[] { "||" },
						StringSplitOptions.None
					);

					dictID_Avaliacao.Add(ids[0], ids[1]);

					Avaliacoes.Add(ids[1]);
				}
			}

			return Avaliacoes;
		}

	}
}
