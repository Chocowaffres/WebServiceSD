
-------------------------------------------------------------------------------
-- USE DBProject: Changes the database context to the DBProject database.
--
USE Inscricoes
--
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- Criar as tabelas
-- (create the database tables)
-------------------------------------------------------------------------------

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Pessoa]') )
begin
  CREATE TABLE Pessoa (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY, 
      Nome nvarchar(50) NOT NULL, 
      CC int NOT NULL,

      CONSTRAINT U_CC UNIQUE (CC)            -- constraint type: unique        
  ); 
    
end

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Matricula]') )
begin
  CREATE TABLE Matricula (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  Data char (10) NOT NULL,
	  ID_Pessoa int NOT NULL,           
	  ID_Aluno nvarchar(10) NOT NULL, 
	  
	  CONSTRAINT FK_ID_Pessoa FOREIGN KEY (ID_Pessoa) 
	     REFERENCES Pessoa(ID)
	     ON UPDATE CASCADE 
	     ON DELETE CASCADE

  ); 
end

-- ............................................................................

if not exists (select * from dbo.sysobjects 
               where id = object_id(N'[dbo].[Password]') )
begin
  CREATE TABLE Password (
	  ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	  Nome_User nvarchar (20) NOT NULL,
	  --Pass_User nvarchar (64) NOT NULL
	  Hash_User nvarchar (128) NOT NULL,             
	  Salt_User nvarchar (8) NOT NULL        
  ); 
end