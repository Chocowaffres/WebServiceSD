﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Security.Cryptography;
using System.ServiceModel;

/// <summary>
/// Summary description for WebService
/// </summary>
/// 

// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]

[ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.Single)]

public class ServicoWeb : System.Web.Services.WebService
{

	public ServicoWeb()
	{
		//Uncomment the following line if using designed components 
		//InitializeComponent(); 
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Avaliação da permissão de entrada do utilizador

	public const int SALT_SIZE = 8; // size in bytes
	public const int HASH_SIZE = 64; // size in bytes
	public const int ITERATIONS = 10000; // number of pbkdf2 iterations

	private static byte[] CreateHash(string sPass, byte[] iSalt)
	{
		// Generate the hash
		var pbkdf2 = new Rfc2898DeriveBytes(sPass, iSalt);
		pbkdf2.IterationCount = ITERATIONS;
		return pbkdf2.GetBytes(HASH_SIZE);
	}

	[WebMethod]
	public string avaliaPermisaoUser(string sNomeUser, string sPassUser)
	{
		string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
		SqlConnection conn = new SqlConnection(linkString);

		string sSalt = saltOfUser(sNomeUser);

		if (sSalt.Equals("Erro"))
		{
			return "Impossível conetar a base de dados!";
		}

		byte[] baSalt= Encoding.ASCII.GetBytes(sSalt);
		byte[] baPassword = CreateHash(sPassUser, baSalt);
		string sPassword = ByteArrayToString(baPassword);

		SqlCommand comm = new SqlCommand(
			"IF EXISTS (Select P.Hash_User as Password " +
			"From Password P " +
			"where P.Nome_User = @NomeUser) " +
			"Begin " +
				"Select " +
				"case " +
					"when A.Password = @PassUser then 'OK' " +
					"else 'NO_OK' " +
				"end as Permissão " +
			"From (Select P.Hash_User as Password " +
			   "From Password P " +
			   "where P.Nome_User = @NomeUser) A " +
			 "end " +
			"ELSE " +
			"Select 'NO_OK' as Permissão", conn);

		comm.Parameters.AddWithValue("@NomeUser", sNomeUser);
		comm.Parameters.AddWithValue("@PassUser", sPassword);

		SqlDataReader rdr;

		string sResposta = "";

		try
		{
			conn.Open();
			rdr = comm.ExecuteReader();
			while (rdr.Read())
			{
				sResposta = rdr.GetString(0);
			}
			conn.Close();

			return sResposta;

		}
		catch (Exception e)
		{
			return "Impossível conetar a base de dados!: " + e.ToString();
		}

	}

	// Convert de byte array para string (hexadecimal)
	private static string ByteArrayToString(byte[] ba)
	{
		StringBuilder hex = new StringBuilder(ba.Length * 2);
		foreach (byte b in ba)
			hex.AppendFormat("{0:x2}", b);
		return hex.ToString();
	}

	// Obter sal de user, de BD
	private string saltOfUser(string sNomeUser)
	{
		string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
		SqlConnection conn = new SqlConnection(linkString);

		SqlCommand comm = new SqlCommand(
			"Select P.Salt_User as Salt " +
			"From Password P " +
			"where P.Nome_User = @NomeUser ", conn);

		comm.Parameters.AddWithValue("@NomeUser", sNomeUser);

		SqlDataReader rdr;

		string sResposta = "";

		try
		{
			conn.Open();
			rdr = comm.ExecuteReader();
			while (rdr.Read())
			{
				sResposta = rdr.GetString(0);
			}
			conn.Close();

			return sResposta;

		}
		catch (Exception e)
		{
			return "Erro" + e.ToString();
		}

	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Informação da BD local

	private string sIP = "localhost\\sqlexpress";
	private string sDBname = "Inscricoes";
	private string sUser = "aluno";
	private string sPass = "SDtest123";
	private string sIPAlpha = "192.168.1.128";
	private string sIPBeta = "192.168.1.198";
	private string sIPGamma = "192.168.1.138";
	private static int iTimeout = 1000;
	// Alpha -> Samsung
	// Beta -> Asus
	// Gamma -> Acer

	public class WebClientEx : WebClient
	{
		public int Timeout { get; set; }

		protected override WebRequest GetWebRequest(Uri address)
		{
			var request = base.GetWebRequest(address);
			request.Timeout = iTimeout;
			return request;
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura de aluno por número

	[WebMethod]
	public string listAlunoUsandoNumero(string sNumUser)
	{
		bool bLicenciatura = false;
		bool bMestrado = false;
		bool bDoutoramento = false;
		bool bPosDoc = false;

		string sGrauNumero;

		// Avaliar as possiveis combinações de número (a -> Licenciatura, m -> mestrado, d -> doutoramento, pd -> pos-doc)
		bLicenciatura = sNumUser.Contains("a") || sNumUser.Contains("A");
		bMestrado = sNumUser.Contains("m") || sNumUser.Contains("M");
		bDoutoramento = sNumUser.Contains("d") || sNumUser.Contains("D");
		bPosDoc = sNumUser.Contains("pd") || sNumUser.Contains("PD");

		// Avaliar grau
		sGrauNumero = (bLicenciatura ?
			"Licenciatura" : (bMestrado ?
			"Mestrado" : (bDoutoramento ?
			"Doutoramento" : "Pós-Doutoramento")));

		// No caso de ser pos-doc teremos que ignorar os dois primeiros caracteres
		string sNumAtualizado = (bPosDoc ? sNumUser.Substring(2) : sNumUser.Substring(1));
		
		// Procurar informação de curso de aluno em servidor remoto
		string sCurso = "";

		switch (sGrauNumero)
		{
			case "Licenciatura":
				sCurso = listAlunoBetaUsandoNumero(sNumAtualizado, sGrauNumero);
				break;
			case "Mestrado":
				sCurso = listAlunoAlphaUsandoNumero(sNumAtualizado, sGrauNumero);
				break;
			case "Doutoramento":
				sCurso = listAlunoGammaUsandoNumero(sNumAtualizado, sGrauNumero);
				break;
			default:
				sCurso = "";
				break;
		}

		// Procurar informação de pessoa, associada ao aluno, em servidor local
		string sNome = getNomeAlunoUsandoNumero(sNumUser);
		if (sNome.Equals("Erro"))
			return sNumUser + "#" + "" + "#" + sCurso;

		return sNumUser + "#" + sNome + "#" + sCurso;

	}

	[WebMethod]
	public string getNomeAlunoUsandoNumero (string sNumUser)
	{
		// Procurar informação de pessoa, associada ao aluno, em servidor local
		string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
		SqlConnection conn = new SqlConnection(linkString);

		SqlCommand comm = new SqlCommand(
			"Select P.Nome " +
			"From Pessoa P, Matricula M " +
			"where M.ID_Aluno = @Num_User " +
			"and M.ID_Pessoa = P.ID", conn);

		comm.Parameters.AddWithValue("@Num_User", sNumUser);

		SqlDataReader rdr;

		string sNome = "";

		try
		{
			conn.Open();
			rdr = comm.ExecuteReader();
			while (rdr.Read())
			{
				sNome = rdr.GetString(0);
			}
			conn.Close();

		}
		catch (Exception e)
		{
			return "Erro" + e.ToString();
		}

		return sNome;
	}

	public string listAlunoAlphaUsandoNumero(string sNumUser, string sGrau)
	{
		string sCurso = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCurso = webService.getCursoAlunoUsandoNumero(sNumUser, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return listAlunoGammaUsandoNumero(sNumUser, sGrau);
		}

		return processJsonCursoAluno(sCurso);
	}

	public string listAlunoBetaUsandoNumero(string sNumUser, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/getCursoAlunoUsandoNumero.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sCurso = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Grau", sGrau);
				reqparm.Add("Numero_Aluno", sNumUser);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sCurso = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return listAlunoAlphaUsandoNumero(sNumUser, sGrau);
		}

		return processJsonCursoAluno(sCurso);
	}

	public string listAlunoGammaUsandoNumero(string sNumUser, string sGrau)
	{
		string sCurso = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCurso = webService.getCursoAlunoUsandoNumero(sNumUser, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return listAlunoBetaUsandoNumero(sNumUser, sGrau);
		}

		return processJsonCursoAluno(sCurso);
	}

	// Procura de aluno por nome
	[WebMethod]
	public string listAlunoUsandoNome(string sNomeUser)
	{
		// Procurar informação de pessoa, associada ao aluno, em servidor local
		string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
		SqlConnection conn = new SqlConnection(linkString);

		SqlCommand comm = new SqlCommand(
			"Select M.ID_Aluno " +
			"From Pessoa P, Matricula M " +
			"where M.ID_Pessoa = P.ID " +
			"and P.Nome LIKE @Nome_User", conn);

		comm.Parameters.AddWithValue("@Nome_User", "%" + sNomeUser + "%");

		SqlDataReader rdr;

		List<string> listIDAlunos = new List<string>();
		// Retorno da lista de todos os ID's de alunos que contenham o nome introduzido
		try
		{
			conn.Open();
			rdr = comm.ExecuteReader();
			while (rdr.Read())
			{
				listIDAlunos.Add(rdr.GetString(0));
			}
			conn.Close();

		}
		catch (Exception e)
		{
			return "Erro: " + e.ToString();
		}

		string sResposta = "";
		// Reaproveitar funções acima definidas
		foreach (string sNumUser in listIDAlunos)
		{
			sResposta += listAlunoUsandoNumero(sNumUser) + ">>";
		}

		return sResposta;
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura cursos

	[WebMethod]
	public string cursosDeGrau(string sGrau)
	{
		string sCursos = "";
		switch (sGrau)
		{
			case "Licenciatura":
				sCursos = cursosDeBeta(sGrau);
				break;
			case "Mestrado":
				sCursos = cursosDeAlpha(sGrau);
				break;
			case "Doutoramento":
				sCursos = cursosDeGamma(sGrau);
				break;
			default:
				sCursos = "";
				break;
		}

		return sCursos;

	}

	public string cursosDeAlpha(string sGrau)
	{
		string sCurso = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCurso = webService.getCursos(sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return cursosDeGamma(sGrau);
		}

		return processJsonCurso(sCurso);
	}

	public string cursosDeBeta(string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/getCursos.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sCurso = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sCurso = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return cursosDeAlpha(sGrau);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonCurso(sCurso);
	}

	public string cursosDeGamma(string sGrau)
	{
		string sCurso = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCurso = webService.getCursos(sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return cursosDeBeta(sGrau);
		}


		return processJsonCurso(sCurso);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura cadeiras de um curso

	[WebMethod]
	public string cadeirasDeCurso(string sCurso)
	{
		// Avaliar grau
		string sCadeiras = (sCurso.Contains("Licenciatura") ?
			cadeirasDeCursoDeBeta(sCurso) : (sCurso.Contains("Mestrado") ?
			cadeirasDeCursoDeAlpha(sCurso) : (sCurso.Contains("Doutoramento") ?
			cadeirasDeCursoDeGamma(sCurso) : "Pós-Doutoramento")));

		return sCadeiras;
	}

	public string cadeirasDeCursoDeAlpha(string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sCadeiras = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCadeiras = webService.getCadeirasDeCurso(sCurso, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return cadeirasDeCursoDeGamma(sCurso);
		}

		return processJsonCadeira(sCadeiras);
	}

	public string cadeirasDeCursoDeBeta(string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sUrl = "https://"+sIPBeta+"/sd/getCadeirasCurso.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sCadeiras  = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Curso", sCurso);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sCadeiras = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return cadeirasDeCursoDeAlpha(sCurso);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonCadeira(sCadeiras);
	}

	public string cadeirasDeCursoDeGamma(string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sCadeiras = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCadeiras = webService.getCadeirasDeCurso(sCurso, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return cadeirasDeCursoDeBeta(sCurso);
		}

		return processJsonCadeira(sCadeiras);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura avaliacoes de uma cadeira

	[WebMethod]
	public string avaliacoesDeCadeira(string sCadeira, string sCurso)
	{
		// Avaliar grau
		string sAvaliacoes = (sCurso.Contains("Licenciatura") ?
			avaliacoesDeCadeiraDeBeta(sCadeira, sCurso) : (sCurso.Contains("Mestrado") ?
			avaliacoesDeCadeiraDeAlpha(sCadeira, sCurso) : (sCurso.Contains("Doutoramento") ?
			avaliacoesDeCadeiraDeGamma(sCadeira, sCurso) : "Pós-Doutoramento")));

		return sAvaliacoes;
	}

	public string avaliacoesDeCadeiraDeAlpha(string sCadeira, string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" :(sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sAvaliacoes = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sAvaliacoes = webService.getAvaliacoesDeCadeira(sCadeira, sCurso, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString() ;
			return avaliacoesDeCadeiraDeGamma(sCadeira, sCurso);
		}


		return processJsonAvaliacao(sAvaliacoes);
	}

	public string avaliacoesDeCadeiraDeBeta(string sCadeira, string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sUrl = "https://"+sIPBeta+"/sd/getAvaliacoesCadeira.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sAvaliacoes = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Curso", sCurso);
				reqparm.Add("Cadeira", sCadeira);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sAvaliacoes = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return avaliacoesDeCadeiraDeAlpha(sCadeira, sCurso);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonAvaliacao(sAvaliacoes);
	}

	public string avaliacoesDeCadeiraDeGamma(string sCadeira, string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sAvaliacoes = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sAvaliacoes = webService.getAvaliacoesDeCadeira(sCadeira, sCurso, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return avaliacoesDeCadeiraDeBeta(sCadeira, sCurso);
		}


		return processJsonAvaliacao(sAvaliacoes);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura classificacoes de alunos de um momento de avaliação

	[WebMethod]
	public string notasDeAvaliacaoDeCadeira(string sID_Avaliacao, string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sAvaliacoes = "";
		switch (sGrau)
		{
			case "Licenciatura":
				sAvaliacoes = notasDeAvaliacaoDeCadeiraDeBeta(sID_Avaliacao, sGrau);
				break;
			case "Mestrado":
				sAvaliacoes = notasDeAvaliacaoDeCadeiraDeAlpha(sID_Avaliacao, sGrau);
				break;
			case "Doutoramento":
				sAvaliacoes = notasDeAvaliacaoDeCadeiraDeGamma(sID_Avaliacao, sGrau);
				break;
			default:
				sAvaliacoes = "";
				break;
		}
		
		return sAvaliacoes;
	}

	public string notasDeAvaliacaoDeCadeiraDeAlpha(string sID_Avaliacao, string sGrau)
	{
		string sNotas = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sNotas = webService.getNotasDeAvaliacaoDeCadeira(sID_Avaliacao, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return notasDeAvaliacaoDeCadeiraDeGamma(sID_Avaliacao, sGrau);
		}


		return processJsonNotasDeAvaliacaoDeCadeira(sNotas);
	}

	public string notasDeAvaliacaoDeCadeiraDeBeta(string sID_Avaliacao, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/getNotasDeAvaliacaoDeCadeira.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sNotas = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID", sID_Avaliacao);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sNotas = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return notasDeAvaliacaoDeCadeiraDeAlpha(sID_Avaliacao, sGrau);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonNotasDeAvaliacaoDeCadeira(sNotas);
	}

	public string notasDeAvaliacaoDeCadeiraDeGamma(string sID_Avaliacao, string sGrau)
	{
		string sNotas = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sNotas = webService.getNotasDeAvaliacaoDeCadeira(sID_Avaliacao, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return notasDeAvaliacaoDeCadeiraDeBeta(sID_Avaliacao, sGrau);
		}


		return processJsonNotasDeAvaliacaoDeCadeira(sNotas);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura cadeiras e respetivas classificações de um aluno

	[WebMethod]
	public string cadeirasDeAluno(string sID_Aluno)
	{
		bool bLicenciatura = false;
		bool bMestrado = false;
		bool bDoutoramento = false;
		bool bPosDoc = false;

		// Avaliar as possiveis combinações de número (a -> Licenciatura, m -> mestrado, d -> doutoramento, pd -> pos-doc)
		bLicenciatura = sID_Aluno.Contains("a") || sID_Aluno.Contains("A");
		bMestrado = sID_Aluno.Contains("m") || sID_Aluno.Contains("M");
		bDoutoramento = sID_Aluno.Contains("d") || sID_Aluno.Contains("D");
		bPosDoc = sID_Aluno.Contains("pd") || sID_Aluno.Contains("PD");

		// Avaliar grau
		string sGrauNumero = (bLicenciatura ?
			"Licenciatura" : (bMestrado ?
			"Mestrado" : (bDoutoramento ?
			"Doutoramento" : "Pós-Doutoramento")));

		// No caso de ser pos-doc teremos que ignorar os dois primeiros caracteres
		string sNumAtualizado = (bPosDoc ? sID_Aluno.Substring(2) : sID_Aluno.Substring(1));

		string sAvaliacoes = (bLicenciatura ?
			cadeirasDeAlunoDeBeta(sNumAtualizado, sGrauNumero) : (bMestrado ?
			cadeirasDeAlunoDeAlpha(sNumAtualizado, sGrauNumero) : (bDoutoramento ?
			cadeirasDeAlunoDeGamma(sNumAtualizado, sGrauNumero) : "Pós-Doutoramento")));

		return sAvaliacoes;
	}

	public string cadeirasDeAlunoDeAlpha(string sID_Aluno, string sGrau)
	{
		string sClassificacoes = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sClassificacoes = webService.getCadeirasAluno(sID_Aluno, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return cadeirasDeAlunoDeGamma(sID_Aluno, sGrau);
		}

		return processJsonClassificacaoDeCadeira(sClassificacoes);
	}

	public string cadeirasDeAlunoDeBeta(string sID_Aluno, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/getCadeirasAluno.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sClassificacoes = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Numero_Aluno", sID_Aluno);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sClassificacoes = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return cadeirasDeAlunoDeAlpha(sID_Aluno, sGrau);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonClassificacaoDeCadeira(sClassificacoes);
	}

	public string cadeirasDeAlunoDeGamma(string sID_Aluno, string sGrau)
	{
		string sClassificacoes = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sClassificacoes = webService.getCadeirasAluno(sID_Aluno, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return cadeirasDeAlunoDeBeta(sID_Aluno, sGrau);
		}

		return processJsonClassificacaoDeCadeira(sClassificacoes);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura avaliações de uma cadeira de um aluno

	[WebMethod]
	public string avaliacoesDeAlunoEmCadeira(string sID_Aluno, string sID_Cadeira, string sCurso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sAvaliacoes = "";
		switch (sGrau)
		{
			case "Licenciatura":
				sAvaliacoes = avaliacoesDeAlunoEmCadeiraDeBeta(sID_Aluno, sID_Cadeira, sGrau);
				break;
			case "Mestrado":
				sAvaliacoes = avaliacoesDeAlunoEmCadeiraDeAlpha(sID_Aluno, sID_Cadeira, sGrau);
				break;
			case "Doutoramento":
				sAvaliacoes = avaliacoesDeAlunoEmCadeiraDeGamma(sID_Aluno, sID_Cadeira, sGrau);
				break;
			default:
				sAvaliacoes = "";
				break;
		}

		return sAvaliacoes;
	}

	public string avaliacoesDeAlunoEmCadeiraDeAlpha(string sID_Aluno, string sID_Cadeira, string sGrau)
	{
		string sClassificacoes = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sClassificacoes = webService.getAvaliacoesDeAlunoEmCadeira(sID_Aluno, sID_Cadeira, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return avaliacoesDeAlunoEmCadeiraDeGamma(sID_Aluno, sID_Cadeira, sGrau);
		}

		return processJsonAvaliacaoDeAlunoEmCadeira(sClassificacoes);
	}

	public string avaliacoesDeAlunoEmCadeiraDeBeta(string sID_Aluno, string sID_Cadeira, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/getAvaliacoesDeAlunoEmCadeira.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sClassificacoes = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Numero_Aluno", sID_Aluno);
				reqparm.Add("ID_Cadeira", sID_Cadeira);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sClassificacoes = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return avaliacoesDeAlunoEmCadeiraDeAlpha(sID_Aluno, sID_Cadeira, sGrau);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonAvaliacaoDeAlunoEmCadeira(sClassificacoes);
	}

	public string avaliacoesDeAlunoEmCadeiraDeGamma(string sID_Aluno, string sID_Cadeira, string sGrau)
	{
		string sClassificacoes = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sClassificacoes = webService.getAvaliacoesDeAlunoEmCadeira(sID_Aluno, sID_Cadeira, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return avaliacoesDeAlunoEmCadeiraDeBeta(sID_Aluno, sID_Cadeira, sGrau);
		}

		return processJsonAvaliacaoDeAlunoEmCadeira(sClassificacoes);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura do ID de uma pessoa usando o seu nome

	[WebMethod]
	public string getIDPessoaUsandoNome(string sNome)
	{
		// Procurar informação de pessoa, associada ao aluno, em servidor local
		string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
		SqlConnection conn = new SqlConnection(linkString);

		SqlCommand comm = new SqlCommand(
			"Select P.ID, P.Nome " +
			"From Pessoa P " +
			"where P.Nome LIKE @Nome ", conn);

		comm.Parameters.AddWithValue("@Nome", "%" + sNome + "%");

		SqlDataReader rdr;

		string sID = "";
		try
		{
			conn.Open();
			rdr = comm.ExecuteReader();
			while (rdr.Read())
			{
				sID += rdr.GetInt32(0) + "||" + rdr.GetString(1) + ">>" ;
			}
			conn.Close();

		}
		catch (Exception e)
		{
			return "Erro no processamento da pessoa" + e.ToString();
		}

		return sID;
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Inserir pessoa na Base de Dados

	[WebMethod]
	public string inserirPessoa(string sNome, string sCC)
	{
		string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
		SqlConnection conn = new SqlConnection(linkString);

		SqlCommand comm = new SqlCommand(
			"INSERT INTO Pessoa(Nome, CC)" +
			"Values(@Nome_Pessoa, @CC_Pessoa)", conn);

		comm.Parameters.AddWithValue("@Nome_Pessoa", sNome);
		comm.Parameters.AddWithValue("@CC_Pessoa", sCC);
		int result = 0;
		try
		{
			conn.Open();
			result = comm.ExecuteNonQuery();
			conn.Close();
		}
		catch (Exception e)
		{
			return "Erro na execução da BD" + e.ToString();
		}

		// Se correu mal
		if (result < 0)
			return "NO OK";

		return "OK";
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// "Ping" um servidor para verificar a conexão

	private string pingServidor(string sGrau)
	{
		switch (sGrau)
		{
			case "Licenciatura":
				try
				{
					using (var Alpha = new TcpClient(sIPAlpha, 443))
					using (var Beta = new TcpClient(sIPBeta, 443))
						return "OK";
				}
				catch (SocketException e)
				{
					return "Error";
				}
			case "Mestrado":
				try
				{
					using (var Alpha = new TcpClient(sIPAlpha, 443))
					using (var Gamma = new TcpClient(sIPGamma, 443))
						return "OK";
				}
				catch (SocketException e)
				{
					return "Error";
				}
			case "Doutoramento":
				try
				{
					using (var Beta = new TcpClient(sIPBeta, 443))
					using (var Gamma = new TcpClient(sIPGamma, 443))
						return "OK";
				}
				catch (SocketException e)
				{
					return "Error";
				}
			default:
				return "Error";
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Introduzir matrícula na Base de Dados

	[WebMethod]
	public string inserirMatricula(string sID_Pessoa, string sCurso, string sID_Curso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sID_Aluno = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sID_Aluno = inserirMatriculaDeBeta(sID_Curso, sGrau);
					sID_Aluno = inserirMatriculaDeAlpha(sID_Curso, sGrau);
				}
				else
				{
					sID_Aluno = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sID_Aluno = inserirMatriculaDeAlpha(sID_Curso, sGrau);
					sID_Aluno = inserirMatriculaDeGamma(sID_Curso, sGrau);
				}
				else
				{
					sID_Aluno = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sID_Aluno = inserirMatriculaDeBeta(sID_Curso, sGrau);
					sID_Aluno = inserirMatriculaDeGamma(sID_Curso, sGrau);
				}
				else
				{
					sID_Aluno = "NO_OK";
				}
				break;
			default:
				sID_Aluno = "";
				break;
		}

		if (sID_Aluno.Contains("NO_OK"))
		{
			return sID_Aluno;
		}
		else
		{
			// Obter a data em que foi feita esta inserção
			DateTime dtLocalDate = DateTime.Now;
			DateTime dtDateOnly = dtLocalDate.Date;
			string sData = dtDateOnly.ToString("d");

			string sNumber = sGrau.Contains("Licenciatura") ?
				"a" + sID_Aluno : sGrau.Contains("Mestrado") ?
				"m" + sID_Aluno : sGrau.Contains("Doutoramento") ?
				"d" + sID_Aluno : "pd" + sID_Aluno;

			string linkString = string.Format("Server=" + sIP + ";Database=" + sDBname + ";User ID=" + sUser + ";Password=" + sPass);
			SqlConnection conn = new SqlConnection(linkString);

			SqlCommand comm = new SqlCommand(
				"INSERT INTO Matricula(Data, ID_Pessoa, ID_Aluno)" +
				"VALUES(@Data, @ID_Pessoa, @ID_Aluno); ", conn);

			comm.Parameters.AddWithValue("@Data", sData);
			comm.Parameters.AddWithValue("@ID_Pessoa", sID_Pessoa);
			comm.Parameters.AddWithValue("@ID_Aluno", sNumber);
			int result = 0;
			try
			{
				conn.Open();
				result = comm.ExecuteNonQuery();
				conn.Close();
			}
			catch (Exception e)
			{
				return "Erro na execução da BD" + e.ToString();
			}

			// Se correu mal
			if (result < 0)
				return "NO OK";

			return "OK";
		}
	}

	public string inserirMatriculaDeAlpha(string sID_Curso, string sGrau)
	{
			string sResultado = "";
			try
			{
				ServicePointManager
				.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

				MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
				// Timeout para evitar um tempo de espera longo
				webService.Timeout = iTimeout;
				sResultado = webService.insertAlunoIntoCurso(sID_Curso, sGrau);
			}
			catch (Exception e)
			{
				return "NO_OK";
			}

			return processJsonResultadoInsercao(sResultado);
	}

	public string inserirMatriculaDeBeta(string sID_Curso, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/insertAlunoIntoCurso.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Curso", sID_Curso);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirMatriculaDeGamma(string sID_Curso, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertAlunoIntoCurso(sID_Curso, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Introduzir inscrição de aluno numa disciplina na Base de Dados

	[WebMethod]
	public string inserirAlunoDisciplina(string sID_Aluno, string sID_Cadeira)
	{
		bool bLicenciatura = false;
		bool bMestrado = false;
		bool bDoutoramento = false;
		bool bPosDoc = false;

		// Avaliar as possiveis combinações de número (a -> Licenciatura, m -> mestrado, d -> doutoramento, pd -> pos-doc)
		bLicenciatura = sID_Aluno.Contains("a") || sID_Aluno.Contains("A");
		bMestrado = sID_Aluno.Contains("m") || sID_Aluno.Contains("M");
		bDoutoramento = sID_Aluno.Contains("d") || sID_Aluno.Contains("D");
		bPosDoc = sID_Aluno.Contains("pd") || sID_Aluno.Contains("PD");

		// Avaliar grau
		string sGrau = (bLicenciatura ?
			"Licenciatura" : (bMestrado ?
			"Mestrado" : (bDoutoramento ?
			"Doutoramento" : "Pós-Doutoramento")));

		// No caso de ser pos-doc teremos que ignorar os dois primeiros caracteres
		string sNumAtualizado = (bPosDoc ? sID_Aluno.Substring(2) : sID_Aluno.Substring(1));

		// Obter o ano em que foi feita esta inserção
		DateTime dtLocalDate = DateTime.Now;
		string sAno = dtLocalDate.Year.ToString();

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirAlunoDisciplinaDeBeta(sNumAtualizado, sID_Cadeira, sAno, "3", sGrau);
					sResultado = inserirAlunoDisciplinaDeAlpha(sNumAtualizado, sID_Cadeira, sAno, "3", sGrau);			
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirAlunoDisciplinaDeAlpha(sNumAtualizado, sID_Cadeira, sAno, "3", sGrau);
					sResultado = inserirAlunoDisciplinaDeGamma(sNumAtualizado, sID_Cadeira, sAno, "3", sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirAlunoDisciplinaDeBeta(sNumAtualizado, sID_Cadeira, sAno, "3", sGrau);
					sResultado = inserirAlunoDisciplinaDeGamma(sNumAtualizado, sID_Cadeira, sAno, "3", sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string inserirAlunoDisciplinaDeAlpha(string sID_Aluno, string sID_Cadeira, string sAno, string sEstado, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertAlunoIntoDisciplina(sID_Aluno, sID_Cadeira, sAno, sEstado, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirAlunoDisciplinaDeBeta(string sID_Aluno, string sID_Cadeira, string sAno, string sEstado, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/insertAlunoIntoDisciplina.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("NumAluno", sID_Aluno);
				reqparm.Add("NumDisc", sID_Cadeira);
				reqparm.Add("Ano", sAno);
				reqparm.Add("Estado", sEstado);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirAlunoDisciplinaDeGamma(string sID_Aluno, string sID_Cadeira, string sAno, string sEstado, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertAlunoIntoDisciplina(sID_Aluno, sID_Cadeira, sAno, sEstado, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Introduzir novo curso na Base de Dados

	[WebMethod]
	public string inserirCurso(string sNome, string sCodigo, string sNumbECTS, string sDescricao)
	{
		// Avaliar grau
		string sGrau = (sDescricao.Contains("Licenciatura") ?
			"Licenciatura" : (sDescricao.Contains("Mestrado") ?
			"Mestrado" : (sDescricao.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirCursoDeBeta(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
					sResultado = inserirCursoDeAlpha(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirCursoDeAlpha(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
					sResultado = inserirCursoDeGamma(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirCursoDeBeta(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
					sResultado = inserirCursoDeGamma(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string inserirCursoDeAlpha(string sNome, string sCodigo, string sNumbECTS, string sDescricao, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertNovoCurso(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirCursoDeBeta(string sNome, string sCodigo, string sNumbECTS, string sDescricao, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/insertNovoCurso.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("NomeCurso", sNome);
				reqparm.Add("Codigo", sCodigo);
				reqparm.Add("NumbECTS", sNumbECTS);
				reqparm.Add("Descricao", sDescricao);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirCursoDeGamma(string sNome, string sCodigo, string sNumbECTS, string sDescricao, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertNovoCurso(sNome, sCodigo, sNumbECTS, sDescricao, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Introduzir disciplina num curso na Base de Dados

	[WebMethod]
	public string inserirDisciplinaCurso(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sCurso)
	{
		// Avaliar grau
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirDisciplinaCursoDeBeta(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
					sResultado = inserirDisciplinaCursoDeAlpha(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirDisciplinaCursoDeAlpha(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
					sResultado = inserirDisciplinaCursoDeGamma(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirDisciplinaCursoDeBeta(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
					sResultado = inserirDisciplinaCursoDeGamma(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string inserirDisciplinaCursoDeAlpha(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertDisciplinaIntoCurso(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirDisciplinaCursoDeBeta(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/insertDisciplinaIntoCurso.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("NomeDisc", sNome);
				reqparm.Add("Codigo", sCodigo);
				reqparm.Add("Criterios", sCriterios);
				reqparm.Add("Descricao", sDescricao);
				reqparm.Add("NumbECTS", sNumbECTS);
				reqparm.Add("NumCurso", sNumCurso);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirDisciplinaCursoDeGamma(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertDisciplinaIntoCurso(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}


	// ----------------------------------------------------------------------------------------------------------------------------------
	// Introduzir avaliação numa disciplina na Base de Dados

	[WebMethod]
	public string inserirAvaliacaoDisciplina(string sFator_Ponderacao, string sData, string sID_Tipo_Avaliacao, string sID_Disciplina, string sCurso)
	{
		// Avaliar grau
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirAvaliacaoDisciplinaDeBeta(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
					sResultado = inserirAvaliacaoDisciplinaDeAlpha(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirAvaliacaoDisciplinaDeAlpha(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
					sResultado = inserirAvaliacaoDisciplinaDeGamma(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirAvaliacaoDisciplinaDeBeta(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
					sResultado = inserirAvaliacaoDisciplinaDeGamma(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string inserirAvaliacaoDisciplinaDeAlpha(string sFator_Ponderacao, string sData, string sID_Tipo_Avaliacao, string sID_Disciplina, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertAvaliacaoIntoDisciplina(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirAvaliacaoDisciplinaDeBeta(string sFator_Ponderacao, string sData, string sID_Tipo_Avaliacao, string sID_Disciplina, string sGrau)
	{
		string sUrl = "https://"+ sIPBeta + "/sd/insertAvaliacaoIntoDisciplina.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Fator_Ponderacao", sFator_Ponderacao);
				reqparm.Add("Data", sData);
				reqparm.Add("ID_Tipo_Avaliacao", sID_Tipo_Avaliacao);
				reqparm.Add("ID_Disciplina", sID_Disciplina);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirAvaliacaoDisciplinaDeGamma(string sFator_Ponderacao, string sData, string sID_Tipo_Avaliacao, string sID_Disciplina, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertAvaliacaoIntoDisciplina(sFator_Ponderacao, sData, sID_Tipo_Avaliacao, sID_Disciplina, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Obter os tipos de avaliação consoante o grau

	[WebMethod]
	public string getTipoAvaliacao()
	{
		return getTipoAvaliacaoDeBeta();
	}

	public string getTipoAvaliacaoDeAlpha()
	{
		string sTipoAvaliacao = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sTipoAvaliacao = webService.getTipoAvaliacao();
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonTipoAvaliacao(sTipoAvaliacao);
	}

	public string getTipoAvaliacaoDeBeta()
	{
		string sUrl = "https://" + sIPBeta + "/sd/getTipoAvaliacao.php";

		string sTipoAvaliacao = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				HttpWebRequest request = (HttpWebRequest)WebRequest.Create(sUrl);
				request.Method = "GET";
				request.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

				HttpWebResponse response = (HttpWebResponse)request.GetResponse();
				sTipoAvaliacao = new StreamReader(response.GetResponseStream()).ReadToEnd();
			}

		}
		catch (Exception e)
		{
			return getTipoAvaliacaoDeAlpha();
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonTipoAvaliacao(sTipoAvaliacao);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Introduzir avaliação numa disciplina na Base de Dados

	[WebMethod]
	public string inserirNotaAlunoAvaliacao(string sID_Avaliacao, string sID_Aluno, string sNota, string sCurso)
	{
		// Avaliar grau
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				sID_Aluno = sID_Aluno.Substring(1);
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirNotaAlunoAvaliacaoDeBeta(sID_Avaliacao, sID_Aluno, sNota, sGrau);
					sResultado = inserirNotaAlunoAvaliacaoDeAlpha(sID_Avaliacao, sID_Aluno, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				sID_Aluno = sID_Aluno.Substring(1);
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirNotaAlunoAvaliacaoDeAlpha(sID_Avaliacao, sID_Aluno, sNota, sGrau);
					sResultado = inserirNotaAlunoAvaliacaoDeGamma(sID_Avaliacao, sID_Aluno, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				sID_Aluno = sID_Aluno.Substring(1);
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = inserirNotaAlunoAvaliacaoDeBeta(sID_Avaliacao, sID_Aluno, sNota, sGrau);
					sResultado = inserirNotaAlunoAvaliacaoDeGamma(sID_Avaliacao, sID_Aluno, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string inserirNotaAlunoAvaliacaoDeAlpha(string sID_Avaliacao, string sID_Aluno, string sNota, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertNotaDeAlunoAvaliacao(sID_Avaliacao, sID_Aluno, sNota, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirNotaAlunoAvaliacaoDeBeta(string sID_Avaliacao, string sID_Aluno, string sNota, string sGrau)
	{
		string sUrl = "https://"+sIPBeta+"/sd/insertNotaDeAlunoAvaliacao.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Avaliacao", sID_Avaliacao);
				reqparm.Add("ID_Aluno", sID_Aluno);
				reqparm.Add("Nota", sNota);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string inserirNotaAlunoAvaliacaoDeGamma(string sID_Avaliacao, string sID_Aluno, string sNota, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.insertNotaDeAlunoAvaliacao(sID_Avaliacao, sID_Aluno, sNota, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Atualizar o curso de um aluno na Base de Dados

	/*[WebMethod]
	public string updateMatricula(string sID_Aluno, string sCurso, string sID_Curso)
	{
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateMatriculaDeBeta(sID_Aluno, sID_Curso, sGrau);
					sResultado = updateMatriculaDeAlpha(sID_Aluno, sID_Curso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateMatriculaDeAlpha(sID_Aluno, sID_Curso, sGrau);
					sResultado = updateMatriculaDeGamma(sID_Aluno, sID_Curso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateMatriculaDeGamma(sID_Aluno, sID_Curso, sGrau);
					sResultado = updateMatriculaDeBeta(sID_Aluno, sID_Curso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string updateMatriculaDeAlpha(string sID_Aluno, string sID_Curso, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateAlunoCurso(sID_Aluno, sID_Curso, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string updateMatriculaDeBeta(string sID_Aluno, string sID_Curso, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/updateAlunoCurso.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Aluno", sID_Aluno);
				reqparm.Add("ID_Curso", sID_Curso);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string updateMatriculaDeGamma(string sID_Aluno, string sID_Curso, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateAlunoCurso(sID_Aluno, sID_Curso, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}*/

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Atualizar uma inscrição de um aluno numa disciplina na Base de Dados

	[WebMethod]
	public string updateAlunoDisciplina(string sID_Inscricao, string sNota, string sID_Aluno)
	{
		bool bLicenciatura = false;
		bool bMestrado = false;
		bool bDoutoramento = false;
		bool bPosDoc = false;

		// Avaliar as possiveis combinações de número (a -> Licenciatura, m -> mestrado, d -> doutoramento, pd -> pos-doc)
		bLicenciatura = sID_Aluno.Contains("a") || sID_Aluno.Contains("A");
		bMestrado = sID_Aluno.Contains("m") || sID_Aluno.Contains("M");
		bDoutoramento = sID_Aluno.Contains("d") || sID_Aluno.Contains("D");
		bPosDoc = sID_Aluno.Contains("pd") || sID_Aluno.Contains("PD");
		
		// Avaliar grau
		string sGrau = (bLicenciatura ?
			"Licenciatura" : (bMestrado ?
			"Mestrado" : (bDoutoramento ?
			"Doutoramento" : "Pós-Doutoramento")));

		// No caso de ser pos-doc teremos que ignorar os dois primeiros caracteres
		string sNumAtualizado = (bPosDoc ? sID_Aluno.Substring(2) : sID_Aluno.Substring(1));

		// Obter o ano em que foi feita esta inserção
		DateTime dtLocalDate = DateTime.Now;
		string sAno = dtLocalDate.Year.ToString();

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateAlunoDisciplinaDeBeta(sID_Inscricao, sNota, sGrau);
					sResultado = updateAlunoDisciplinaDeAlpha(sID_Inscricao, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateAlunoDisciplinaDeAlpha(sID_Inscricao, sNota, sGrau);
					sResultado = updateAlunoDisciplinaDeGamma(sID_Inscricao, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateAlunoDisciplinaDeBeta(sID_Inscricao, sNota, sGrau);
					sResultado = updateAlunoDisciplinaDeGamma(sID_Inscricao, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string updateAlunoDisciplinaDeAlpha(string sID_Inscricao, string sNota, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateInscricaoAlunoDisciplina(sID_Inscricao, sNota, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string updateAlunoDisciplinaDeBeta(string sID_Inscricao, string sNota, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/updateInscricaoAlunoDisciplina.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Inscricao", sID_Inscricao);
				reqparm.Add("Nota", sNota);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string updateAlunoDisciplinaDeGamma(string sID_Inscricao, string sNota, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateInscricaoAlunoDisciplina(sID_Inscricao, sNota, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Atualizar informação de curso na Base de Dados

	[WebMethod]
	public string updateCurso(string sNome, string sCodigo, string sNumbECTS, string sDescricao, string sID_Curso)
	{
		// Avaliar grau
		string sGrau = (sDescricao.Contains("Licenciatura") ?
			"Licenciatura" : (sDescricao.Contains("Mestrado") ?
			"Mestrado" : (sDescricao.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateCursoDeBeta(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
					sResultado = updateCursoDeAlpha(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateCursoDeAlpha(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
					sResultado = updateCursoDeGamma(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateCursoDeGamma(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
					sResultado = updateCursoDeBeta(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string updateCursoDeAlpha(string sNome, string sCodigo, string sNumbECTS, string sDescricao, string sID_Curso, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateCurso(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string updateCursoDeBeta(string sNome, string sCodigo, string sNumbECTS, string sDescricao, string sID_Curso, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/updateCurso.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("NomeCurso", sNome);
				reqparm.Add("CodigoCurso", sCodigo);
				reqparm.Add("ECTSCurso", sNumbECTS);
				reqparm.Add("DescCurso", sDescricao);
				reqparm.Add("ID_Curso", sID_Curso);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string updateCursoDeGamma(string sNome, string sCodigo, string sNumbECTS, string sDescricao, string sID_Curso, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateCurso(sNome, sCodigo, sNumbECTS, sDescricao, sID_Curso, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura as informações de um curso
	
	[WebMethod]
	public string cursosInformacao(string sID_Curso, string sGrau)
	{
		string sCursos = "";
		switch (sGrau)
		{
			case "Licenciatura":
				sCursos = cursosInformacaoDeBeta(sID_Curso, sGrau);
				break;
			case "Mestrado":
				sCursos = cursosInformacaoDeAlpha(sID_Curso, sGrau);
				break;
			case "Doutoramento":
				sCursos = cursosInformacaoDeGamma(sID_Curso, sGrau);
				break;
			default:
				sCursos = "";
				break;
		}

		return sCursos;

	}
	
	public string cursosInformacaoDeAlpha(string sID_Curso, string sGrau)
	{
		string sCurso = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCurso = webService.getCursosInformacao(sID_Curso, sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return cursosInformacaoDeGamma(sID_Curso, sGrau);
		}


		return processJsonCursoInformacao(sCurso);
	}

	public string cursosInformacaoDeBeta(string sID_Curso, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/getCursosInformacao.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sCurso = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("Grau", sGrau);
				reqparm.Add("ID_Curso", sID_Curso);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sCurso = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return cursosInformacaoDeAlpha(sID_Curso, sGrau);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonCursoInformacao(sCurso);
	}

	public string cursosInformacaoDeGamma(string sID_Curso, string sGrau)
	{
		string sCurso = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			//sCurso = webService.getCursosInformacao(sGrau);
		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return cursosInformacaoDeGamma(sID_Curso, sGrau);
		}


		return processJsonCursoInformacao(sCurso);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Atualizar disciplina de um curso na Base de Dados

	[WebMethod]
	public string updateDisciplinaCurso(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sID_Disc, string sCurso)
	{
		// Avaliar grau
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateDisciplinaCursoDeBeta(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
					sResultado = updateDisciplinaCursoDeAlpha(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateDisciplinaCursoDeAlpha(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
					sResultado = updateDisciplinaCursoDeGamma(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateDisciplinaCursoDeGamma(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
					sResultado = updateDisciplinaCursoDeBeta(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string updateDisciplinaCursoDeAlpha(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sID_Disc, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateDisciplinaCurso(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string updateDisciplinaCursoDeBeta(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sID_Disc, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/updateDisciplinaCurso.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("NomeDisc", sNome);
				reqparm.Add("CodigoDisc", sCodigo);
				reqparm.Add("CritDisc", sCriterios);
				reqparm.Add("DescDisc", sDescricao);
				reqparm.Add("ECTSDisc", sNumbECTS);
				reqparm.Add("ID_Curso", sNumCurso);
				reqparm.Add("ID_Disc", sID_Disc);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string updateDisciplinaCursoDeGamma(string sNome, string sCodigo, string sCriterios, string sDescricao, string sNumbECTS, string sNumCurso, string sID_Disc, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateDisciplinaCurso(sNome, sCodigo, sCriterios, sDescricao, sNumbECTS, sNumCurso, sID_Disc, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura as informações de cadeiras
	
	[WebMethod]
	public string cadeirasInformacao(string sID_Cadeira, string sGrau)
	{
		// Avaliar grau
		string sCadeiras = (sGrau.Contains("Licenciatura") ?
			cadeirasInformacaoDeBeta(sID_Cadeira, sGrau) : (sGrau.Contains("Mestrado") ?
			cadeirasInformacaoDeAlpha(sID_Cadeira, sGrau) : (sGrau.Contains("Doutoramento") ?
			cadeirasInformacaoDeGamma(sID_Cadeira, sGrau) : "Pós-Doutoramento")));

		return sCadeiras;
	}

	public string cadeirasInformacaoDeAlpha(string sID_Cadeira, string sGrau)
	{
		string sCadeiras = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCadeiras = webService.getCadeirasInformacao(sID_Cadeira, sGrau);

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return cadeirasInformacaoDeGamma(sID_Cadeira, sGrau);
		}

		return processJsonCadeiraInformacao(sCadeiras);
	}

	public string cadeirasInformacaoDeBeta(string sID_Cadeira, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/getCadeirasInformacao.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sCadeiras = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Cadeira", sID_Cadeira);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sCadeiras = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return cadeirasInformacaoDeAlpha(sID_Cadeira, sGrau);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonCadeiraInformacao(sCadeiras);
	}

	public string cadeirasInformacaoDeGamma(string sID_Cadeira, string sGrau)
	{
		string sCadeiras = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			//sCadeiras = webService.getCadeirasInformacao(sID_Cadeira, sGrau);

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return cadeirasInformacaoDeBeta(sID_Cadeira, sGrau);
		}

		return processJsonCadeiraInformacao(sCadeiras);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Atualizar avaliação de uma disciplina na Base de Dados

	[WebMethod]
	public string updateAvaliacaoDisciplina(string sID_Avaliacao, string sFator_Ponderacao, string sData, string sCurso)
	{
		// Avaliar grau
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateAvaliacaoDisciplinaDeBeta(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
					sResultado = updateAvaliacaoDisciplinaDeAlpha(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateAvaliacaoDisciplinaDeAlpha(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
					sResultado = updateAvaliacaoDisciplinaDeGamma(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateAvaliacaoDisciplinaDeGamma(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
					sResultado = updateAvaliacaoDisciplinaDeBeta(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string updateAvaliacaoDisciplinaDeAlpha(string sID_Avaliacao, string sFator_Ponderacao, string sData, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateAvaliacao(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string updateAvaliacaoDisciplinaDeBeta(string sID_Avaliacao, string sFator_Ponderacao, string sData, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/updateAvaliacao.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Avaliacao", sID_Avaliacao);
				reqparm.Add("Fator_Ponderacao", sFator_Ponderacao);
				reqparm.Add("Data", sData);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string updateAvaliacaoDisciplinaDeGamma(string sID_Avaliacao, string sFator_Ponderacao, string sData, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateAvaliacao(sID_Avaliacao, sFator_Ponderacao, sData, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}


	// ----------------------------------------------------------------------------------------------------------------------------------
	// Procura as informações de cadeiras

	[WebMethod]
	public string avaliacoesInformacao(string sID_Avaliacao, string sCurso)
	{
		// Avaliar grau
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sCadeiras = "";
		switch (sGrau)
		{
			case "Licenciatura":
				sCadeiras = avaliacoesInformacaoDeBeta(sID_Avaliacao, sGrau);
				break;
			case "Mestrado":
				sCadeiras = avaliacoesInformacaoDeAlpha(sID_Avaliacao, sGrau);
				break;
			case "Doutoramento":
				sCadeiras = avaliacoesInformacaoDeGamma(sID_Avaliacao, sGrau);
				break;
			default:
				sCadeiras = "";
				break;
		}

		return sCadeiras;
	}

	public string avaliacoesInformacaoDeAlpha(string sID_Avaliacao, string sGrau)
	{
		string sAvaliacoes = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sAvaliacoes = webService.getAvaliacaoInformacao("1", "Mestrado");

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Licenciatura"))
				return "Erro" + e.ToString();
			return avaliacoesInformacaoDeGamma(sID_Avaliacao, sGrau);
		}

		return processJsonAvaliacaoInformacao(sAvaliacoes);
	}

	public string avaliacoesInformacaoDeBeta(string sID_Avaliacao, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/getAvaliacoesInformacao.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sCadeiras = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Avaliacao", sID_Avaliacao);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sCadeiras = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Doutoramento"))
				return "Erro" + e.ToString();
			return avaliacoesInformacaoDeAlpha(sID_Avaliacao, sGrau);
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonAvaliacaoInformacao(sCadeiras);
	}

	public string avaliacoesInformacaoDeGamma(string sID_Avaliacao, string sGrau)
	{
		string sCadeiras = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sCadeiras = webService.getAvaliacaoInformacao(sID_Avaliacao, sGrau);

		}
		catch (Exception e)
		{
			// Se o pedido vier de outro servidor
			if (sGrau.Contains("Mestrado"))
				return "Erro" + e.ToString();
			return cadeirasInformacaoDeBeta(sID_Avaliacao, sGrau);
		}

		return processJsonAvaliacaoInformacao(sCadeiras);
	}
	

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Introduzir avaliação numa disciplina na Base de Dados

	[WebMethod]
	public string updateNotaAlunoAvaliacao(string sID_Avaliacao, string sID_Aluno, string sNota, string sCurso)
	{
		// Avaliar grau
		string sGrau = (sCurso.Contains("Licenciatura") ?
			"Licenciatura" : (sCurso.Contains("Mestrado") ?
			"Mestrado" : (sCurso.Contains("Doutoramento") ?
			"Doutoramento" : "Pós-Doutoramento")));

		string sResultado = "";
		switch (sGrau)
		{
			case "Licenciatura":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateNotaAlunoAvaliacaoDeBeta(sID_Avaliacao, sID_Aluno, sNota, sGrau);
					sResultado = updateNotaAlunoAvaliacaoDeAlpha(sID_Avaliacao, sID_Aluno, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Mestrado":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateNotaAlunoAvaliacaoDeAlpha(sID_Avaliacao, sID_Aluno, sNota, sGrau);
					sResultado = updateNotaAlunoAvaliacaoDeGamma(sID_Avaliacao, sID_Aluno, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			case "Doutoramento":
				if (pingServidor(sGrau).Equals("OK"))
				{
					sResultado = updateNotaAlunoAvaliacaoDeGamma(sID_Avaliacao, sID_Aluno, sNota, sGrau);
					sResultado = updateNotaAlunoAvaliacaoDeBeta(sID_Avaliacao, sID_Aluno, sNota, sGrau);
				}
				else
				{
					sResultado = "NO_OK";
				}
				break;
			default:
				sResultado = "";
				break;
		}

		return sResultado;
	}

	public string updateNotaAlunoAvaliacaoDeAlpha(string sID_Avaliacao, string sID_Aluno, string sNota, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			MestradoService.ServicoWeb webService = new MestradoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateAvaliacaoAluno(sID_Avaliacao, sID_Aluno, sNota, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	public string updateNotaAlunoAvaliacaoDeBeta(string sID_Avaliacao, string sID_Aluno, string sNota, string sGrau)
	{
		string sUrl = "https://" + sIPBeta + "/sd/updateAvaliacaoAluno.php";

		ServicePointManager
		.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
		string sResultado = "";
		try
		{
			using (WebClientEx client = new WebClientEx())
			{
				var reqparm = new System.Collections.Specialized.NameValueCollection();
				reqparm.Add("ID_Avaliacao", sID_Avaliacao);
				reqparm.Add("ID_Aluno", sID_Aluno);
				reqparm.Add("Nota", sNota);
				reqparm.Add("Grau", sGrau);
				byte[] responsebytes = client.UploadValues(sUrl, "POST", reqparm);
				sResultado = Encoding.UTF8.GetString(responsebytes);
			}

		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		// Devolver a resposta de servidor depois de processado o JSON
		return processJsonResultadoInsercao(sResultado);
	}

	public string updateNotaAlunoAvaliacaoDeGamma(string sID_Avaliacao, string sID_Aluno, string sNota, string sGrau)
	{
		string sResultado = "";
		try
		{
			ServicePointManager
			.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

			DoutoramentoService.ServicoWeb webService = new DoutoramentoService.ServicoWeb();
			// Timeout para evitar um tempo de espera longo
			webService.Timeout = iTimeout;
			sResultado = webService.updateAvaliacaoAluno(sID_Avaliacao, sID_Aluno, sNota, sGrau);
		}
		catch (Exception e)
		{
			return "NO_OK";
		}

		return processJsonResultadoInsercao(sResultado);
	}

	// ----------------------------------------------------------------------------------------------------------------------------------
	// Parsers de JSON

	private string processJsonCursoAluno(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<Curso>>(sJson);

		foreach (Curso row in deserializedResult)
		{
			Curso curso = (Curso)row;

			sResult += curso.Descricao + ">>";
		}

		return sResult;
	}

	private string processJsonCurso(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<Curso>>(sJson);

		foreach (Curso row in deserializedResult)
		{
			Curso curso = (Curso)row;

			sResult += curso.Codigo + "||" + curso.Descricao + ">>";
		}

		return sResult;
	}

	private string processJsonCadeira(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<Cadeira>>(sJson);

		foreach (Cadeira row in deserializedResult)
		{
			Cadeira cadeira = (Cadeira)row;

			sResult += cadeira.ID + "||" + cadeira.Codigo + " . " + cadeira.Nome + ">>";
		}

		return sResult;
	}

	private string processJsonAvaliacao(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<Avaliacao>>(sJson);

		foreach (Avaliacao row in deserializedResult)
		{
			Avaliacao avaliacao = (Avaliacao)row;

			sResult += avaliacao.ID + "||" + avaliacao.Data + ". " + avaliacao.Designacao + " : " + avaliacao.Nota + ">>";
		}

		return sResult;
	}

	private string processJsonNotasDeAvaliacaoDeCadeira(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<NotaDeAvaliacaoDeCadeira>>(sJson);

		foreach (NotaDeAvaliacaoDeCadeira row in deserializedResult)
		{
			NotaDeAvaliacaoDeCadeira notaAvalCadeira = (NotaDeAvaliacaoDeCadeira)row;

			sResult += notaAvalCadeira.ID + "||" + notaAvalCadeira.Nota + ">>";
		}

		return sResult;
	}

	private string processJsonClassificacaoDeCadeira(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<ClassificacaoDeCadeira>>(sJson);

		foreach (ClassificacaoDeCadeira row in deserializedResult)
		{
			//Avaliacao avaliacao = (Avaliacao)row;
			//sResult += avaliacao.ID + "||" + avaliacao.Designacao + " : " +avaliacao.Data + ">>";

			ClassificacaoDeCadeira classCadeira = (ClassificacaoDeCadeira)row;
			sResult += classCadeira.ID + "||" + classCadeira.Nome + " : " + classCadeira.Nota + ">>";
		}

		return sResult;
	}

	private string processJsonAvaliacaoDeAlunoEmCadeira(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<AvaliacaoDeAlunoEmCadeira>>(sJson);

		foreach (AvaliacaoDeAlunoEmCadeira row in deserializedResult)
		{
			AvaliacaoDeAlunoEmCadeira avalAlunCadeira = (AvaliacaoDeAlunoEmCadeira)row;

			sResult += avalAlunCadeira.Data + ". " + avalAlunCadeira.Designacao + " : " + avalAlunCadeira.Nota + ">>";
		}

		return sResult;
	}

	private string processJsonResultadoInsercao(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<Resposta>>(sJson);
		foreach (Resposta row in deserializedResult)
		{
			Resposta resposta = (Resposta)row;

			sResult += resposta.Resultado;
		}

		return sResult;
	}

	private string processJsonTipoAvaliacao(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<TipoAvaliacao>>(sJson);

		foreach (TipoAvaliacao row in deserializedResult)
		{
			TipoAvaliacao tipoAval = (TipoAvaliacao)row;

			sResult += tipoAval.ID + "||" + tipoAval.Designacao + ">>";
		}

		return sResult;
	}

	private string processJsonCursoInformacao(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<CursoInformacao>>(sJson);

		foreach (CursoInformacao row in deserializedResult)
		{
			CursoInformacao cursoInfo = (CursoInformacao)row;

			sResult += cursoInfo.Nome + "#" + cursoInfo.ECTS + "#" + cursoInfo.Codigo + "#" + cursoInfo.Descricao + ">>";
		}

		return sResult;
	}

	private string processJsonCadeiraInformacao(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<CadeiraInformacao>>(sJson);

		foreach (CadeiraInformacao row in deserializedResult)
		{
			CadeiraInformacao cursoInfo = (CadeiraInformacao)row;

			sResult += cursoInfo.Nome + "#" + cursoInfo.Codigo + "#" + cursoInfo.Criterios + "#" + cursoInfo.Descricao + "#" + cursoInfo.ECTS + ">>";
		}

		return sResult;
	}

	private string processJsonAvaliacaoInformacao(string sJson)
	{
		if (sJson.Equals(""))
			return sJson;

		string sResult = "";
		var serializer = new JavaScriptSerializer();
		var deserializedResult = serializer.Deserialize<List<AvaliacaoInformacao>>(sJson);

		foreach (AvaliacaoInformacao row in deserializedResult)
		{
			AvaliacaoInformacao cursoInfo = (AvaliacaoInformacao)row;

			sResult += cursoInfo.FatorPonderacao + "#" + cursoInfo.Data + ">>";
		}

		return sResult;
	}

	// Classes

	public class Curso
	{
		public int Codigo { get; set; }
		public string Descricao { get; set; }
	}

	public class Cadeira
	{
		public int ID { get; set; }
		public int Codigo { get; set; }
		public string Nome { get; set; } // ALTERAR DESCRICAO PARA NOME NOS WEBSERVICE/PHP
	}

	public class NotaDeAvaliacaoDeCadeira
	{
		public int ID { get; set; }
		public double Nota { get; set; }
	}

	public class ClassificacaoDeCadeira
	{
		public int ID { get; set; }
		public string Nome { get; set; }
		public string Nota { get; set; }
	}

	public class AvaliacaoDeAlunoEmCadeira
	{
		public string Data { get; set; }
		public string Designacao { get; set; }
		public double Nota { get; set; }

	}

	public class Avaliacao
	{
		public int ID { get; set; }
		public string Data { get; set; }
		public string Designacao { get; set; }
		public int Nota { get; set; } /// -----------------------------------------------------------------------------

	}

	public class Resposta
	{
		public string Resultado { get; set; }
	}

	public class TipoAvaliacao
	{
		public int ID { get; set; }
		public string Designacao { get; set; }
	}

	public class CursoInformacao
	{
		public string Nome { get; set; }
		public int ECTS { get; set; }
		public int Codigo { get; set; }
		public string Descricao { get; set; }
	}

	public class CadeiraInformacao
	{
		public string Nome { get; set; }
		public int Codigo { get; set; }
		public string Criterios { get; set; }
		public string Descricao { get; set; }
		public int ECTS { get; set; }
	}

	public class AvaliacaoInformacao
	{
		public int FatorPonderacao { get; set; }
		public string Data { get; set; }
	}
}
